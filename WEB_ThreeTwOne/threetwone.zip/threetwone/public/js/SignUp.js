// Chặn gửi biểu mẫu khi dữ liệu sai
var checkForm = () => {
  let name = document.getElementById("name");
  let email = document.getElementById("email");
  let pass = document.getElementById("pass");
  let date = document.getElementById("date");
  let phone = document.getElementById("phone");
  //Kiểm tra không nhập
  isValid = true;
  if (
    name.value.length == 0 ||
    email.value.length == 0 ||
    pass.value.length == 0 ||
    date.value.length == 0
  ) {
    let mess = document.querySelector(".tong > .alert-warning");
    displayWarn(mess, "Không được bỏ trống các ô trên");
    isValid = false;
  }
  // Kiểm tra mật khẩu
  if (
    !/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/.test(pass.value)
  ) {
    let mess = document.querySelector(".matkhau > .alert-warning");
    displayWarn(
      mess,
      "Mật khẩu không hợp lệ! ít nhất 8 ký tự, có chữ hoa, chữ thường, số và ký tự đặc biệt."
    );
    isValid = false;
  }
  // Kiểm tra Phone
  if (!/^(0\d{9,10})$/.test(phone.value)) {
    let mess = document.querySelector(".sdt > .alert-warning");
    displayWarn(mess, "Số điện thoại không hợp lệ!");
    isValid = false;
  }

  //Kiểm tra ngày
  if (checkDate() == false) {
    isValid = false;
  }
  return isValid;
};
// Hiện cảnh báo
var displayWarn = (mess, text) => {
  mess.style.display = "flex";
  mess.innerHTML = text;
  // Set thời gian sẽ ẩn thông báo sao 8 giây
  setTimeout(() => {
    mess.style.display = "none";
  }, 8000);
};

// Hiện nhắc nhở vào mail xác nhận
document.addEventListener("DOMContentLoaded", () => {
  let mess = document.querySelector("body > .mess");
  if (mess) {
    setTimeout(() => {
      mess.classList.add("hidden");
      setTimeout(() => {
        mess.style.display = "none";
        console.log("Thông báo đã ẩn!");
      }, 2000);
    },1000);
  }
});

// document.addEventListener("DOMContentLoaded", function () {
//   const alertBox = document.querySelector(".body > .mess");
//   if (alertBox) {
//     setTimeout(() => {
//       alertBox.style.opacity = "0";
//       alertBox.style.visibility = "hidden";
//     }, 2000); // 3 giây
//   }
// });

// Kiểm tra ngày sinh có đủ 18 tuổi không
var checkDate = () => {
  let date = document.getElementById("date");
  let message = document.querySelector(".mb-3 > .alert");
  let dateValue = new Date(date.value);
  let today = new Date();
  let age = today.getFullYear() - dateValue.getFullYear();

  if (age < 18) {
    message.style.display = "flex";
    message.innerHTML = "Ngày sinh không hợp lệ, Bạn phải trên 18 tuổi";
    return false;
  } else {
    message.style.display = "none";
    return true;
  }
};

// tắt bật icon password
var togglePassword = () => {
  let pass = document.getElementById("pass");
  let icon = document.querySelector(".icon");
  if (pass.type === "password") {
    pass.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    pass.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
};
// Kiểm tra có dữ liệu nhập vào không
