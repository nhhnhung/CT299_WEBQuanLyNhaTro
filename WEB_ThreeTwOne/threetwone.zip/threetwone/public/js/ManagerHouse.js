// chuyển tới trang thông tin nhà trọ
const goToInfoHouse = (ma_nt) => {
    window.location.href = `DetailBoardingHouse.php?ma_nt=${ma_nt}`;
};

const goToList = () => {
    document.getElementById("listTypeRoom").scrollIntoView({behavior: "smooth"});
}

document.addEventListener("DOMContentLoaded", function () {
    setTimeout(() => {
        document.querySelector('.alert').style.display = 'none';
    }, 3000);
});


// chuyển đổi tiền
document.querySelectorAll(".gia").forEach((element) => {
    let price = Number(element.getAttribute("data-price"));
    element.innerText = price.toLocaleString("vi-VN", {
        style: "currency",
        currency: "VND",
    });
});

//Phần upload ảnh bên chi tiết nhà trọ
const clickAddImgs = () =>{
    document.getElementById("imgs").click();
}
// Hiển thị số lượng ảnh đã chọn
document.getElementById("imgs").addEventListener("change", function () {
    let numImgs = this.files.length; // Số lượng ảnh đã chọn
    document.getElementById("number-img").innerText = "Số ảnh đã chọn :"+numImgs;
});
