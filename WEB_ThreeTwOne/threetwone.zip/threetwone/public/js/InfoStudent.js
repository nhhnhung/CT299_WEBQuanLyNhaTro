// Phần ẩn hiện avartar box
var toggleBoxAVT = () => {
    let avtBox = document.getElementById("avt-box");
    avtBox.classList.toggle("show");
};

// ẩn khi click ra ngoài trang
document.addEventListener("click", function (event) {
    let avtBox = document.getElementById("avt-box");
    let avt = document.querySelector(".avatar");
    let menuBox = document.getElementById("menu-box");
    let menu = document.querySelector(".menu");

    // Kiểm tra không có sự kiện click vào 2 thành phần trên
    if (!avt.contains(event.target) && !avtBox.contains(event.target)) {
        avtBox.classList.remove("show");
    }

    if (!menu.contains(event.target) && !menuBox.contains(event.target)) {
        avtBox.classList.remove("display");
    }
});

// Phần ẩn hiện danh mục
var toggleMenuBox = () => {
    let menuBox = document.getElementById("menu-box");
    let overlay = document.getElementById("overlay");
    menuBox.classList.toggle("display");
    overlay.classList.toggle("display");
};

document.addEventListener("click", function (event) {
    let menuBox = document.getElementById("menu-box");
    let menu = document.querySelector(".menu");
    let overlay = document.getElementById("overlay");

    // Kiểm tra không có sự kiện click vào 2 thành phần trên
    if (!menu.contains(event.target) && !menuBox.contains(event.target)) {
        menuBox.classList.remove("display");
        overlay.classList.remove("display");
    }
});

// Khi logout thì không thể quay lại trang trước đó
var logout = () => {
    window.location.replace("Logout.php");
};

// Phần hiện thông báo có muốn Upload không
function showConfirm() {
    document.getElementById("customConfirm").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

function closeConfirm() {
    document.getElementById("customConfirm").style.display = "none";
    document.getElementById("overlay").style.display = "none";
    return false;
}

// gửi form
function UploadItem() {
    document.getElementById("editForm").submit();
    return true;
}

var checkDate = () => {
    let date = document.getElementById("date");
    let message = document.querySelector(".table-edit > .alert");
    let dateValue = new Date(date.value);
    let today = new Date();
    let age = today.getFullYear() - dateValue.getFullYear();

    if (!date.value) {
        displayWarn(message, "Vui lòng nhập ngày sinh!");
        return false;
    }

    if (age < 18) {
        displayWarn(message, "Ngày sinh không hợp lệ, Bạn phải trên 18 tuổi");
        return false;
    }
    return true;
};

// Hiện cảnh báo
var displayWarn = (mess, text) => {
    if (!mess) {
        console.error("Phần tử cảnh báo không tồn tại!");
        return;
    }
    mess.style.display = "flex";
    mess.innerHTML = text;
    // Set thời gian sẽ ẩn thông báo sao 8 giây
    setTimeout(() => {
        mess.style.display = "none";
    }, 3000);
};

// Hàm check form
var checkForm = () => {
    let phone = document.getElementById("phone");
    let message = document.querySelector(".table-edit > .alr1");
    let testPhone = /^(0\d{9,10})$/.test(phone.value);

    // Kiểm tra Phone
    if (!testPhone) {
        displayWarn(message, "Số điện thoại không hợp lệ!");
        if (!checkDate()) {
            return false;
        }
        return false;
    }

    //Kiểm tra ngày
    if (!checkDate()) {
        return false;
    }

    showConfirm();
    return false
};

// Phần ko cho đăng ký dịch dụ khi chưa có phòng
var checkRoom = () => {
    let room = document.querySelector(".select-room > option:checked");
    let message = document.querySelector(".box-alr > .alert");
    if (room.value == "-1") {
        displayWarn(message, "Bạn chưa có phòng nào để đăng ký dịch vụ!");
        return false;
    }
    return true;
};

// Hàm upload ảnh
function uploadAvatar() {
    document.getElementById("fileToUpload").click();
}

//Hàm hiển thị ảnh trước khi upload
function previewAvatar(event) {
    const img = document.getElementById("img-personnal");
    const file = event.target.files[0]; //lấy file ảnh
    const reader = new FileReader(); //đọc file
    reader.onload = function (e) {
        img.src = e.target.result; //gán đường dẫn ảnh
    };
    reader.readAsDataURL(file);
}
