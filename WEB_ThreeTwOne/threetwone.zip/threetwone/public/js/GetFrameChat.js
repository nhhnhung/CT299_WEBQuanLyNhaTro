
var botmanWidget = {
    frameEndpoint: 'http://localhost/threetwone/public/helper/FrameChat.php',
    introMessage: '🤖 Xin chào! Tôi có thể giúp gì cho bạn?',
    chatServer : '../helper/Bot.php',
    title: 'Threetwone Chatbot',
    timeFormat: 'HH:MM',
    dateTimeFormat: 'm/d/yy HH:MM',
    placeholderText: 'Nhập tin nhắn ...',
    displayMessageTime: true,
    mainColor: 'rgb(52, 195, 235)',
    bubbleBackground: 'black',
    aboutText: '',
    bubbleAvatarUrl: 'http://localhost/threetwone/public/img_chatbot/icon-bot.png',
    desktopHeight:500,
    desktopWidth:800,
    mobileHeight:100,
    mobileWidth:100,
    videoHeight:500,
    videoWidth:500,
    aboutLink: '',
    aboutText: '',
};


