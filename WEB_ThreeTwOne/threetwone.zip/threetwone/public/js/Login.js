
document.addEventListener('DOMContentLoaded', function () {
    const alertBox = document.querySelector('.alert');
    if (alertBox) {
        setTimeout(() => {
            alertBox.style.opacity = '0';
            alertBox.style.visibility = 'hidden';
        }, 2000); // 3 giây
    }
});



function togglePassword() {
    var passwordField = document.getElementById("password");
    var toggleIcon = document.querySelector(".toggle-password i");

    // Kiểm tra nếu mật khẩu đang ẩn, thì hiện ra, ngược lại ẩn đi
    if (passwordField.type === "password") {
        passwordField.type = "text";  // Thay đổi loại input thành text
        toggleIcon.classList.remove("fa-eye");  // Xóa biểu tượng mắt đóng
        toggleIcon.classList.add("fa-eye-slash");  // Thêm biểu tượng mắt mở
    } else {
        passwordField.type = "password";  // Thay đổi loại input trở lại password
        toggleIcon.classList.remove("fa-eye-slash");  // Xóa biểu tượng mắt mở
        toggleIcon.classList.add("fa-eye");  // Thêm biểu tượng mắt đóng
    }
}

    
