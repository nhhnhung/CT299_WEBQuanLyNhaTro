let count = localStorage.getItem("count") ? parseInt(localStorage.getItem("count")) : 0;

document.addEventListener("DOMContentLoaded", function () {
    const alertBox = document.getElementById("note");
    const form = document.getElementById("box");
    if (alertBox) {
        count++;
        localStorage.setItem("count",count);
        setTimeout(() => {
            alertBox.style.display = "none";
        }, 2000); // 2 giây
    }

    if (count == 3) {
        form.style.opacity = "0";
        form.style.visibility = "none";
        alert("Bạn nhập sai quá 3 lần, chờ 5 phút để đăng nhập lại!");

        setTimeout(() => {
            form.style.opacity = "1";
            form.style.visibility = "visible";
            localStorage.setItem("count", 0); // Reset count về 0
        }, 5*60*1000);
    }
});




