<?php
    require '../../vendor/autoload.php';
    use BotMan\BotMan\BotMan;
    use BotMan\BotMan\BotManFactory;
    use BotMan\BotMan\Drivers\DriverManager;
    use GuzzleHttp\Client;

    $config = [];
    DriverManager::loadDriver(\BotMan\Drivers\Web\WebDriver::class);
    $botman = BotManFactory::create($config);
    $botman->hears('.*.*', function ($bot) {
        $message = $bot->getMessage()->getText();
        $respone = sendMessageToRasa($message);
        $bot->reply($respone);
    });

    $botman->listen();
    function sendMessageToRasa($message) {
        $client = new Client();
        try {
            $response = $client->post('http://localhost:5005/webhooks/rest/webhook', [
                'json' => [
                    'sender' => $_COOKIE['ma_sv'],
                    'message' => $message
                ]
            ]);

            $data = json_decode($response->getBody()->getContents(), true);
            $responses = [];
            foreach ($data as $response) {
                if (isset($response['text'])) {
                    $responses[] = $response['text'];
                }

                if (isset($response['image'])) {
                    $responses[] = "<img src='{$response['image']}' style='max-width: 300px;'>";
                }
            }

            $finalResponse = implode("<br>", $responses);
            return $finalResponse ?: 'Chúng tôi không hiểu yêu cầu của bạn !!!';
        } catch (\Exception $e) {
            return 'Chúng tôi không hiểu yêu cầu của bạn !!!';
        }
    }

?>