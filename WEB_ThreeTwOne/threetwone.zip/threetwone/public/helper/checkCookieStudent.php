<?php
    if($_COOKIE['ma_sv'] == null){
        header('Location: Login.php');
    }
?>
