<?php
    function pay($vnp_Returnurl, $vnp_TxnRef, $vnp_OrderInfo, $vnp_OrderType, $vnp_Amount){
        error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
        date_default_timezone_set('Asia/Ho_Chi_Minh');

        $vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
        $vnp_TmnCode = "JIBMOZHC";//Mã website tại VNPAY
        $vnp_HashSecret = "13L00ZHVZ1VGJVL0W93Y05GVJD3X8PHP"; //Chuỗi bí mật


        $vnp_Amount = $vnp_Amount * 100; // số tiền thanh toán, phải nhân 100 để đưa về đơn vị tiền tệ nhỏ nhất
        $vnp_Locale = "vn"; // ngôn ngữ hiển thị trên cổng thanh toán
        $vnp_BankCode = "NCB"; // mã Ngân hàng thanh toán
        $vnp_IpAddr = "127.0.0.1"; // Địa chỉ IP người mua
        $inputData = array(
            "vnp_Version" => "2.1.0", // phiên bản vnPay
            "vnp_TmnCode" => $vnp_TmnCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef,
        );

        if (isset($vnp_BankCode) && $vnp_BankCode != "") {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }

        //var_dump($inputData);
        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash =   hash_hmac('sha512', $hashdata, $vnp_HashSecret);
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }
        $returnData = array('code' => '00'
        , 'message' => 'success'
        , 'data' => $vnp_Url);
        if (isset($_POST['redirect'])) {
            header('Location: ' . $vnp_Url);
            die();
        } else {
            // echo json_encode($returnData);
        }
    }

?>

<!--
    Giải thích hàm :
    pay($vnp_Returnurl, $vnp_TxnRef, $vnp_OrderInfo, $vnp_OrderType, $vnp_Amount)
    - $vnp_Returnurl : URL trả về khi thanh toán thành công
    - $vnp_TxnRef : Mã đơn hàng. Trong thực tế Merchant cần insert đơn hàng vào DB và gửi mã này sang VNPAY
    - $vnp_OrderInfo : nội dung thanh toán
    - $vnp_OrderType : loại đơn hàng
    - $vnp_Amount : số tiền thanh toán

-->

<!--Tài khoản test:-->
<!--Ngân hàng: NCB-->
<!--Số thẻ: 9704198526191432198-->
<!--Tên chủ thẻ:NGUYEN VAN A-->
<!--Ngày phát hành:07/15-->
<!--Mật khẩu OTP:123456-->

<!-- Các tài khoản kiểm thử khác tại : https://sandbox.vnpayment.vn/apis/vnpay-demo/ -->
<!--Link hướng dẫn : https://sandbox.vnpayment.vn/apis/docs/thanh-toan-pay/pay.html -->


