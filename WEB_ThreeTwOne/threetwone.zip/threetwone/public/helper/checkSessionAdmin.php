<?php
    include '../model/checkAdmin.php';
    if(check($_SESSION['admin']) == false){
        header('Location: Login.php');
    }
?>