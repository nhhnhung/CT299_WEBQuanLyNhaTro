<?php

require '../vendor/autoload.php';
require '../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/phpmailer/src/SMTP.php';

    function send_email($subject, $body, $address_seen) {
        $mail = new PHPMailer\PHPMailer\PHPMailer();
        $mail->IsSMTP(); // khởi tạo SMTP

        //$mail->SMTPDebug = 1; // bật SMTP debug hiển thị từng dòng
        $mail->SMTPAuth = true; // bật SMTP authentication
        $mail->SMTPSecure = 'ssl'; // bật SSL
        $mail->Host = "smtp.gmail.com"; // SMTP server
        $mail->Port = 465; // or 587
        $mail->IsHTML(true);
        $mail->CharSet = "utf-8";
        $mail->Username = "phatb2205953@student.ctu.edu.vn"; // tên đăng nhập email
        $mail->Password = "apez ijzn kvfe mlwz"; // mật khẩu ứng dụng email (vào xác thực 2 bước để tạo)
        $mail->SetFrom("phatb2205953@student.ctu.edu.vn"); // email người gửi
        $mail->Subject = $subject; // tiêu đề email
        $mail->Body = $body; // nội dung email
        $mail->AddAddress($address_seen); // email người nhận

        if(!$mail->Send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            echo
        '<body>
            <div class="alert alert-info mess" role="alert">
                Vui lòng vào email để xác nhận !!!
            </div>
        </body>';
        }
    }



?>
