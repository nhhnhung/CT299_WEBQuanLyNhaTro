<?php
    if($_COOKIE['ma_ct'] == null){
        header('Location: Login.php');
    }
?>