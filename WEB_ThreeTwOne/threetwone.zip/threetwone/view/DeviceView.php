<?php
    function getFormEditDevice($action, $device){
        return '
            <div class="main-content container">
                <div class="row mainR">
                    <form action="' . $action . '" method="post" class="form-edit-device" enctype="multipart/form-data">
                        <input type="hidden" name="current_img" value="' . $device['img'] . '">
                        <h1 class="title">Sửa thiết bị</h1>
                        <input type="hidden" name="ma_tb" value="' . $device['ma_tb'] . '">
                        <img id="imgInput" src="'.$device['img'].'" onclick="uploadAvatar()" style="width: 200px;">
                        <input type="file" name="fileToUpload" id="fileToUpload" onchange="previewAvatar(event)" style="display:none;">
                        <input type="text" name="tenthietbi" value="' . $device['tenthietbi'] . '" required>
                        <input type="submit" value="Sửa" class="btn-edit">
                    </form>
                </div>
            </div>
                ';
    }

    function getFormAddDevice($action) {
        return '
                    <div class="boxImg">
                        <img id="imgInput" src="../public/img/default_avartar.jpg" alt="Click vào để thêm ảnh" style="width: 100px;" onclick="uploadAvatar()">
                    </div>
                    <form action="' . $action . '" method="post" class="device-form" enctype="multipart/form-data">
                        <input type="file" name="fileToUpload" id="fileToUpload" " style="display:none;" onchange="previewAvatar(event)">
                        <input type="text" name="tenthietbi" placeholder="Tên thiết bị" class="device-input">
                        <input type="submit" value="Thêm" class="device-button">
                    </form>';
    }

    function showListDevice($devices) {
        $stt = 0;
        echo '<table class="device-table">
                    <tr>
                        <th class="device-th">STT</th>
                        <th class="device-th">Tên thiết bị</th>
                        <th class="device-th img_device">Hình ảnh</th>
                        <th class="device-th">Thao tác</th>
                    </tr>';
        while ($row = $devices->fetch_assoc()) {
            echo '<tr>
                        <td class="device-td">' . ++$stt . '</td>
                        <td class="device-td">' . $row["tenthietbi"] . '</td>
                        <td class="devide-td"><img src="'.$row['img'].'" style="width: 100px;"></td>
                        <td class="device-td">
                            <form action="DeviceEdit.php" method="get" style="display:inline-block;">
                                <input type="hidden" name="ma_tb" value="' . $row["ma_tb"] . '">
                                <button type="submit" class="btn-edit">Sửa</button>
                            </form>
                            <form action="DeviceDelete.php" method="get" style="display:inline-block;" onsubmit="return confirm(\'Bạn có chắc chắn muốn xóa?\');">
                                <input type="hidden" name="img" value="' . $row["img"] . '">
                                <input type="hidden" name="ma_tb" value="' . $row["ma_tb"] . '">
                                <button type="submit" class="btn-delete">Xóa</button>
                            </form>
                        </td>
                      </tr>';
        }
        echo '</table>';
    }

?>
