
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container container123">
        <a class="navbar-brand" href="LandLord.php">
            <img src="../public/img/mainLogo.png" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="InfoLandlord.php">Thông tin cá nhân</a></li>
                <li class="nav-item"><a class="nav-link" href="MangeBoardingHouse.php">Quản lý nhà trọ</a></li>
                <li class="nav-item"><a class="nav-link" href="ApproveRoomBooking.php">Duyệt thuê phòng</a></li>
                <li class="nav-item"><a class="nav-link" href="Commission.php">Hoa hồng</a></li>
                <li class="nav-item"><a class="nav-link" href="NoteElectricWater.php">Quản lý điện nước</a></li>
                <li class="nav-item"><a class="nav-link" href="Device.php">Thiết bị</a></li>
                <li class="nav-item"><a class="nav-link" href="MakePostLandLord.php">Đăng tin</a></li>
                <li class="nav-item"><a class="nav-link" href="Posts.php">Bài đăng</a></li>
                <li class="nav-item">
                    <a class="nav-link text-danger" href="Logout.php" id="logout-link">Đăng xuất</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById("logout-link").addEventListener("click", function(event) {
        if (!confirm("Bạn có chắc chắn muốn đăng xuất không?")) {
            event.preventDefault(); // Ngăn không cho chuyển trang nếu bấm Cancel
        }
    });
</script>
