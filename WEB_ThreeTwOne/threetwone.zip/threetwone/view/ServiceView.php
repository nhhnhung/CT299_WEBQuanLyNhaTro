<?php
    function showAllService($listService, $listRoom){
        $stt = 0;
        echo '
                <form action="ServiceBooking.php" method="get" onsubmit="return checkRoom()">
                    <div class="container first">
                        <div class="row">
                            <h1>Danh sách dịch vụ</h1>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="number">STT</th>
                                        <th>Tên dịch vụ</th>
                                        <th>Mô tả</th>
                                        <th>Giá</th>
                                        <th>Hình ảnh</th>
                                        <th>Số lượng</th>
                                    </tr>
                                </thead>
                                <tbody>';
        while ($row = $listService->fetch_assoc()) {
            echo '
                                    <tr>
                                        <td>' . ++$stt . '</td>
                                        <td>' . $row['tendichvu'] . '</td>
                                        <td>' . $row['mota'] . '</td>
                                        <td class="money"> ';
            echo number_format($row['gia'], 0, ",", ".") . ' VND
                                        </td>
                                        <td><img id="imgInput" src="' . $row['img'] . '" alt="ảnh minh họa" style="width: 100px;"></td>
                                        <td>
                                            <input class="number" type="number" name="' . $row['ma_dv'] . '" min="0" value="0" maxlenght="3">
                                        </td>
                                    </tr>';
        }
        echo '
                              
                                </tbody>
                            </table>
                        </div>
                        <div class="row row-room"> 
                            <div class="room col-12">   
                                <h3>Danh sách phòng bạn đang ở</h3>
                                <div class="box-alr">
                                    <div class="alert alert-warning" role="alert"></div>
                                </div>
                                <select name="ma_phong" class="select-room">
                                    <option value="-1">Chọn phòng</option>';

        if ($listRoom->num_rows > 0) {
            while ($row = $listRoom->fetch_assoc()) {
                echo '<option value="' . $row['ma_phong'] . '">Phòng ' . $row['sophong'] . $row['ten_nt'] . $row['diachi'] . '</option>';
            }
        } else {
            echo '<option value="-1">Bạn chưa thuê phòng nào</option>';
        }

        echo '
                            </select>
                                <button type="submit" class="btn btn-primary">Đặt dịch vụ</button>
                            </div>
                        </div>
                    </div>
                </form>';
    }


    function showAllServiceBooked($listService) {
        echo '<div class="container container-service-booked">';
        echo '<h4 class="text-center mb-3">Danh sách dịch vụ bạn đã chọn</h4>';
        echo '<div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr class="text-center">
                                    <th>STT</th>
                                    <th>Tên dịch vụ</th>
                                    <th>Giá</th>
                                    <th>Số lượng</th>
                                    <th>Thành tiền</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">';
        $stt = 0;
        foreach ($listService as $service) {
            echo '<tr>
                            <td>' . ++$stt . '</td>
                            <td>' . $service['tendichvu'] . '</td>
                            <td>' . number_format($service['gia'], 0, ',', '.') . ' VND</td>
                            <td>' . $service['soluong'] . '</td>
                            <td>' . number_format($service['gia'] * $service['soluong'], 0, ',', '.') . ' VND</td>
                        </tr>';
        }
        echo '</tbody>
                    </table>
                </div>
                </div>';
    }




    function getFormPayService($action, $vnp_Returnurl, $vnp_TxnRef, $vnp_OderInfo, $vnp_OderType, $vpn_Amount) {
        return '<div class="container text-center mt-4">
                            <form action="' . $action . '" method="post">
                                <input type="hidden" name="vnp_Returnurl" value="' . $vnp_Returnurl . '">
                                <input type="hidden" name="vnp_TxnRef" value="' . $vnp_TxnRef . '">
                                <input type="hidden" name="vnp_OrderInfo" value="' . $vnp_OderInfo . '">
                                <input type="hidden" name="vnp_OrderType" value="' . $vnp_OderType . '">
                                <input type="hidden" name="vnp_Amount" value="' . $vpn_Amount . '">
                                <button type="submit" name="redirect" class="custom-payment-btn">Thanh toán</button>
                            </form>
                        </div>';
    }


    function getMessageSuccessPayment() {
        return '<div class="alert alert-danger mess" role="alert">
                            Thanh toán thành công
                        </div>';
    }


?>