<?php 
    function getFormForgetPass($action){
        return '<div class="container mt-5">
                    <h1>Quên mật khẩu</h1>
                    <p class="instruction-text">Nhập email của bạn để nhận mã đặt lại mật khẩu.</p>

                    <form action="' . $action . '" method="post">
                        <div class="input-group mb-3">
                            <input type="email" name="email" class="form-control" placeholder="Nhập email" required>
                        </div>
                        <button type="submit" class="btn btn-danger w-100">Gửi yêu cầu</button>
                    </form>

                    <div class="link-group text-center mt-3">
                        <a href="login.php" class="text-primary">Quay lại đăng nhập</a>
                    </div>
                    <p class="policy-text mt-4">
                        Nếu bạn cần hỗ trợ. Vui lòng liên hệ SĐT/Zalo: <span class="text-danger">0967 958 971</span>
                    </p>
                </div>';
    }


    function getFormResetPass($email){
        return '
                    <div style="
                        font-family: Arial, sans-serif; 
                        padding: 20px; 
                        border: 1px solid #ddd; 
                        border-radius: 10px; 
                        background-color: #f9f9f9; 
                        text-align: center; 
                        width: 350px; 
                        margin: 20px auto;
                        box-sizing: border-box;
                    ">
                        <h2 style="
                            color: #dc3545; 
                            font-size: 24px; 
                            margin-bottom: 20px; 
                            font-weight: bold;
                        ">
                            Đặt lại mật khẩu
                        </h2>
                
                        <form action="http://localhost/threetwone/controller/ResetPass.php" method="post" style="margin-top: 20px;">
                
                            <input style="
                                width: calc(100% - 22px); 
                                padding: 10px; 
                                margin-bottom: 15px; 
                                border-radius: 5px; 
                                border: 1px solid #ccc; 
                                font-size: 14px; 
                                box-sizing: border-box;
                            " 
                            id="boss" type="password" name="password" required placeholder="Nhập mật khẩu mới">
                
                            <input type="hidden" name="email" value="'.$email.'">
                
                            <input style="
                                background-color: #dc3545; 
                                color: white; 
                                padding: 10px 20px; 
                                border: none; 
                                border-radius: 5px; 
                                cursor: pointer; 
                                font-size: 14px; 
                                width: 50%;
                                box-sizing: border-box;
                            " 
                            class="submit" type="submit" value="Đổi mật khẩu">
                        </form>
                
                        <p style="
                            color: #6c757d; 
                            font-size: 14px; 
                            margin-top: 15px;
                        ">
                            Nếu không phải bạn, hãy bỏ qua email này.
                        </p>
                    </div>';
    }


    function getMessageNonExitEmail(){
        return '<div class="alert alert-danger mess" role="alert">Email không tồn tại!</div>';
    }

    function getBackgroundVideo(){
        return '<video autoplay loop muted plays-inline class="back-video">
                    <source src="../public/video/sakura.mp4" type="video/mp4">
                </video>';
    }

?>