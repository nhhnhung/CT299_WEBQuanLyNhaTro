<?php
    function getInfoLandLord($landlord) {
        $show = '<div class="landlord-info-container container mt-4">
                        <!-- Tiêu đề -->
                        <h2 class="text-center mb-3">Thông tin cá nhân</h2>
                        <div class="landlord-content d-flex align-items-center">
                            <!-- Ảnh đại diện -->
                            <div class="landlord-avatar">
                                <img src="';
        if ($landlord['avatar'] != null) {
            $show .= $landlord['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .= '" alt="Ảnh đại diện">
                            </div>
                            <!-- Bảng thông tin -->
                            <div class="table-container">    
                                <table class="table table-bordered">
                                    <tr><th>Họ tên</th><td>' . htmlspecialchars($landlord['hoten']) . '</td></tr>
                                    <tr><th>Ngày sinh</th><td>' . htmlspecialchars($landlord['ngaysinh']) . '</td></tr>
                                    <tr><th>Email</th><td>' . htmlspecialchars($landlord['email']) . '</td></tr>
                                    <tr><th>Địa chỉ</th><td>' . htmlspecialchars($landlord['diachi']) . '</td></tr>
                                    <tr><th>Số điện thoại</th><td>' . htmlspecialchars($landlord['sdt']) . '</td></tr>
                                </table>
                            </div>
                        </div>
                    </div>';
        return $show;
    }

    function getButtonEditInfoLandLord($landlord) {
        $form =  '<div class="landlord-info-section text-center mt-3">
                        <form action="EditInfoLandLord.php" method="post">
                            <input type="hidden" name="hoten" value="' . htmlspecialchars($landlord["hoten"]) . '">
                            <input type="hidden" name="ngaysinh" value="' . htmlspecialchars($landlord["ngaysinh"]) . '">
                            <input type="hidden" name="diachi" value="' . htmlspecialchars($landlord["diachi"]) . '">
                            <input type="hidden" name="sdt" value="' . htmlspecialchars($landlord["sdt"]) . '">
                            <input type="hidden" name="avatar" value="';
        if ($landlord['avatar'] != null ) {
            $form .= $landlord['avatar'];
        } else {
            $form .= '../public/img/default_avartar.jpg';
        }
        $form .= '">
                            <button type="submit" class="custom-btn-edit">Chỉnh sửa thông tin</button>
                        </form>
                    </div>';
        return $form;
    }

    function getFormEditInfoLandLord($info) {
        $today = date('Y-m-d');
        return '<div class="landlord-info-container container mt-4">
                        <!-- Ô hiển thị cảnh báo -->
                        <div class="alert alert-warning text-center" role="alert" style="display:none; max-width:500px; margin: 0 auto 20px auto; padding:10px 20px; font-size:14px;"></div>
        
                        <!-- Tiêu đề -->
                        <h2 class="text-center mb-3">Chỉnh sửa thông tin cá nhân</h2>
        
                        <form action="UpdateInfoLandLord.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()" >
                            <div class="landlord-content d-flex align-items-center">
                                <input type="hidden" name="current_avatar" value="' . htmlspecialchars($info['avatar']) . '">
                                <!-- Ảnh đại diện -->
                                <div class="landlord-avatar">
                                    <img id="imgInput" src="' .$info['avatar']. '" alt="Ảnh đại diện" onclick="uploadAvatar()">
                                    <input type="file" name="fileToUpload" id="fileToUpload" style="display:none;"  onchange="previewAvatar(event)" value="'.$info['avatar'].'">
                                </div>
                                <!-- Bảng chỉnh sửa thông tin -->
                                <div class="table-container">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Họ tên</th>
                                            <td><input type="text" class="form-control" name="hoten" value="' . htmlspecialchars($info['hoten']) . '"></td>
                                        </tr>
                                        <tr>
                                            <th>Ngày sinh</th>
                                            <td><input type="date" class="form-control" name="ngaysinh" max="'.$today.'" value="' . htmlspecialchars($info['ngaysinh']) . '"></td>
                                        </tr>
                                        <tr>
                                            <th>Địa chỉ</th>
                                            <td><input type="text" class="form-control" name="diachi" value="' . htmlspecialchars($info['diachi']) . '"></td>
                                        </tr>
                                        <tr>
                                            <th>Số điện thoại</th>
                                            <td><input type="tel" class="form-control" name="sdt" value="' . htmlspecialchars($info['sdt']) . '"></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <!-- Nút lưu -->
                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-success">Lưu</button>
                            </div>
                        </form>
        
                        <script>
                            function validateForm() {
                                const dateInput = document.querySelector(\'input[name="ngaysinh"]\');
                                const birthDate = new Date(dateInput.value);
                                const today = new Date();
                                let age = today.getFullYear() - birthDate.getFullYear();
                                const m = today.getMonth() - birthDate.getMonth();
                                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                                    age--;
                                }
        
                                if (birthDate > today) {
                                    showAlert("Ngày sinh không được ở tương lai.");
                                    return false;
                                }
        
                                if (age < 18) {
                                    showAlert("Ngày sinh không hợp lệ / bạn phải trên 18 tuổi.");
                                    return false;
                                }
        
                                hideAlert();
                                return confirm("Bạn có chắc chắn muốn lưu thay đổi không?");
                            }
        
                            function showAlert(message) {
                                const alertBox = document.querySelector(".landlord-info-container .alert");
                                alertBox.textContent = message;
                                alertBox.style.display = "block";
        
                                setTimeout(() => {
                                    alertBox.style.display = "none";
                                }, 3000);
                            }
        
                            function hideAlert() {
                                const alertBox = document.querySelector(".landlord-info-container .alert");
                                alertBox.textContent = "";
                                alertBox.style.display = "none";
                            }
                            // Hàm upload ảnh
                            function uploadAvatar() {
                                document.getElementById("fileToUpload").click();
                            }
    
    
                            //Hàm hiển thị ảnh trước khi upload
                            function previewAvatar(event) {
                                const img = document.getElementById("imgInput");
                                const file = event.target.files[0]; //lấy file ảnh
                                const reader = new FileReader(); //đọc file
                                reader.onload = function(e) {
                                    img.src = e.target.result; //gán đường dẫn ảnh
                                }
                                reader.readAsDataURL(file);
    
                            }
                        </script>
                    </div>';
    }


?>