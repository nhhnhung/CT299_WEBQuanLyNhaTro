<footer class="footer py-4">
    <div class="container container123">
        <div class="row">
            <div class="col-md-3">
                <h5>Quản lý nhà trọ</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Danh sách nhà trọ của tôi</a></li>
                    <li><a href="#">Đăng ký nhà trọ mới</a></li>
                    <li><a href="#">Quản lý hợp đồng thuê</a></li>
                    <li><a href="#">Quản lý khách thuê</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Công cụ hỗ trợ</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Định giá phòng trọ</a></li>
                    <li><a href="#">Tìm kiếm khách thuê</a></li>
                    <li><a href="#">Quản lý hóa đơn</a></li>
                    <li><a href="#">Lịch sử thanh toán</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Hướng dẫn & hỗ trợ</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Câu hỏi thường gặp</a></li>
                    <li><a href="#">Hướng dẫn sử dụng hệ thống</a></li>
                    <li><a href="#">Liên hệ hỗ trợ</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Thông tin pháp lý</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Quy chế hoạt động</a></li>
                    <li><a href="#">Điều khoản dịch vụ</a></li>
                    <li><a href="#">Chính sách bảo mật</a></li>
                </ul>
            </div>
        </div>
        <div class="text-center mt-4 social-icons">
            <h5>Liên kết hệ thống</h5>
            <a href="#" class="me-3"><i class="fab fa-facebook fa-2x"></i></a>
            <a href="#" class="me-3"><i class="fab fa-twitter fa-2x"></i></a>
            <a href="#" class="me-3"><i class="fab fa-instagram fa-2x"></i></a>
            <a href="#" class="me-3"><i class="fab fa-youtube fa-2x"></i></a>
        </div>
    </div>
</footer>