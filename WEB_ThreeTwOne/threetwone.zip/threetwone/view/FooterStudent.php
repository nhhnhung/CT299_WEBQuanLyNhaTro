<footer>
    <div class="container-xl cn-footer">
        <div class="row row-main">
            <div class="col-sm-6 col-md-3 mt-4 mt-md-0">
                <h6 class="title1">VỀ THREETWONE</h6>
                <ul>
                    <li><a href="">Giới thiệu</a></li>
                    <li><a href="">Quy chế hoạt động</a></li>
                    <li><a href="">Quy định sử dụng</a></li>
                    <li><a href="">Chính sách bảo mật</a></li>
                    <li><a href="">Liên hệ</a></li>
                </ul>
            </div>
            <div class="col-sm-6 col-md-3 mt-4 mt-md-0">
                <h6 class="title1">DÀNH CHO KHÁCH HÀNG</h6>
                <ul>
                    <li><a href="">Câu hỏi thường gặp</a></li>
                    <li><a href="">Hướng dẫn đăng tin</a></li>
                    <li><a href="">Báo giá dịch vụ</a></li>
                    <li><a href="">Quy định đăng tin</a></li>
                    <li><a href="">Giải quyết khiếu nại</a></li>
                </ul>
            </div>
            <div class="col-sm-6 col-md-3 mt-4 mt-md-0">
                <h6 class="title1">PHƯƠNG THỨC THANH TOÁN</h6>
                <span><img src="../public/img/bi-cash.svg" alt="tiền mặt"></span>
                <span><img src="../public/img/bi-internet-banking.svg" alt="chuyển khoản"></span>
                <span><img src="../public/img/vnpay.png" alt="vnpay" class="img-vnpay"></span>
            </div>
            <div class="col-sm-6 col-md-3 mt-4 mt-md-0">
                <h6 class="title1">THEO DÕI THREETWONE TẠI</h6>
                <div class="brands">
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                    <a href=""><i class="fa-brands fa-youtube"></i></a>
                    <a href=""><i class="fa-brands fa-tiktok"></i></a>
                    <a href=""><i class="fa-brands fa-square-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-square-x-twitter"></i></a>
                </div>
            </div>
        </div>
        <div class="row row-second">
            <h6 class="title1">CÔNG TY TNHH 3 THÀNH VIÊN</h6>
            <span><i class="fa-solid fa-map-location-dot"></i> 123 Đường 30 Tháng 4, Phường Xuân Khánh, Quận Ninh Kiều, TP. Cần Thơ, Việt Nam</span>
        </div>
    </div>
</footer>

<!-- Lấy khung chat -->
<script src="../public/js/GetFrameChat.js"></script>
<script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>