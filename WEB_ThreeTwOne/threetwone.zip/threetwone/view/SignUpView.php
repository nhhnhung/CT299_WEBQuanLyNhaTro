<?php 

    // Hàm lấy form đăng nhập
    function getFormSignUp($action){
        return '<div class="container">
                    <div class="row">
                        <div class="box">
                            <h1 class="title" href="SignUpAccount.php">Đăng ký</h1>
                        </div>
                        <div class="box1">
                            <form action="' . $action . '" method="post" id="formSignUp" onsubmit="return checkForm()">
                                <div class="mb-3">
                                    <input class="form-control" id="name" type="text" name="name" placeholder="Họ và tên">
                                </div>
                                <div class="mb-3">
                                    <input class="form-control" id="date" type="date" name="birthday" placeholder="Ngày sinh"
                                        oninput="checkDate()">
                                    <div class="alert alert-danger" role="alert"></div>
                                </div>
                                <div class="mb-3">
                                    <input class="form-control" type="text" name="address" placeholder="Địa chỉ">
                                </div>
                                <div class="mb-3">
                                    <input class="form-control" id="email" type="email" name="email" placeholder="Email">
                                </div>
                                <div class="mb-3 sdt">
                                    <input class="form-control" id="phone" type="tel" name="phone" placeholder="Số điện thoại">
                                    <div class="alert alert-warning" role="alert"></div>
                                </div>
                                <div class="mb-3 matkhau">
                                    <input class="form-control" id="pass" type="password" name="password"
                                        placeholder="Nhập mật khẩu" oninput="checkInPut()">
                                    <i style="cursor: pointer;" class="fa-regular fa-eye icon" onclick="togglePassword()"></i>
                                    <div class="alert alert-warning" role="alert"></div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><b>Loại tài khoản</b></label>
                                    <label for="sinhvien">
                                        <input class="mark" id="sinhvien" type="radio" name="role" value="sinhvien" required>Sinh viên
                                    </label>
                                    <label for="chutro">
                                        <input class="mark" id="chutro" type="radio" name="role" value="chutro" required>Chủ trọ
                                    </label>
                                
                                </div>
                                <div class="mb-3 tong">
                                    <div class="alert alert-warning" role="alert"></div>
                                </div>
                                <div class="mb-3 btn">
                                    <input type="submit" value="Đăng ký">
                                </div>
                                <div class="mb-3 login">
                                    <p>Bạn đã có tài khoản?<a href="../controller/Login.php"> Đăng nhập ngay</a></p>
                                </div>
                            </form>
                        </div>
                        <div class="note">
                            <p class="note">
                                Qua việc đăng nhập hoặc tạo tài khoản, bạn đồng ý với các <a href="#">quy định sử dụng</a> cũng như <a href="#">chính sách bảo mật</a>
                                của chúng tôi
                            </p>
                            <p class="note copy">Bản quyền &copy 2024 - 2025 ThreetWone.com</p>
                        </div>
                    </div>
                </div>
                 <video autoplay loop muted plays-inline class="back-video">
                    <source src="../public/video/sakura.mp4" type="video/mp4">
                </video>';
    }



    // Hàm lấy thông báo lỗi email đã tồn tại khi đăng ký
    function getMessageExitEmail(){
        return '<body>
                    <div class="alert alert-danger mess" role="alert">
                        Email đã tồn tại!
                    </div>
                </body>';
    }



    // Hàm lấy form xác nhận đăng ký trong email
    function getContentConfirmSignUp($name, $birthday, $address, $email, $phone, $password, $role){
        $body = '
        <!DOCTYPE html>
        <html lang="en">
        
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                 /* Phần form xác thực */
                .form-authentic {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
        
                .box-sub {
                    background-color: #f1f1f1;
                    height: auto;
                    width: 500px;
                    position: relative;
                    border: 2px solid #3498db;
                    border-radius: 8px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
                }
        
                 .box-sub>.content {
                    position: relative;
                    bottom: 30px;
                    margin: 5px;
                }
        
        
                  .box-sub>.submit {
                    margin-left: 35%;
                    padding: 5px;
                    background-color: #3498db;
                    width: 11em;
                    border: none;
                    color: #fff;
                    font-size: 1em;
                    font-weight: 600;
                    border-radius: 8px;
                    margin-bottom: 10px;
                }
                .box-sub>.submit:hover{
                    background-color:rgb(100, 182, 236);
                    transform: scale(1.1);
                }
                 .box-sub>.input-boss {
                    border-radius: 5px;
                    width: 250px;
                    height: 23px;
                    margin-bottom: 10px;
                    border: 1px solid #3498db;
                    background-color: #ffffff;
                    outline: #3498db;
                }
                .label{
                    margin-left:5px;
                }
                
            </style>
        
        </head>
        
        <body>
            <form class="form-authentic" action="http://localhost/threetwone/controller/CreateAccount.php" method="post">
                <input type="hidden" name="name" value="' . htmlspecialchars($name) . '">
                <input type="hidden" name="birthday" value="' . htmlspecialchars($birthday) . '">
                <input type="hidden" name="address" value="' . htmlspecialchars($address) . '">
                <input type="hidden" name="email" value="' . htmlspecialchars($email) . '">
                <input type="hidden" name="phone" value="' . htmlspecialchars($phone) . '">
                <input type="hidden" name="password" value="' . htmlspecialchars($password) . '">
                <input type="hidden" name="role" value="' . htmlspecialchars($role) . '">
                <div class="box-sub">
                    <p class="content"><strong>ThreetWone</strong> xin thông báo tài khoản của bạn đã được đăng ký thành công. vui lòng click vào nút bên dưới để xác thực email của bạn. </p>
                    ';
        
                if ($role == 'chutro') {
                    $body .= '
                            <label class="label" for="boss"><b>Nhập mã số thuế:<b></label> 
                            <input class="input-boss" id="boss" type="text" name="tax_id" required placeholder="Nhập mã số thuế">
                        ';
                }
        
                $body .= '
                   <input class="submit" type="submit" value="Xác nhận đăng ký"> 
                </div>
                </body>
        
            </html>';

            return $body;
    }

?>