<?php
    function getInfoStudent($student){
        $show = '
                    <main>
                        <div class="container main">
                            <div class="row row-body">
                                 <div class="box-form">
                                    <div class="box-img">
                                        <img id="img-personnal" src="';
        if($student['avatar'] != null){
            $show .= $student['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .= '" alt="ảnh đại diện">
                                    </div>
                                    <div class="form-edit col-6 col-sm-6">
                                        <h2 class="title">THÔNG TIN CÁ NHÂN</h2>
                                        <table>
                                            <tr class="row-table">
                                                <th><i class="fa-solid fa-user"></i> Họ tên:</th>
                                                <td>' . $student["hoten"] . '</td>
                                            </tr>
        
                                            <tr class="row-table">
                                                <th><i class="fa-solid fa-cake-candles"></i> Ngày sinh:</th>
                                                <td>' . $student["ngaysinh"] . '</td>
                                            </tr>
        
                                            <tr class="row-table">
                                                <th><i class="fa-solid fa-envelope"></i> Email:</th>
                                                <td>' . $student["email"] . '</td>
                                            </tr>
        
                                            <tr class="row-table">
                                                <th><i class="fa-solid fa-location-dot"></i> Địa chỉ:</th>
                                                <td>' . $student["diachi"] . '</td>
                                            </tr>
        
                                            <tr class="row-table">
                                                <th><i class="fa-solid fa-phone"></i> Số điện thoại:</th>
                                                <td>' . $student["sdt"] . '</td>
                                            </tr>
                                        </table>
                                        
                                    ';
        return $show;
    }


    function getButtonEditInfoStudent($student){
        $show = '          <form action="EditInfoStudent.php" method="post">
                                            <input type="hidden" name="hoten" value="' . $student["hoten"] . '">
                                            <input type="hidden" name="ngaysinh" value="' . $student["ngaysinh"] . '">
                                            <input type="hidden" name="diachi" value="' . $student["diachi"] . '">
                                            <input type="hidden" name="sdt" value="' . $student["sdt"] . '">
                                            <input type="hidden" name="avatar" value="';
        if($student['avatar'] != null){
            $show .= $student['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .= '">
                                            <div class="buttons">
                                                <input type="submit" class="btn-edit" value="Chỉnh sửa thông tin">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>';
        return $show;
    }

    function getFormEditInfoStudent($info){
        return '
                <div class="container main">
                    <div class="row row-body">
                        <h2 class="title">CHỈNH SỬA THÔNG TIN CÁ NHÂN</h2>
                        <div class="box-form edit">
                            <form class="form-edit col-md-12" id="editForm" action="UpdateInfoStudent.php" method="post" enctype="multipart/form-data" onsubmit="return checkForm()">
                                <div class="box-edit">
                                     <input type="hidden" name="current_avatar" value="' . htmlspecialchars($info['avatar']) . '">
                                    <div class="box-img col-12" id="box-img">
                                        <img id="img-personnal" src="'.$info['avatar']. '" alt="ảnh đại diện" onclick="uploadAvatar()">
                                        <input type="file" name="fileToUpload" id="fileToUpload" style="display:none;"  onchange="previewAvatar(event)">
                                    </div>
                                    <div class="table-edit col-12">
                                        <div class="alert alert-warning" role="alert"></div>
                                        <div class="alert alert-warning alr1" role="alert"></div>
                                        <table >
                                            <tr class="row-table1">
                                                <th><i class="fa-solid fa-user"></i> Họ tên:</th>
                                                <td><input type="text" name="hoten" value="' . htmlspecialchars($info['hoten'] ). '"></td>
                                            </tr>
                                
                                            <tr class="row-table1">
                                                <th><i class="fa-solid fa-cake-candles"></i> Ngày sinh:</th>
                                                <td><input type="date" name="ngaysinh" value="' . htmlspecialchars($info['ngaysinh'])  . '" id="date"></td>
                                            </tr>
                                
                                            <tr class="row-table1">
                                                <th><i class="fa-solid fa-location-dot"></i> Địa chỉ:</th>
                                                <td><input type="text" name="diachi" value="' . htmlspecialchars($info['diachi'])  . '"></td>
                                            </tr>
                                
                                            <tr class="row-table1">
                                                <th><i class="fa-solid fa-phone"></i> Số điện thoại:</th>
                                                <td><input type="tel" name="sdt" value="' . htmlspecialchars($info['sdt']) . '" id="phone"></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="buttons">
                                    <button class="btn-edit" type="submit">Lưu</button>
                                </div>
                            </form>
                        </div>
                    </div>        
                </div>
                <div id="customConfirm" class="confirm-box">
                    <div class="confirm-content">
                        <p>Bạn có chắc chắn muốn upload không?</p>
                        <button class="btn cancel" onclick="closeConfirm()">Hủy</button>
                        <button class="btn confirm" onclick="UploadItem()">Có</button>
                    </div>
                </div>
        
                <div id="overlay" class="overlay"></div>
                        ';
    }

?>