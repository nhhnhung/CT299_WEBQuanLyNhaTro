<?php
    function getHeader($hoten, $sdt, $student){
        $show= '
            <header>
                <div class="container-xl">
                    <div class="row row-header1">
                        <div class="box1 col-md-4 col-sm-6 col-6">
                            <a href="Student.php"><img src="../public/img/mainLogo.png" alt="Logo ThreetWone" class="logo"></a>
                        </div>
                        <div class="col-6 text-end d-md-none">
                            <div class="menu" onclick="toggleMenuBox()">
                                <i class="fa-solid fa-bars"></i>
                                <span>Danh mục</span>
                            </div>
                        </div>
                        <div class="box2 col-md-4 col-sm-6 col-12 d-none d-md-block">
                            <div class="first-box">
                                
                            </div>
                        </div>
                        <div class="box col-md-4 col-sm-6 col-12 d-none d-md-flex">
                            <div class="avatar" onclick="toggleBoxAVT()">
                                <img id="img-avt" src="';
        if ($student['avatar'] != null) {
            $show .= $student['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .='" alt="ảnh đại diện">
                                <span class="avt-name">' . $hoten . '</span>
                                <i class="fa-solid fa-caret-down"></i>
                            </div>
                            <div class="avt-box" id="avt-box">
                                <div class="info-main">
                                    <img id="img-avt" src="';
        if ($student['avatar'] != null) {
            $show .= $student['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .= '" alt="ảnh đại diện">
                                    <div class="info-avt">
                                        <b><span class="avt-name">' . $hoten . '</span></b>
                                        <p class="avt-sdt">' . $sdt . '</p>
                                    </div>
                                </div>
                                <div class="logout" onclick="logout()">
                                    <a href="Logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a>
                                </div>
                            </div>
                            <button class="btn1"><a href="MakePost.php"><i class="fa-solid fa-pen-to-square"></i>Đăng tin</a></button>
                        </div>
                    </div>
                </div>
                <div class="container n1 d-none d-sm-flex">
                    <a href="InfoStudent.php">Thông tin cá nhân</a> <br>
                    <a href="Student.php">Trang chủ</a> <br>
                    <a href="FindRoom.php">Thuê phòng</a> <br>
                    <a href="Service.php">Dịch vụ</a> <br>
                    <a href="StudentPay.php">Thanh toán</a> <br>
                    <a href="PostNew.php">Bài đăng</a> <br>
                    <a href="RoomStay.php">Phòng ở</a> <br>
                </div>
            </header>
            <div class="row">
                <div class="menu-box" id="menu-box">
                    <div class="info-main">
                        <img id="img-avt" src="';
        if ($student['avatar'] != null) {
            $show .= $student['avatar'];
        } else {
            $show .= '../public/img/default_avartar.jpg';
        }
        $show .= '" alt="ảnh đại diện">
                        <div class="info-avt">
                            <b><span class="avt-name">' . $hoten . '</span></b>
                            <p class="avt-sdt">' . $sdt . '</p>
                        </div>
                    </div>
                    <div class="box-post">
                        <button class="btn1 btn-post"><a href="MakePost.php"><i class="fa-solid fa-pen-to-square"></i>Đăng tin</a></button>
                    </div>
                    <div class="link">
                        <ul>                      
                            <a href="InfoStudent.php"><li>Thông tin cá nhân</li></a>
                            <a href="Student.php"><li>Trang chủ</li></a>
                            <a href="FindRoom.php"><li>Thuê phòng</li></a>
                            <a href="Service.php"><li>Dịch vụ</li></a>
                            <a href="StudentPay.php"><li>Thanh toán</li></a>
                            <a href="PostNew.php">Bài đăng</a> <br>
                            <a href="RoomStay.php">Phòng ở</a> <br>
                        </ul>
                    </div>
                    <div class="logout" onclick="logout()">
                        <ul>
                            <a href=""><li><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</li></a>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="overlay" id="overlay"></div>
            <div class="hiden"></div>
            ';
        return $show;

    }
?>