<?php
function getFormRegistBoardingHouse($action) {
    return ' <div class="form-container">
                    <h2>Đăng ký nhà trọ</h2>
                    <form action="' . $action . '" method="post">
                        <input type="text" name="tennt" placeholder="Tên nhà trọ" required>
                        <input type="text" name="diachi" placeholder="Địa chỉ" required>
                        <button type="submit">Đăng ký</button>
                    </form>
                </div>';
}

function showListBoardingHouseUncomfirm($listBoardingHouseUnComfirm) {
    if($listBoardingHouseUnComfirm->num_rows > 0) {
        echo '<div class="col-md-10">';
        echo '<h1 class="title1">Xác nhận đăng ký nhà trọ</h1>';
        echo '<div class="infoheader"></div>';
        echo '<table border="1">
                        <thead>';
        echo '<tr>';
        echo '<th>Tên nhà trọ</th>';
        echo '<th>Địa chỉ</th>';
        echo '<th>Chủ trọ</th>';
        echo '<th>Thao tác</th>';
        echo '</tr>
                        </thead>';
        while($row = $listBoardingHouseUnComfirm->fetch_assoc()) {
            echo '<tr>';
            echo '<td>'.$row['ten_nt'].'</td>';
            echo '<td>'.$row['diachi'].'</td>';
            echo '<td>'.$row['hoten'].'</td>';
            echo '<td>
                            <a class="sub" href="AllowRegistBoardingHouse.php?ma_nt='.$row['ma_nt']. '">Xác nhận</a>
                            <a class="stop" href="RefuseBoardingHouse.php?ma_nt='.$row['ma_nt'] . '&email=' . $row['email'] . '">Từ chối</a>
                          </td>';
            echo '</tr>';
        }
        echo '</table>
                </div>';
    }
}

function showListBoardingHouse($listBoardingHouse){
    echo '
            <div class="container first-table">
                <div class="row row1">
                    <table class="table">
                         <thead class="text-primary headR">
                             <tr>
                                 <th style="background-color: #069679">Tên nhà trọ</th>
                                 <th style="background-color: #069679;">Địa chỉ</th>
                                 <th style="background-color: #069679;">Số lượng phòng</th>
                                 <th style="background-color: #069679;">Trạng thái</th>
                                 <th style="background-color: #069679;">Hành động</th>
                             </tr>
                         </thead>
                         <tbody>';
    foreach ($listBoardingHouse as $boardingHouse) {
        $ma_nt = $boardingHouse['ma_nt'];
        $soluongphong = $boardingHouse['soluongphong'];
        if($soluongphong >= 0) {
            echo '
                            <tr class="row-info tr-list-homestay" onclick="goToInfoHouse(' . $ma_nt . ')">
                                 <td>' . $boardingHouse['ten_nt'] . '</td>
                                 <td>' . $boardingHouse['diachi'] . '</td>
                                 <td>' . $boardingHouse['soluongphong'] . '</td>
                                 <td>' . 'Đã đăng ký kinh doanh' . '</td>
                                 <td>
                                    <button class="btn-detail"><a href="DetailBoardingHouse.php?ma_nt=' . $ma_nt . '" >Chi tiết</a></button>                             
                                 </td>
                             </tr>
                             ';
        }
    }
    echo '
                        </tbody>
                    </table>
                </div>
            </div> 
                ';

}




?>