<div class=" row main">
    <div class="header col-md-2 row col-sm-3 g-0">
        <div class="img-logo col-md-12">
            <img class="col-9" src="../public/img/mainLogo.png" alt="logo">
        </div>
        <ul class="list">
            <a href="Admin.php">
                <li>
                    Home
                </li>
            </a>
            <a href="ComfirmRegistBoardingHouse.php">
                <li class="regis">
                    Xác nhận đăng kí
                </li>
            </a>
            <a href="ModerationAdmin.php?manage=moderation">
                <li class="post">
                    Quản lý bài đăng
                </li>
            </a>
            <a href="MangeAccount.php?mange=sv">
                <li>
                    Quản lý tài khoản
                </li>
            </a>
            <a href="MangeCommission.php">
                <li>
                    Quản lý Hoa hồng
                </li>
            </a>
            <a href="">
                <li>
                    <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
                </li>
            </a>
        </ul>


    </div>