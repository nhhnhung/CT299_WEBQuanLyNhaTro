<?php 
    function getViewLogin($action){
        return '<form action="' . $action . '" method="post">
                    <div class="input-group">
                        <input type="email" name="email" required placeholder="Nhập email">
                    </div>

                    <div class="input-group">
                        <input type="password" id="password" name="password" required placeholder="Nhập mật khẩu">
                        <span class="toggle-password" onclick="togglePassword()">
                            <i class="fa-regular fa-eye"></i>
                        </span>
                    </div>

                    <div class="role-group">
                        <label><b>Loại tài khoản</b></label>
                        <label><input type="radio" name="role" value="sinhvien" required> Sinh viên</label>
                        <label><input type="radio" name="role" value="chutro" required> Chủ trọ</label>
                    </div>

                    <input type="submit" value="Đăng nhập" class="btn btn-danger">
                </form>';


    }


    function getMessageErrorLogin(){
        return '<div class="alert alert-danger mess">Đăng nhập thất bại!</div>';
    }

    function getMoreOption(){
        return '<div class="link-group">
                    <a href="ForgetPass.php">Quên mật khẩu?</a><br>
                    <a href="SignUpAccount.php">Chưa có tài khoản?</a>
                </div>
                <p class="policy-text">
                    Qua việc đăng nhập hoặc tạo tài khoản, bạn đồng ý với các 
                    <a href="#">quy định sử dụng</a> cũng như 
                    <a href="#">chính sách bảo mật</a> của chúng tôi.
                </p>
                <p class="copyright-text">Bản quyền &copy; 2025 - 2025 ThreetWone.com</p>
                ';
    }


    function getBackgroundVideo(){
        return '<video autoplay loop muted plays-inline class="back-video">
                    <source src="../public/video/sakura.mp4" type="video/mp4">
                </video>';
    }

?>