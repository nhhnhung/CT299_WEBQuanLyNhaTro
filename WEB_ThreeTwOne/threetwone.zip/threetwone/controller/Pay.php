<?php
    include '../public/helper/payMent.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['vnp_Returnurl']) && isset($_POST['vnp_TxnRef']) && isset($_POST['vnp_OrderInfo']) && isset($_POST['vnp_OrderType']) && isset($_POST['vnp_Amount'])){
        pay($_POST['vnp_Returnurl'], $_POST['vnp_TxnRef'], $_POST['vnp_OrderInfo'], $_POST['vnp_OrderType'], $_POST['vnp_Amount']);
    }

?>