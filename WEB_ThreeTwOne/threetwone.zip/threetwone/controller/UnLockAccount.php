<?php
    include '../model/Admin.php';

    if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ma_nd'])){
        unlockAccount($_GET['ma_nd']);
    }
?>