<?php 
    include '../model/Account.php';
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_POST['birthday']) && isset($_POST['address']) && isset($_POST['phone']) && isset($_POST['password']) && isset($_POST['email']) && isset($_POST['role'])){
        $name = $_POST['name'];
        $birthday = $_POST['birthday'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $passwordUser = $_POST['password'];
        $role = $_POST['role'];
        $tax_id = '';
        if($role == 'chutro'){
            $tax_id = $_POST['tax_id'];
        }
        
        if($role == 'sinhvien'){
            saveSinhVien($name, $birthday, $email, $address, $phone, $passwordUser);
            header('Location: ../controller/Login.php');

        }else if($role == 'chutro'){
            saveChuTro($name, $birthday, $email, $address, $phone, $passwordUser, $tax_id);
            header('Location: ../controller/Login.php');
        }
        
    }
?>