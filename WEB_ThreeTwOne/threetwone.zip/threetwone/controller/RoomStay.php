<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
    include '../model/BoardingHouse.php';
    include '../model/ElectricWater.php';
    include '../model/Review.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Phòng ở') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
    <link rel="stylesheet" href="../public/css/RoomStay.css">
    <!--  Nhúng file css thêm nếu cần  -->

</head>

<body>

<?php include '../view/HeaderStudent.php' ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    // phần header
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_member'])) {
        $email = $_POST['email_new_member'];
        $ma_phong = $_POST['ma_phong'];
        $ma_hd = $_POST['ma_hd'];
        $student = getDataStudentByEmail($email);
        if ($student) {
            if (isMemberOfRoom($student['ma_sv'], $ma_hd)) {
                echo '
                        <div class="alert alert-warning">
                            Người này đã là thành viên của phòng
                        </div>';
            } else {
                if (addPersonToRoom($ma_phong, $ma_hd, $student['ma_sv'])) {
                    echo '
                            <div class="alert alert-success">
                                Thêm thành công
                            </div>';
                } else {
                    echo '
                            <div class="alert alert-danger">
                                Thêm thất bại
                            </div>';
                }
            }
        } else {
            echo '
                    <div class="alert alert-warning" role="alert">
                        Không tìm thấy sinh viên
                    </div>';
        }
    }
?>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accept_invitation'])) {
        $ma_phong = $_POST['ma_phong'];
        $ma_hd = $_POST['ma_hd'];
        $ma_sv = $_POST['ma_sv'];
        acceptJoinRoom($ma_phong, $ma_hd, $ma_sv);
    }
?>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_invitation'])) {
        $ma_phong = $_POST['ma_phong'];
        $ma_hd = $_POST['ma_hd'];
        $ma_sv = $_POST['ma_sv'];
        rejectJoinRoom($ma_phong, $ma_hd, $ma_sv);
    }
?>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['exit_room'])) {
        $ma_phong = $_POST['ma_phong'];
        $ma_hd = $_POST['ma_hd'];
        $ma_sv = $_POST['ma_sv'];
        exitRoom($ma_phong, $ma_hd, $ma_sv);
    }
?>

<div class="container box-room">
    <div class="row">
        <?php
        echo '<h1>Danh sách chỗ ở</h1>';
        echo '<div class="line"></div>';
        $listRoom = getAllRoomStudentStay($_COOKIE['ma_sv']);

        foreach ($listRoom as $room) {
            echo '<div class="listroom col-md-12">';
            echo '<div class="roombox col-md-12 row">';
                echo '<div class="room1 col-md-6">';
                echo '<span><i class="fa-solid fa-clipboard"></i> Phòng số: </span>' . $room['sophong'] . '<br>';
                echo '<span><i class="fa-solid fa-house"></i> Nhà trọ: </span>' . $room['ten_nt'] . '<br>';
                echo '<span><i class="fa-solid fa-map-location-dot"></i> Địa chỉ: </span>' . $room['diachi'] . '<br>';
                echo '<span><i class="fa-solid fa-person"></i> Số người tối đa được phép: </span>' . $room['succhua'] . ' người<br>';
                echo '<div class="rate pay">';
                echo '<button  class="btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showReview(' . $room['ma_nt'] . ')">Xem đánh giá</button>';

                echo '<br><br>';
                echo '</div>';
                echo '<br>';

                $listPerson = getListPersonOfRoom($room['ma_phong']);

            echo '</div>';
                echo '<div class="room1 col-md-6">';
                if (isPersonHiring($_COOKIE['ma_sv'], $room['ma_hd'])) {
                    echo '<p class="p-title">Bạn là chủ phòng</p>';
                    if ($listPerson->num_rows <= $room['succhua']) {
                        echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">
                                <label for="email_new_member"><b>Mời bạn ở cùng: </b></label>
                                <input class="in" type="email" name="email_new_member" placeholder="Nhập email..">
                                <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">
                                <input type="hidden" name="ma_hd" value="' . $room['ma_hd'] . '">
                                <input type="hidden" name="add_member" value="add_member">
                                <input class="btn-success" type="submit" value="Thêm">
                            </form>';
                    } else {
                        echo '<p>Phòng đã đầy</p>';
                    }


                    if (isRoomNotPayElectricWater($_COOKIE['ma_sv'], $room['ma_phong'])) {
                        echo '<div class="rate pay">';
                        echo '<p>Bạn có hóa đơn tiền phòng và điện nước chưa thanh toán!<br>';
                        echo 'Bạn phải phải thanh toán hóa đơn trước khi rời phòng </p>';
                        echo '<a href="StudentPay.php" class="btn-success">Thanh toán</a>';
                        echo '</div>';
                    } else {
                        echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">
                            <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">
                            <input type="hidden" name="ma_hd" value="' . $room['ma_hd'] . '">
                            <input type="hidden" name="ma_sv" value="' . $_COOKIE['ma_sv'] . '">
                            <input type="hidden" name="exit_room" value="exitrom">
                            <input class="btn-success" type="submit" value="Rời phòng">
                        </form>';
                    }
                } else {
                    echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">
                            <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">
                            <input type="hidden" name="ma_hd" value="' . $room['ma_hd'] . '">
                            <input type="hidden" name="ma_sv" value="' . $_COOKIE['ma_sv'] . '">
                            <input type="hidden" name="exit_room" value="exitrom">
                            <input class="btn-success" type="submit" value="Rời phòng">
                        </form>';
                }
                echo '</div>';
            echo '</div>';
            echo '<div class="list-person">';
            echo '<p class="p-title">Danh sách bạn ở chung: </p>';
            echo '<table style="width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 18px; text-align: left; border-radius: 10px; overflow: hidden; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
            <tr style="background-color:rgb(19,86,19) ;color: white; text-align: center;">
                <th style="padding: 12px 15px; border: 1px solid #ddd;">Avatar</th>
                <th style="padding: 12px 15px; border: 1px solid #ddd;">Họ tên</th>
                <th style="padding: 12px 15px; border: 1px solid #ddd;">Ngày sinh</th>
                <th style="padding: 12px 15px; border: 1px solid #ddd;">SĐT</th>
                <th style="padding: 12px 15px; border: 1px solid #ddd;">Email</th>
            </tr>';
            foreach ($listPerson as $person) {
                $student = getDataStudent($person['ma_sv']);
                echo "<tr style='background-color: #f9f9f9; text-align: center;'>";
                echo "<td style='padding: 12px 15px; border: 1px solid #ddd; width: 120px;'>
                <img src='";
                if ($student['avatar'] == null) {
                    echo '../public/img/default_avartar.jpg';
                } else {
                    echo $student['avatar'];
                }
                echo "' style='width: 80px; height: 80px; object-fit: cover; border: 2px solid #ddd;'>
              </td>";
                echo "<td style='padding: 12px 15px; border: 1px solid #ddd;'>" . $student['hoten'] . "</td>";
                echo "<td style='padding: 12px 15px; border: 1px solid #ddd;'>" . date("d-m-Y", strtotime($student['ngaysinh'])). "</td>";
                echo "<td style='padding: 12px 15px; border: 1px solid #ddd;'>" . $student['sdt'] . "</td>";
                echo "<td style='padding: 12px 15px; border: 1px solid #ddd;'>" . $student['email'] . "</td>";
                echo "</tr>";
            }
            echo '</table>';
            echo '</div>';
            echo '<div class="line"></div>';

            echo '<h3>Đánh giá nhà trọ</h3>';
            echo '<form id="form-rate">
                    <input type="hidden" name="ma_nt" value="' . $room['ma_nt'] . '">
                    <input type="hidden" name="ma_nd" value="' . $_COOKIE['ma_sv'] . '">

                    <div class="rating">
                    <input type="radio" id="star5" name="so_sao" value="5"><label for="star5">★</label>
                    <input type="radio" id="star4" name="so_sao" value="4"><label for="star4">★</label>
                    <input type="radio" id="star3" name="so_sao" value="3"><label for="star3">★</label>
                    <input type="radio" id="star2" name="so_sao" value="2"><label for="star2">★</label>
                    <input type="radio" id="star1" name="so_sao" value="1"><label for="star1">★</label>
                    </div>

                    <textarea class="in" type="text" name="danh_gia" required placeholder="Nhập đánh giá"></textarea>
                    <input type="hidden" name="rate_boardinghouse" value="rate_boardinghouse">
                    <button type="submit" onclick="rateBoardingHouse()"  class="btn-success">Đánh giá</button>
                    </form>';
            echo '
            <div id="result-rating" style="display: none" class="alert alert-success" role="alert">
            </div>';

            echo ' </div>';
        }
        ?>
    </div>

    <?php
        echo '<h3>Thư mời ở cùng:</h3>';
        $listInvitation = getListInvitation($_COOKIE['ma_sv']);
        foreach ($listInvitation as $invitation) {
            echo '<div class="card col-md-6">';
            echo '<div class="card-mini">';
            $inviter = getDataStudent($invitation['ma_inviter']);
            echo '<p><b>Người mời: </b>' . $inviter['hoten'] . ' đã gửi lời mời bạn ở chung</p>';
            echo '<p><b>Email : </b>' . $inviter['email'] . '</p>';
            echo '<p><b>SDT : </b>' . $inviter['sdt'] . '</p>';

            echo '<p><b>Phòng số: </b>' . $invitation['sophong'] . '</p>';
            echo '<p><b>Nhà trọ: </b>' . $invitation['ten_nt'] . '</p>';
            echo '<p><b>Địa chỉ: </b>' . $invitation['diachi'] . '</p>';
            echo '<p><b>Giá: </b>' . $invitation['gia'] . 'VNĐ</p>';
            echo '<p><b>Số người tối đa được phép: </b>' . $invitation['succhua'] . ' người</p>';
            echo '<div class="box-action">';
            echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">
                            <input type="hidden" name="ma_phong" value="' . $invitation['ma_phong'] . '">
                            <input type="hidden" name="ma_hd" value="' . $invitation['ma_hd'] . '">
                            <input type="hidden" name="ma_sv" value="' . $invitation['ma_sv'] . '">
                            <input type="hidden" name="accept_invitation" value="accept_invitation">
                            <input class="accept" type="submit" value="Chấp nhận">
                        </form>';

            echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">
                            <input type="hidden" name="ma_phong" value="' . $invitation['ma_phong'] . '">
                            <input type="hidden" name="ma_hd" value="' . $invitation['ma_hd'] . '">
                            <input type="hidden" name="ma_sv" value="' . $invitation['ma_sv'] . '">
                            <input type="hidden" name="reject_invitation" value="reject_invitation">
                            <input class="deny" type="submit" value="Từ chối">
                        </form>';
            echo '</div>';
            echo '<br><br>';
            echo '</div>';
            echo '</div>';
        }

    ?>


</div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Đánh giá</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body">

            </div>
        </div>
    </div>
</div>

<div class="body"></div>
<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>
</body>

</html>

<script>
    function showReview(ma_nt) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("modal-body").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "ShowReview.php?ma_nt=" + ma_nt, true);
        xhttp.send();
    }

    function rateBoardingHouse() {
        event.preventDefault();
        var formData = new FormData(document.getElementById('form-rate'));
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById('result-rating').style.display = 'block';
                document.getElementById('result-rating').innerHTML = 'Đánh giá thành công';
                setTimeout(function() {
                    document.getElementById('result-rating').style.display = 'none';
                }, 3000);
            }
        };
        xhttp.open("POST", "AddReview.php");
        xhttp.send(formData);
    }

    document.addEventListener("DOMContentLoaded", function () {
        var reviewContainer = document.querySelector(".review-container");
        if (reviewContainer) {
            reviewContainer.scrollTop = reviewContainer.scrollHeight;
        }
    });



</script>