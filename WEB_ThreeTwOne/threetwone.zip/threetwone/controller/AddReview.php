<?php
    include '../model/Review.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['rate_boardinghouse'])){
        $ma_nt = $_POST['ma_nt'];
        $ma_nd = $_POST['ma_nd'];
        $so_sao = $_POST['so_sao'];
        $danh_gia = $_POST['danh_gia'];
        addReview($ma_nt, $ma_nd, $so_sao, $danh_gia);
    }
?>