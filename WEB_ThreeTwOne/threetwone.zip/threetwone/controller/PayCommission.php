<?php
    include '../public/helper/payMent.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tongtien']) && isset($_POST['hoahong'])){
        $tongtien = $_POST['tongtien'];
        $hoahong = $_POST['hoahong'];

        $vnp_TxnRef = 'hoahong-' . $hoahong . time();
        $vnp_OrderInfo = 'Thanh toán hoa hồng';
        $vnp_OrderType = 'billpayment';
        $vnp_Amount = $tongtien;
        $vnp_Returnurl = 'http://localhost/threetwone/controller/Commission.php?hoa_hong=' . $hoahong;
        pay($vnp_Returnurl, $vnp_TxnRef, $vnp_OrderInfo, $vnp_OrderType, $vnp_Amount);
    }
?>