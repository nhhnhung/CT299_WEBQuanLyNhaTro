<?php
    include '../model/BoardingHouse.php';
    include '../model/ElectricWater.php';
    include '../public/helper/checkCookieLandLord.php';
    include '../view/title_lib.php';
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib("Quản lý điện nước") ?>
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/NoteEW.css">
</head>

<body>
<?php include '../view/HeaderLandLord.php'; ?>

<?php
    if (isset($_GET['set_price_electric_water'])) {
        $ma_nt = $_GET['ma_nt'];
        $gia_dien = $_GET['gia_dien'];
        $gia_nuoc = $_GET['gia_nuoc'];
        setOrUpdatePriceElectricWater($ma_nt, $gia_dien, $gia_nuoc);
    }

    if (isset($_GET['set_electric_water'])) {
        $ma_phong = $_GET['ma_phong'];
        $ma_dgdn = $_GET['ma_dgdn'];
        $so_dien = $_GET['so_dien'];
        $so_nuoc = $_GET['so_nuoc'];
        setOrUpdateElectricWater($ma_phong, $ma_dgdn, $so_dien, $so_nuoc);
    }
?>

<div class="container main_box">
    <div class="row row-box">
        <?php
        echo '<div class="box-primary">';
        $listBoardingHouse = getAllBoardingHouseOfLandLord($_COOKIE['ma_ct']);
        foreach ($listBoardingHouse as $boardingHouse) {
            echo '<div class="house-card col-md-6">';
            echo '<h1>🏠 Thông tin nhà trọ:</h1><br>';
            echo '<div class="house-info">';
            echo '<span><b>Tên nhà trọ: </b>' . $boardingHouse['ten_nt'] . '</span><br>';
            echo '<span><b> Địa chỉ: </b>' . $boardingHouse['diachi'] . '</span><br>';
            echo '<span><b> Số lượng phòng: </b>' . $boardingHouse['soluongphong'] . ' phòng</span><br>';
            $priceElectricWater = getPriceElectricWater($boardingHouse['ma_nt'], date('m'), date('Y'));
            if ($priceElectricWater != null) {
                echo '<span><b> Giá điện: </b>' . $priceElectricWater['gia_dien']*1000 . ' VND/kW</span><br>';
                echo '<span><b> Giá nước: </b>' . $priceElectricWater['gia_nuoc']*1000 . ' VND/m<sup>3</sup></span><br>';
            } else {
                $priceElectricWater['ma_dgdn'] = -1;
                echo '<div class="not-price">';
                echo '<span> Chưa cập nhật giá điện nước tháng này !!!</span><br>';
                echo '</div>';
            }
            echo '</div>';
            echo '<h3>⚡Cập nhật lại giá điện nước</h3>
                <form method="get" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '">
                    <input class="in" type="number" name="gia_dien" min="0" placeholder="Giá điện" required>
                    <input class="in" type="number" name="gia_nuoc" min="0" placeholder="Giá nước" required>
                    <input type="hidden" name="ma_nt" value="' . $boardingHouse['ma_nt'] . '">      
                    <input type="text" name="set_price_electric_water" value="set_price_electric_water" hidden>        
                    <input class="save" type="submit" value="Lưu">
                </form>            
                ';
            echo '</div>';

            $listRoom = getAllRoomOfBoardingHouse($boardingHouse['ma_nt']);
            if($boardingHouse['soluongphong']!=0){
                echo '<h1>Thông tin phòng:</h1><br>';
            }

            foreach ($listRoom as $room) {
                echo '<div  class="room-info card">';
                $tien_phong = getPriceRoom($room['ma_phong'])['gia']*1000;
                echo '<span class="room-number"><b> Phòng số: ' . $room['sophong'] . '</b><br>Giá: '.$tien_phong.' VNĐ</span><br>';
                $electricWaterBefore = getElectricWater($room['ma_phong'], BeforeMonth(date('m')), date('Y'));
                echo '<div class="line"></div>';
                echo '<div  class="room-card row">';
                echo '<div  class="col-md-4 box-money">';
                echo '<span>Tháng trước:</span><br>';
                if ($electricWaterBefore != null) {
                    echo '<span>Chỉ số điện: ' . $electricWaterBefore['chiso_dien'] . '</span><br>';
                    echo '<span>Chỉ số nước: ' . $electricWaterBefore['chiso_nuoc'] . '</span><br>';
                } else {
                    echo '<span>Chưa ghi điện nước phòng này</span><br>';
                }
                echo '</div>';


                $electricWater = getElectricWater($room['ma_phong'], date('m'), date('Y'));
                echo '<div  class="col-md-4 box-money">';
                echo '<span>Tháng này:</span><br>';
                if ($electricWater != null) {
                    echo '<span>Chỉ số điện: ' . $electricWater['chiso_dien'] . '</span><br>';
                    echo '<span>Chỉ số nước: ' . $electricWater['chiso_nuoc'] . '</span><br>';
                } else {
                    echo '<span> Chưa ghi điện nước phòng này</span><br>';
                }
                echo '</div>';


                if ($electricWater != null && $electricWaterBefore != null) {
                    echo '<div  class="col-md-4 box-money">';
                    echo '<span>Thành tiền: </span><br>';
                    $tien_phong = getPriceRoom($room['ma_phong'])['gia'];
                    $tien_dien = ($electricWater['chiso_dien'] - $electricWaterBefore['chiso_dien']) * $priceElectricWater['gia_dien']*1000;
                    $tien_nuoc = ($electricWater['chiso_nuoc'] - $electricWaterBefore['chiso_nuoc']) * $priceElectricWater['gia_nuoc']*1000;
                    echo 'Tiền điện: ' . $tien_dien . '<br>';
                    echo 'Tiền nước: ' . $tien_nuoc . '<br>';
                    echo '</div>';
                    echo '<div class="line"></div>';
                    echo '<div class="last-box">';
                    echo '<span>Tổng tiền: <b>' . ($tien_phong + $tien_dien + $tien_nuoc) . ' VNĐ</b></span><br>';
                    if ($electricWater['trangthai_thanhtoan'] == null) {
                        echo '<span style="color: tomato;">Chưa thanh toán ❌</span><br>';
                    } else {
                        echo '<span style="color: green;">Đã thanh toán ✅</span><br>';
                    }
                    echo '</div>';
                }
                if ($electricWater == null) {
                    echo '<div class="box-form">';
                    echo '<form class="form" method="get" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '">
                            <h4>Chỉ số điện nước tháng này</h4>
                            <input class="in" type="number" name="so_dien" min="0" placeholder="Số điện" required>
                            <input class="in" type="number" name="so_nuoc" min="0" placeholder="Số nước" required>
                            <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">
                            <input type="hidden" name="ma_dgdn" value="' . $priceElectricWater['ma_dgdn'] . '">
                            <input type="text" name="set_electric_water" value="set_electric_water" hidden>               
                            <input class="save" type="submit" value="Lưu">
                        </form>
                        </div>
                        ';
                }
                echo '<br><br>';
                echo '</div>';
                echo '</div>';
            }
            echo '<br><br><br><br>';
        }
        echo '</div>';
        ?>
    </div>
</div>
<?php include '../view/FooterLandLord.php'; ?>
</body>

</html>