<?php
    include '../public/helper/checkCookieLandLord.php';
    include '../view/title_lib.php';
    include '../model/Device.php';
    include '../view/DeviceView.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Thiết bị') ?>
    <!-- Nhúng thêm CSS nếu cần -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/DeviceLac.css">
</head>

<body class="device-page">
<?php include '../view/HeaderLandLord.php'; ?>

<div class="device-container">
    <h2 class="device-title">Thêm thiết bị</h2>
    <div class="device-form-wrapper">
        <?php echo getFormAddDevice('DeviceAdd.php'); ?>
        <?php
            if(isset($_GET['errorExist'])){
                echo '
                <div class="alert alert-warning al-w" role="alert">
                  Thiết bị đã tồn tại
                </div>';
            }
        ?>
    </div>

    <div class="device-table-wrapper">
        <?php
            $devices = getAllDevice();
            showListDevice($devices);
        ?>
    </div>
</div>

<?php include '../view/FooterLandLord.php'; ?>
<script>
    // Hàm upload ảnh
    function uploadAvatar() {
        document.getElementById("fileToUpload").click();
    }


    //Hàm hiển thị ảnh trước khi upload
    function previewAvatar(event) {
        const img = document.getElementById("imgInput");
        const file = event.target.files[0]; //lấy file ảnh
        const reader = new FileReader(); //đọc file
        reader.onload = function(e) {
            img.src = e.target.result; //gán đường dẫn ảnh
        }
        reader.readAsDataURL(file);

    }

    const al = document.querySelector('.al-w');
    if(al){
        setTimeout(() => {
            al.style.display = 'none';
        }, 3000);
    }
</script>
</body>

</html>