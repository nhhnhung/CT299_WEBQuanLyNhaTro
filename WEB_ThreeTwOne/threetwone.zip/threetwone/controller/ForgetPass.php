<?php 
    include '../public/helper/sendEmail.php';
    include '../model/Account.php';
    include '../view/title_lib.php';
    include '../view/ForgetPassView.php';


    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])){
        $email = $_POST['email'];

        if(checkEmail($email) == false){
            echo getMessageNonExitEmail();
        }else{
            $subject = 'Đặt lại mật khẩu';
            $body = getFormResetPass($email);
            send_email($subject, $body, $email);
        }
    }
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Quên mật khẩu') ?>
    <link rel="stylesheet" href="../public/css/stylemn.css">
</head>
<body>
    <?php echo getFormForgetPass(htmlspecialchars($_SERVER['PHP_SELF'])) ?>
    <?php echo getBackgroundVideo() ?>
    <script src="../public/js/Login.js"></script>
</body>
</html>