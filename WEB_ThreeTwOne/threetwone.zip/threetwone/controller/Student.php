<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Trang chủ Sinh Viên') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
    <link rel="stylesheet" href="../public/css/style1.css">
    <!--  Nhúng file css thêm nếu cần  -->

</head>

<body>

<?php include '../view/HeaderStudent.php' ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    // phần header
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>


<div class="body">
    <section class="slidermn">
        <div class="container">
            <div class="slider-contentmn">
                <div class="slider-content-left">
                    <div class="slider-content-left-top-container">
                        <div class="slider-content-left-top">
                            <a href="#"><img src="../public/img/img1.jpg" width="840px" height="320px"></a>
                            <a href="#"><img src="../public/img/img2.jpg" width="840px" height="320px"></a>
                            <a href="#"><img src="../public/img/img3.webp" width="840px" height="320px"></a>
                            <a href="#"><img src="../public/img/img4.jpg" width="840px" height="320px"></a>
                        </div>

                        <div class="slider-content-left-top-btn">
                            <i class="fa-solid fa-chevron-left"></i>
                            <i class="fa-solid fa-chevron-right"></i>
                        </div>
                    </div>

                    <div class="slider-content-left-bottom">
                        <li class="active">Khuyến mãi hot</li>
                        <li>Trang web uy tín</li>
                        <li>Lưu ý cần biết</li>
                        <li >Thiết kế hiện đại</li>
                    </div>
                </div>
                <div class="slider-content-right">
                    <li><a href="#"><img src="../public/img/pic1.png" ></a></li>
                    <li><a href="#"><img src="../public/img/pic2.jpg" ></a></li>
                    <li><a href="#"><img src="../public/img/pic3.jpg" ></a></li>
                    <li><a href="#"><img src="../public/img/pic4.jpg" ></a></li>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="../public/js/script1.js"></script>
<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>
</body>

</html>