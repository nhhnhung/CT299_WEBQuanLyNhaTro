<?php
    include '../model/BoardingHouse.php';
    include '../model/Device.php';
    include '../controller/AddImgs.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['price']) && isset($_POST['capacity']) && isset($_POST['area-room']) && isset($_POST['ma_nt']) && isset($_POST['devices'])) {
        $price = $_POST['price']/1000;
        $capacity = $_POST['capacity'];
        $area_room = $_POST['area-room'];
        $ma_nt = $_POST['ma_nt'];
        $devices = $_POST['devices'];
        $quantity_device = $_POST['quantity-device'];
        $imgs = uploadImgs();
        addRoomType($price, $capacity, $area_room, $ma_nt, $imgs);

        $ma_lp = getRoomType($price, $capacity, $area_room, $ma_nt)['ma_lp'];
        for ($i = 0; $i < $quantity_device; $i++) {
            $ma_tb = $devices[$i];
            $quantity = $_POST['quantity-' . $ma_tb];
            if ($quantity == 0) continue;
            addDeviceOfRoomType($ma_lp, $ma_tb, date('Y-m-d'), $quantity, true);
        }
        header('Location: DetailBoardingHouse.php?ma_nt=' . $ma_nt);
    }

?>