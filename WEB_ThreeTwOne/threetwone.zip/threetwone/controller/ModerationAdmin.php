<?php
    session_start();
    include '../public/helper/checkSessionAdmin.php';
    include '../view/title_lib.php';
    include '../model/Posts.php';
?>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['allow_post'])) {
        $ma_bd = $_POST['ma_bd'];
        allowPost($ma_bd);
        header('Location: ModerationAdmin.php?manage=moderation');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_post'])) {
        $ma_bd = $_POST['ma_bd'];
        rejectPost($ma_bd);
        header('Location: ModerationAdmin.php?manage=moderation');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_post'])) {
        $ma_bd = $_POST['ma_bd'];
        deletePost($ma_bd);
        header('Location: ModerationAdmin.php?manage=delete_or_block');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['block_comment'])) {
        $ma_bd = $_POST['ma_bd'];
        blockCommentByAdmin($ma_bd);
        header('Location: ModerationAdmin.php?manage=delete_or_block');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['unblock_comment'])) {
        $ma_bd = $_POST['ma_bd'];
        unblockCommentByAdmin($ma_bd);
        header('Location: ModerationAdmin.php?manage=delete_or_block');
    }

?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib("Duyệt bài đăng") ?>
    <link rel="stylesheet" href="../public/css/headerAdmin.css">
    <link rel="stylesheet" href="../public/css/ComfirmRegistBH.css">
    <link rel="stylesheet" href="../public/css/postnew.css">
    <!-- Đính kèm thêm css nếu có   -->
</head>

<body>
<?php include '../view/HeaderAdmin.php'; ?>
<?php
    if(isset($_GET['manage']) && $_GET['manage'] == 'moderation') {
        echo '<div class="col-md-10 col-sm-9">';
        echo '<h1 class="title1">Duyệt bài đăng</h1>';
        echo '<div class="infoheader"></div>';
        echo '<div class="col-md-10 box-btn">
            <a class="btn btn-primary m-2" href="ModerationAdmin.php?manage=moderation">Duyệt bài</a>
            <a class="btn btn-primary m-2" href="ModerationAdmin.php?manage=delete_or_block">Xóa hoặc khóa bình luận</a>
            </div>';
        $listPost = getAllPostNotModeration();
        echo '<div class="card-post col-10 row">';
        foreach ($listPost as $post) {
            if ($post['ngaydang'] == null) {
                echo '<div class="card col-md-5 col-12">';
                echo '<div class="mini-card">';
                echo '<span><i class="fa-solid fa-user"></i> Người đăng: </span> ' . $post['hoten'] . '<br>';
                echo '<span><i class="fa-regular fa-envelope"></i> Email: </span>' . $post['email'] . '<br>';
                echo '<span><i class="fa-solid fa-pen-to-square"></i> Nội dung bài đăng: </span><br>' . $post['noidungbd'] . '<br>';
                if (!empty($post["url_images"])) {
                    echo '<div class="box-imgs"';
                        $imagePaths = explode(",", $post["url_images"]);
                        foreach ($imagePaths as $imagePath) {
                            echo '<img class="item-img" src="' . $imagePath . '" alt="Hình ảnh bài đăng">';
                        }
                    echo '</div>';
                }
                echo '<div class="btn-action">';
                echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                            <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                            <input type="hidden" name="allow_post" value="allow_post">
                            <input class="btn accept" type="submit" name="submit" value="Duyệt bài">                                      
                          </form>';

                echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                            <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                            <input type="hidden" name="reject_post" value="reject_post">  
                            <input class="btn deny" type="submit" name="submit" value="Từ chối">                                     
                          </form>';
                echo '</div>';
                echo '<br><br><br>';
                echo '</div>';
                echo '</div>';
            }

        }
        echo '</div>';
        echo '</div>';
    }else if(isset($_GET['manage']) && $_GET['manage'] == 'delete_or_block') {
        echo '<div class="col-md-10 col-sm-9">';
        echo '<h1 class="title1">Xóa hoặc khóa bình luận</h1>';
        echo '<div class="infoheader"></div>';
        echo '<div class="col-md-10 box-btn">
            <a class="btn btn-primary m-2" href="ModerationAdmin.php?manage=moderation">Duyệt bài</a>
            <a class="btn btn-primary m-2" href="ModerationAdmin.php?manage=delete_or_block">Xóa hoặc khóa bình luận</a>
            </div>';
        $listPost = getAllPost();
        echo '<div class="card-post col-10 row">'; // Chỉnh hàng ngang giữa trang

        foreach ($listPost as $post) {
            if ($post['ngaydang'] != null) {
                echo '<div class="col-md-5 col-12 mb-4">'; // Định dạng cột với khoảng cách giữa các bài
                echo '<div class="card p-3 shadow">'; // Thêm padding và shadow để dễ nhìn hơn
                echo '<div class="mini-card">';
                echo '<span><i class="fa-solid fa-user"></i> Người đăng: </span> ' . $post['hoten'] . '<br>';
                echo '<span><i class="fa-regular fa-envelope"></i> Email: </span>' . $post['email'] . '<br>';
                echo '<span><i class="fa-solid fa-pen-to-square"></i> Nội dung bài đăng: </span><br>' . $post['noidungbd'] . '<br>';
                if (!empty($post["url_images"])) {
                    echo '<div class="box-imgs"';
                    $imagePaths = explode(",", $post["url_images"]);
                    foreach ($imagePaths as $imagePath) {
                        echo '<img class="item-img" src="' . $imagePath . '" alt="Hình ảnh bài đăng">';
                    }
                    echo '</div>';
                }
                if ($post['khoa_bl'] == 'user_block') {
                    echo '<p class="text-danger mt-3">Bình luận đã bị khóa bởi người dùng</p>';
                }

                echo '<div class="btn-action flex-column gap-2 mt-3">'; // Tạo khoảng cách giữa các nút
                echo '<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showComment(' . $post['ma_bd'] . ')">Xem bình luận</button>';

                echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                        <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                        <input type="hidden" name="delete_post" value="delete_post">
                        <input class="btn btn-danger" type="submit" name="submit" value="Xóa bài">                                      
                    </form>';


                if ($post['khoa_bl'] == null) {
                    echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                            <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                            <input type="hidden" name="block_comment" value="block_comment">  
                            <input class="btn btn-warning" type="submit" name="submit" value="Khóa bình luận">                                     
                        </form>';
                } else if ($post['khoa_bl'] == 'admin_block') {
                    echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                            <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                            <input type="hidden" name="unblock_comment" value="unblock_comment">  
                            <input class="btn btn-success" type="submit" name="submit" value="Mở khóa bình luận">                                     
                        </form>';
                }else if($post['khoa_bl'] == 'user_block'){
                    echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                            <input type="hidden" name="ma_bd" value="' . $post['ma_bd'] . '">
                            <input type="hidden" name="block_comment" value="block_comment">  
                            <input class="btn btn-warning" type="submit" name="submit" value="Khóa bình luận bởi admin">                                     
                        </form>';
                }

                echo '</div>'; // Đóng btn-action
                echo '</div>'; // Đóng mini-card
                echo '</div>'; // Đóng card
                echo '</div>'; // Đóng col-md-5
            }
        }

        echo '</div>'; // Đóng row
        echo '</div>'; // Đóng col-md-10

    }
?>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Bình luận</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body"></div>
        </div>
    </div>
</div>

<script>
    function showComment(ma_bd) {
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById('modal-body').innerHTML = `
                <div class="comment-container custom-scroll" id="comment-container-${ma_bd}">
                    ` + this.responseText + `
                </div>`;
            }
        };
        xhttp.open("GET", "fetch_comments.php?ma_bd=" + ma_bd);
        xhttp.send();
    }


    // ẩn ảnh
    function showAllImages(postId) {
        // Hiển thị tất cả ảnh bị ẩn
        let hiddenImages = document.querySelectorAll('.post-' + postId);
        hiddenImages.forEach(img => img.style.display = 'block');

        // Ẩn nút "+X"
        let extraButton = document.querySelector('#post-images-' + postId + ' .extra-images');
        if (extraButton) {
            extraButton.style.display = 'none';
        }

        // Thêm nút "Thu gọn"
        let collapseButton = document.createElement('div');
        collapseButton.className = 'collapse-images';
        collapseButton.innerText = 'Thu gọn';
        collapseButton.onclick = function () {
            hideExtraImages(postId);
        };

        // Thêm vào cuối danh sách ảnh
        document.querySelector('#post-images-' + postId).appendChild(collapseButton);
    }


    function hideExtraImages(postId) {
        // Ẩn tất cả ảnh dư
        let hiddenImages = document.querySelectorAll('.post-' + postId);
        hiddenImages.forEach(img => img.style.display = 'none');

        // Hiển thị nút "+X" lại
        let extraButton = document.querySelector('#post-images-' + postId + ' .extra-images');
        if (extraButton) {
            extraButton.style.display = 'flex';
        }

        // Xóa nút "Thu gọn"
        let collapseButton = document.querySelector('#post-images-' + postId + ' .collapse-images');
        if (collapseButton) {
            collapseButton.remove();
        }
    }
</script>

</body>

</html>