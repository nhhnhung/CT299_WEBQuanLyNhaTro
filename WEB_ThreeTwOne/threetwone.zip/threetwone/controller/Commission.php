<?php
    include '../model/BoardingHouse.php';
    include '../view/title_lib.php';
?>

<?php
    if(isset($_GET['vnp_ResponseCode']) && $_GET['vnp_ResponseCode'] == '00') {
        $hoa_hong = $_GET['hoa_hong'];
        $hoa_hong = explode('-', $hoa_hong);
        foreach ($hoa_hong as $ma_hoahong) {
            updateStatusCommision($ma_hoahong);
        }
        echo '<div class="alert alert-success text-center" role="alert">Thanh toán hoa hồng thành công</div>';
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <title>Danh sách hoa hồng</title>
    <link rel="stylesheet" href="../public/css/Commit.css">
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
</head>
<body>
<?php include '../view/HeaderLandLord.php'; ?>
<div class="container mt-4">
    <h1 class="text-center text-primary">Danh sách hoa hồng chưa thanh toán</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-hover text-center">
            <thead class="table-dark">
            <tr>
                <th>Tên nhà trọ</th>
                <th>Địa chỉ</th>
                <th>Số phòng</th>
                <th>Người đại diện</th>
                <th>Email</th>
                <th>Ngày ký hợp đồng</th>
                <th>Thành tiền</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $listCommisson = getListCommision($_COOKIE['ma_ct']);
                $tongtien = 0;
                $hoahong = '';
                while ($row = mysqli_fetch_array($listCommisson)) {
                    $thanhtien = $row['tylephantram'] * $row['sotien'] * 1000 / 100;
                    $tongtien += $thanhtien;
                    $hoahong .= $row['ma_hoahong'] . '-';
                    echo "<tr>
                                        <td>{$row['ten_nt']}</td>
                                        <td>{$row['diachi']}</td>
                                        <td>{$row['sophong']}</td>
                                        <td>{$row['hoten']}</td>
                                        <td>{$row['email']}</td>
                                        <td>{$row['ngayky']}</td>
                                        <td>" . number_format($thanhtien, 0, ',', '.') . " VND</td>
                                      </tr>";
                }
            ?>
            </tbody>
        </table>
    </div>
    <h2 class=" text-success">Tổng tiền: <?php echo number_format($tongtien, 0, ',', '.'); ?> VND</h2>
    <form method="post" action="PayCommission.php" class="text-center">
        <input type="hidden" name="tongtien" value="<?php echo $tongtien; ?>">
        <input type="hidden" name="hoahong" value="<?php echo $hoahong; ?>">
        <button type="submit" class="btn btn-primary btn-lg" name="redirect">Thanh toán</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../public/js/Login.js"></script>
<?php include '../view/FooterLandLord.php'; ?>
</body>
</html>
