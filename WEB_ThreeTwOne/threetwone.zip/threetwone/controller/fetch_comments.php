<?php
    include '../model/Posts.php';

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $ma_bd = $_GET['ma_bd'];
        $result = getAllCommentOfPost($ma_bd);

        foreach ($result as $row) {
            echo '<div class="comment-box">
                        <div class="comment-header">
                            <img src="' . $row['avatar'] . '" alt="Avatar" class="comment-avatar">
                            <span class="comment-name">' . $row['hoten'] . '</span>
                        </div>
                        <div class="comment-content">' . $row['noidungbl'] . '</div>
                        <div class="comment-time">' . $row['thoigianbl'] . '</div>
                      </div>';
        }

        $isBlockComment = isBlockComment($ma_bd);
        if($isBlockComment){
            echo '
                <div class="alert alert-danger block-comment" id="block-comment">
                    Bình luận đã bị khóa
                </div>';
        }

    }
?>
