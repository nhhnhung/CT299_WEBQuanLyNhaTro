<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
    include '../model/BoardingHouse.php';
    include '../model/LandLord.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Thuê phòng') ?>
    <link rel="stylesheet" href="../public/css/FindRoom.css">
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <!--  Nhúng file css thêm nếu cần  -->
    <!-- Nhúng thư viện jquery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

</head>

<body>
<?php include '../view/HeaderStudent.php' ?>
<?php
$ma_sv = $_COOKIE['ma_sv'];
$student = getDataStudent($ma_sv);
// phần header
echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<?php
echo '<div class="container box-main">';
echo '<div class="row">';
echo '
         <form method="get" action="search.php" class="first-box col-md-12">
            <input id="searchInput" name="search" class="box-search col-md-9" type="text" placeholder="Nhập từ khóa, diện tích, giá hoặc khoảng giá(vd: 500-1500)" maxlength ="30">
            <input class="rate col-md-2" type="submit" value="Tìm kiếm">
            <div id="suggestions" class="col-md-9"></div>
        </form>
                    ';

echo '</div>';
$listLandLord = getAllLandLord();
while ($landlord = $listLandLord->fetch_assoc()) {
    $dataLandLord = getDataLandLord($landlord['ma_nd']);
    $listBoardingHouse = getAllBoardingHouseOfLandLord($landlord['ma_ct']);
    while ($boardingHouse = $listBoardingHouse->fetch_assoc()) {
        $dataBoardingHouse = getDataBoardingHouse($boardingHouse['ma_nt']);
        $listRoomType = getListRoomType($boardingHouse['ma_nt']);
        while ($roomType = $listRoomType->fetch_assoc()) {
            $listRoom = getListRommOfRoomType($roomType['ma_lp']);
            echo '<div class="row">';
            echo '<div class="col-md-12">';
            echo '<div class="card">';
            echo '<div class="card-header">';
            echo '<h3>Thông tin phòng trọ</h3>';
            echo '</div>';
            echo '<div class="card-body">';
            echo '<div class="row">';
            echo '<div class="col-md-6 infoBoss">';
            echo '<h4>Thông tin chủ trọ</h4>';
            echo '<p>Họ tên: ' . $dataLandLord['hoten'] . '</p>';
            echo '<p>Số điện thoại: ' . $dataLandLord['sdt'] . '</p>';
            echo '<button class="rate" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showReview(' . $roomType['ma_nt'] . ')">Xem đánh giá</button>';
            if ($roomType['imgs'] != null) {
                $imgs = explode(",", $roomType['imgs']);
                echo '<div class="col-md-12 imgs-box">';
                foreach ($imgs as $img) {
                    echo '<img class="col-sm-5 col-md-5 imgs" src="' . $img . '" alt="ảnh nhà trọ">';
                }
                echo '</div>';
            }
            echo '</div>';
            echo '<div class="col-md-6 infoHouse">';
            echo '<h4>Thông tin nhà trọ</h4>';
            echo '<p>Tên nhà trọ: ' . $dataBoardingHouse['ten_nt'] . '</p>';
            echo '<p>Địa chỉ: ' . $dataBoardingHouse['diachi'] . '</p>';
            echo '<p>Giá phòng: ' . $roomType['gia'] *1000 . ' VNĐ</p>';
            echo '<p>Sức chứa: ' . $roomType['succhua'] . ' người</p>';
            echo '<p>Diện tích: ' . $roomType['dientich'] . ' m <sup>2</sup></p>';

            echo '<div id="map_' . $dataBoardingHouse['ma_nt'] . '" class="map-container" data-address="' . $dataBoardingHouse['diachi'] . '"></div>';

            echo '</div>';
            echo '</div>';
            echo '<div class="row">';
            echo '<div class="col-md-12">';
            echo '<div class="line"></div>';
            echo '<h4>Danh sách phòng</h4>';
            echo '<table class="table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th class="number">Số của phòng</th>';
            echo '<th>Thuê phòng</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            if ($listRoom->num_rows == 0) {
                echo '<tr>';
                echo '<td class="exception" colspan="3">Chưa có phòng</td>';
                echo '</tr>';
            }
            while ($room = $listRoom->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $room['sophong'] . '</td>';
                if (checkOccupiedRoom($room['ma_phong'])) {
                    echo '<td>Phòng đã được thuê</td>';
                } else if (checkRegisted($_COOKIE['ma_sv'], $room['ma_phong'])) {
                    echo '<td>Đã đăng ký vui lòng chờ phản hồi từ chủ trọ</td>';
                } else if (checkWaitingPaymentForRoom($_COOKIE['ma_sv'], $room['ma_phong'])) {
                    echo '<td  class="td-pay"><p>Đã đăng ký thành công vui lòng thanh toán tiền cọc</p> <a class="btn_pay" href="StudentPay.php">Thanh toán</a></td>';
                } else {
                    echo '<td>';
                    echo '<form method="get" action="RegistrationForm.php">';
                    echo '<input type="hidden" name="name_landlor" value="' .  $dataLandLord['hoten'] . '">';
                    echo '<input type="hidden" name="phone_landlor" value="' .  $dataLandLord['sdt'] . '">';
                    echo '<input type="hidden" name="name_boarding_house" value="' .  $dataBoardingHouse['ten_nt'] . '">';
                    echo '<input type="hidden" name="address_boarding_house" value="' .  $dataBoardingHouse['diachi'] . '">';
                    echo '<input type="hidden" name="price" value="' .  $roomType['gia'] . '">';
                    echo '<input type="hidden" name="capacity" value="' .  $roomType['succhua'] . '">';
                    echo '<input type="hidden" name="area_room" value="' .  $roomType['dientich'] . '">';
                    echo '<input type="hidden" name="so_phong" value="' .  $room['sophong'] . '">';

                    echo '<input type="hidden" name="ma_phong" value="' .  $room['ma_phong'] . '">';
                    echo '<input type="hidden" name="ma_sv" value="' .  $_COOKIE['ma_sv'] . '">';
                    echo '<input type="hidden" name="ma_ct" value="' .  $landlord['ma_ct'] . '">';
                    echo '<button type="submit" class="btn btn-rent">Thuê phòng</button>';
                    echo '</form>';
                    echo '</td>';
                }
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '<br><br>';
        }
    }
}
echo '</div>';
?>

<div class="body"></div>
<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Đánh giá</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body">

            </div>
        </div>
    </div>
</div>


<script>
    function showReview(ma_nt) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("modal-body").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "ShowReview.php?ma_nt=" + ma_nt, true);
        xhttp.send();
    }
</script>
<!-- Phần gợi ý -->
<script>
    $(document).ready(function() {
        $("#searchInput").on("keyup", function() {
            let query = $(this).val();
            if (query.length > 1) {
                $.ajax({
                    url: "suggest.php",
                    type: "GET",
                    data: {
                        query: $("#searchInput").val()
                    },
                    dataType: "json", // Ép kiểu JSON
                    success: function(results) {
                        let suggestionBox = $("#suggestions");
                        suggestionBox.empty().show();
                        if (results.length === 0) {
                            suggestionBox.append("<div class='suggestion-item'>Không tìm thấy</div>");
                        } else {
                            results.forEach(item => {
                                suggestionBox.append(`<div class='suggestion-item'>${item}</div>`);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("Lỗi AJAX:", error);
                    }
                });
            } else {
                $("#suggestions").hide();
            }
        });

        // Chọn gợi ý
        $(document).on("click", ".suggestion-item", function() {
            $("#searchInput").val($(this).text());
            $("#suggestions").hide();
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var maps = document.querySelectorAll(".map-container");

        maps.forEach(function(mapDiv) {
            var address = mapDiv.getAttribute("data-address");

            // Tọa độ mặc định Cần Thơ
            var defaultLat = 10.045162;
            var defaultLng = 105.746857;

            // Khởi tạo bản đồ mặc định ở Cần Thơ
            var map = L.map(mapDiv).setView([defaultLat, defaultLng], 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);

            // Marker mặc định ở Cần Thơ
            var marker = L.marker([defaultLat, defaultLng]).addTo(map)
                .bindPopup("Cần Thơ").openPopup();

            // Nếu có địa chỉ thì tìm tọa độ trong phạm vi Cần Thơ
            if (address) {
                let url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}` +
                    `&viewbox=105.6,10.2,106.0,9.9&bounded=1`; // Giới hạn tìm trong Cần Thơ

                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        if (data.length > 0) {
                            var latitude = parseFloat(data[0].lat);
                            var longitude = parseFloat(data[0].lon);

                            map.setView([latitude, longitude], 15); // Di chuyển tới vị trí đúng
                            marker.setLatLng([latitude, longitude]) // Cập nhật vị trí marker
                                .bindPopup(address).openPopup();
                        } else {
                            console.error("Không tìm thấy tọa độ trong Cần Thơ cho: " + address);
                        }
                    })
                    .catch(error => console.error("Lỗi lấy tọa độ:", error));
            }
        });
    });
</script>
</body>

</html>