<?php
    include '../public/helper/payMent.php';
?>

<?php

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['vnp_TxnRef']) && isset($_POST['vnp_OrderInfo']) && isset($_POST['vnp_OrderType']) && isset($_POST['vnp_Amount']) && isset($_POST['ma_phong'])){
        $ma_sv = $_COOKIE['ma_sv'];
        $ma_phong = $_POST['ma_phong'];
        $vnp_TxnRef = $_POST['vnp_TxnRef'];
        $vnp_OrderInfo = $_POST['vnp_OrderInfo'];
        $vnp_OrderType = $_POST['vnp_OrderType'];
        $vnp_Amount = $_POST['vnp_Amount'];
        $vnp_Returnurl = 'http://localhost/threetwone/controller/ResultPayDeposit.php?ma_hd=' . $vnp_TxnRef . '&tongtien=' . $vnp_Amount . '&ma_phong=' . $ma_phong . '&ma_sv=' . $ma_sv;
        $vnp_TxnRef .= '-' . time();
        pay($vnp_Returnurl, $vnp_TxnRef, $vnp_OrderInfo, $vnp_OrderType, $vnp_Amount);
    }else{
        header('Location: http://localhost/threetwone/controller/StudentPay.php');
    }

?>