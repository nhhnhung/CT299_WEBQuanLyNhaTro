<?php
    header('Content-Type: application/json');
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    include '../db/open.php';
    include '../model/BoardingHouse.php';

if (isset($_GET['query'])) {
    $search = $_GET['query'];
    // Truy vấn tìm kiếm
    $result = getDataSearchHouse($search);
    if (!$result) {
        echo json_encode(["error" => "Lỗi truy vấn SQL hoặc không có dữ liệu"]);
        exit;
    }
    $suggestions = [];
    while ($row = $result->fetch_assoc()) {
        if(is_numeric($search)){
            if($search > 100){
                if(!in_array($row['gia'], $suggestions)){
                    $suggestions[] = $row['gia'];
                }
            }else{
                if (!in_array($row['dientich'], $suggestions)) {
                    $suggestions[] = $row['dientich'];
                }
            }
        }else{
            if(strpos(mb_strtolower($row['ten_nt']), mb_strtolower($search)) !== false){
                if (!in_array($row['ten_nt'], $suggestions)) {
                    $suggestions[] = $row['ten_nt'];
                }
            }else if(strpos(mb_strtolower($row['diachi']), mb_strtolower($search)) !== false){
                if (!in_array($row['diachi'], $suggestions)) {
                    $suggestions[] = $row['diachi'];
                }
            }
        }

    }

    echo json_encode($suggestions, JSON_UNESCAPED_UNICODE);
}

    include '../db/close.php';
?>