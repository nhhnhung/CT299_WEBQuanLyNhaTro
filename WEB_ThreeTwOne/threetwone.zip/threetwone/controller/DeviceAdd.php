<?php
    include '../public/helper/checkCookieLandLord.php';
    include '../model/Device.php';
    include '../controller/AddImgDevice.php';


    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tenthietbi'])){
        $tenthietbi = $_POST['tenthietbi'];
        if(isExitDevice($tenthietbi)){
            header('Location: Device.php?errorExist=true');
        }else{
            addDevice($tenthietbi, UploadImg());
            header('Location: Device.php');
        }
    }
?>