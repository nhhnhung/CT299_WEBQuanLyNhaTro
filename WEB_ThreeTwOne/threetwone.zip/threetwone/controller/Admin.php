<?php
    session_start();
    include '../public/helper/checkSessionAdmin.php';
    include '../view/title_lib.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib("Admin") ?>
    <link rel="stylesheet" href="../public/css/headerAdmin.css">
    <link rel="stylesheet" href="../public/css/ComfirmRegistBH.css">
    <!-- Đính kèm thêm css nếu có   -->
</head>
<body>
    <?php include '../view/HeaderAdmin.php'; ?>

</body>
</html>

<!-- http://localhost/threetwone/controller/LoginAdmin.php -->

