<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Service.php';
    include '../view/ServiceView.php';
    include '../model/Student.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Xác nhận thanh toán dịch vụ') ?>
    <!-- Mỗi trang cần file khác nhau nên import thủ công -->
    <link rel="stylesheet" href="../public/css/stylelac.css">
    <link rel="stylesheet" href="../public/css/header_footer.css">
</head>
<body>
    <?php include '../view/HeaderStudent.php'; ?>
    <?php
        $ma_sv = $_COOKIE['ma_sv'];
        $student = getDataStudent($ma_sv);
        echo getHeader($student['hoten'], $student['sdt'], $student);
    ?>

    <?php
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $listService = [];
            $vpn_Amount = 0;
            $vnp_OderType = 'Thanh toán dịch vụ';
            $vnp_OderInfo ='';
            $vnp_TxnRef = $_COOKIE['ma_sv'] . time();
            $vnp_Returnurl = 'http://localhost/threetwone/controller/ResultPayment.php?';

            foreach($_GET as $key => $value){
                if($value > 0 && $key != 'ma_phong'){
                    $service = getServiceById($key);
                    $service['soluong'] = $value;
                    $listService[$key] = $service;

                    $vpn_Amount += $service['gia'] * $service['soluong'];
        //                    $vnp_OderInfo .= $service['ma_dv'] . 'x' . $service['soluong'] . '_';
                    $vnp_OderInfo .= $service['ma_dv'] . '=' . $service['soluong'] . '&';
                }
            }
            $vnp_OderInfo .= 'ma_phong=' . $_GET['ma_phong'];
            $vnp_Returnurl .= $vnp_OderInfo;
            $vnp_OderInfo = 'Thanh toán dịch vụ cho sinh viên ' . $_COOKIE['ma_sv'];

            // Hiển thị danh sách dịch vụ đã chọn
            showAllServiceBooked($listService);
            echo '<div class="container text-center mt-4">';
            echo '    <div class="total-price p-3 rounded">Tổng tiền: <span>' . number_format($vpn_Amount, 0, ',', '.') . ' VND</span></div>';
            echo '</div>';

            echo getFormPayService('Pay.php', $vnp_Returnurl, $vnp_TxnRef, $vnp_OderInfo, $vnp_OderType, $vpn_Amount);
        }

        ?>

    <?php include '../view/FooterStudent.php'; ?>
    <script src="../public/js/InfoStudent.js"></script>
</body>
</html>
