<!doctype html>
<html lang="en">
<head>
    <?php
        include('../view/title_lib.php');
        setTitleAndImportLib('Đăng xuất');
    ?>
</head>
<body>

</body>
</html>

<?php
    setcookie('ma_sv', null, time() - 3600, '/');
    setcookie('ma_ct', null, time() - 3600, '/');
    setcookie('hoten', null, time() - 3600, '/');
    setcookie('sdt', null, time() - 3600, '/');
    header('Location: Login.php');
?>