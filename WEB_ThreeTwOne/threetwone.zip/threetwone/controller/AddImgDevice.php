<?php
    function UploadImg(){
        // Phần upload ảnh
        // Kiểm tra nếu có file upload
        if (isset($_FILES["fileToUpload"]) && !empty($_FILES["fileToUpload"]["name"])) {
            $folder = "../public/imgDevice/";
            $last_str = pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION);
            $file = $folder . "img" .uniqid().".".$last_str; //đánh tên theo chuỗi dài tự nhiên

            $imageFileType = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $isUpload = 1;

            // Kiểm tra file có phải ảnh không
            if (isset($_POST["submit"])) {
                $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                $isUpload = $check !== false ? 1 : 0;
            }

            // Kiểm tra định dạng ảnh
            if (!in_array($imageFileType, ["jpg", "png", "jpeg", "gif"])) {
                echo "Chỉ hỗ trợ JPG, PNG, JPEG, GIF.";
                $isUpload = 0;
            }

            // Nếu mọi thứ hợp lệ, tiến hành upload
            if ($isUpload && move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) {
                $img = $file;
            } else {
                echo "Lỗi khi upload file.";
                $img = isset($_POST['current_img']) ? $_POST['current_img'] : "../public/img/default_avartar.jpg";
            }
        } else {
            $img = isset($_POST['current_img']) ? $_POST['current_img'] : "../public/img/default_avartar.jpg";
        }
        return $img;
    }

?>