<?php
    include '../model/Account.php';
    include '../public/helper/sendEmail.php';
    include '../view/title_lib.php';
    include '../view/SignUpView.php';
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Đăng ký') ?>
    <link rel="stylesheet" href="../public/css/SignUp.css">
    <link rel="stylesheet" href="../public/css/together.css">
</head>

<body>
    <?php echo getFormSignUp(htmlspecialchars($_SERVER["PHP_SELF"])) ?>
    <script src="../public/js/SignUp.js"></script>
</body>

</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_POST['birthday']) && isset($_POST['address']) && isset($_POST['phone']) && isset($_POST['password']) && isset($_POST['email']) && isset($_POST['role'])) {
    $name = $_POST['name'];
    $birthday = $_POST['birthday'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $check = checkEmail($email);

    if ($check == true) {
        echo getMessageExitEmail();
    } else {
        $subject = 'Xác nhận email đăng ký tài khoản';
        $body = getContentConfirmSignUp($name, $birthday, $address, $email, $phone, $password, $role);

        send_email($subject, $body, $email);
    }
}


?>

<!-- Link check :  http://localhost/threetwone/controller/SignUpAccount.php -->