<?php
    session_start();
    include '../view/title_lib.php';
    include '../model/checkAdmin.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['key'])) {
        $key = $_POST['key'];
        if (check($key)) {
            $_SESSION['admin'] = $key;
            header('Location: Admin.php');
        } else {
            echo '
            <div class="alert alert-danger" id="note">
                Key không hợp lệ
            </div>';
        }
    }
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib("Admin") ?>
    <link rel="stylesheet" href="../public/css/LoginAdmin.css">
    <!-- Đính kèm thêm css nếu có   -->
</head>

<body>
<div class="container">
    <div class="row main">
        <div class="col-md-6 box" id="box">
            <h2 class="title2">Đăng nhập Admin</h2>
            <form id="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
                <input type="text" name="key" placeholder="Key" required>
                <button id="btn" type="submit">Xác thực</button>
            </form>
        </div>
    </div>
</div>
<script src="../public/js/LoginAD.js"></script>
</body>

</html>