<?php
    include '../model/BoardingHouse.php';
    include '../model/LandLord.php';
    include '../model/ElectricWater.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
?>
<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Trang thanh toán') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
    <link rel="stylesheet" href="../public/css/StudentPay.css">
    <!--  Nhúng file css thêm nếu cần  -->

</head>

<body>

<?php include '../view/HeaderStudent.php' ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    // phần header
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<?php
    if (isset($_GET['ma_phong']) && isset($_GET['ma_dgdn']) && isset($_GET['tong_tien']) && isset($_GET['vnp_ResponseCode']) == '00') {
        $ma_phong = $_GET['ma_phong'];
        $ma_dgdn = $_GET['ma_dgdn'];
        $tong_tien = $_GET['tong_tien'];
        updateElectricWater_AfterPay($ma_phong, $ma_dgdn);
        echo '<script>alert("Thanh toán điện nước và tiền phòng thành công")</script>';
    }
?>


<div class="container">
    <div class="row">
        <?php
        echo '<h2>Danh sách phòng chưa thanh toán cọc</h2>';
        $listRoom = getListRoomNotDeposit($_COOKIE['ma_sv']);
        if ($listRoom->num_rows == 0) {
            echo '<p class="null">Không có phòng nào chưa thanh toán cọc</p>';
        } else {
            echo '<table class="table col-md-12">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Tên nhà trọ</th>';
            echo '<th>Địa chỉ</th>';
            echo '<th>Số phòng</th>';
            echo '<th>Giá</th>';
            echo '<th>Sức chứa</th>';
            echo '<th>Diện tích</th>';
            echo '<th>Đếm ngược tới hẹn</th>';
            echo '<th>Thanh toán cọc</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            while ($room = $listRoom->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $room['ten_nt'] . '</td>';
                echo '<td>' . $room['diachi'] . '</td>';
                echo '<td>' . $room['sophong'] . '</td>';
                echo '<td>' . $room['gia'] * 1000 . '</td>';
                echo '<td>' . $room['succhua'] . '</td>';
                echo '<td>' . $room['dientich'] . '</td>';
                echo '<td class="countdown" data-time="' . $room['ngayhen'] . '"></td>';
                echo '<form action="PayDeposit.php" method="post">                           
                    <input type="hidden" name="vnp_TxnRef" value="' . $room['ma_hd'] . '">
                    <input type="hidden" name="vnp_OrderInfo" value="Thanh toán cọc tháng đầu-' . $room['ten_nt'] . '-' . $room['sophong'] . '">            
                    <input type="hidden" name="vnp_OrderType" value="billpayment">
                    <input type="hidden" name="vnp_Amount" value="' . $room['gia'] * 1000 . '"> 
                    <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">      
                    <td><button type="submit" name="redirect" class="btn btn-primary">Thanh toán cọc tháng đầu</button></td>  
                 </form>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        }
        ?>
    </div>


    <?php
    echo '<h2>Danh sách phòng chưa thanh toán tiền điện nước và tiền phòng </h2>';
    $listRoom_notPay_ElectricWater = getListRoom_NotPay_ElectricWater($_COOKIE['ma_sv']);
    if ($listRoom_notPay_ElectricWater->num_rows == 0) {
        echo '<p class="null">Không có phòng nào chưa thanh toán tiền điện nước</p>';
    } else {
        foreach ($listRoom_notPay_ElectricWater as $room) {
            $priceElectricWater = getPriceElectricWater($room['ma_nt'], date('m'), date('Y'));
            echo '<div class="card">';
                echo '<div class="card-mini row">';
                echo '<h2 class="h2-title">THÔNG BÁO THU ĐIỆN NƯỚC</h2>';
                echo '<p class="h2-title" >Tháng: ' . date('m') . '/' . date('y') . '</p>';
                echo '<div class="box-price">';
                echo '<span><b> Phòng số: ' . $room['sophong'] . '</b></span><br>';
                echo '<span><b> Tên nhà trọ: ' . $room['ten_nt'] . '</b></span><br>';
                echo '<span><b> Địa chỉ: ' . $room['diachi'] . '</b></span><br><br>';
                $tien_phong = getPriceRoom($room['ma_phong'])['gia'];
                $tien_phong *= 1000;
                echo '<span><b>Tiền phòng: ' . $tien_phong . '</b></span><br>';
                echo '<span>Đơn vị: VNĐ</span><br>';


                echo '</div>';
                echo '<div class="line"></div>';

                echo '<div class="col-md-2 col-sm-2 box-tb">';
                echo '<span>Sử dụng</span>';
                echo '<span>Điện</span>';
                echo '<span>Nước</span>';
                echo '</div>';
                $electricWaterBefore = getElectricWater($room['ma_phong'], BeforeMonth(date('m')), date('Y'));
                echo '<div class="col-md-2 col-sm-2 box-tb">';
                echo '<span>Tháng trước</span>';
                if ($electricWaterBefore != null) {
                    echo '<span>' . $electricWaterBefore['chiso_dien'] . '</span>';
                    echo '<span>' . $electricWaterBefore['chiso_nuoc'] . '</span>';
                } else {
                    echo '<span>Chưa ghi điện nước phòng này</span><br>';
                }
                echo '</div>';
                echo '<br>';

                $electricWater = getElectricWater($room['ma_phong'], date('m'), date('Y'));
                echo '<div class="col-md-2 col-sm-2 box-tb">';
                echo '<span>Tháng này</span>';
                if ($electricWater != null) {
                    echo '<span>' . $electricWater['chiso_dien'] . '</span>';
                    echo '<span>' . $electricWater['chiso_nuoc'] . '</span>';
                } else {
                    echo '<span> Chưa ghi điện nước phòng này</span><br>';
                }
                echo '</div>';

                if ($electricWater != null && $electricWaterBefore != null) {
                    echo '<div class="col-md-2 col-sm-2 box-tb">';
                    echo '<span>Tiêu Thụ</span>';
                    $tt_dien = ($electricWater['chiso_dien'] - $electricWaterBefore['chiso_dien']);
                    $tt_nuoc = ($electricWater['chiso_nuoc'] - $electricWaterBefore['chiso_nuoc']);
                    echo '<span>' . $tt_dien . '</span>';
                    echo '<span>' . $tt_nuoc . '</span>';
                    echo '</div>';

                    echo '<div class="col-md-2 col-sm-2 box-tb">';
                    echo '<span>Đơn giá</span>';
                    if ($priceElectricWater != null) {
                        echo '<span>' . $priceElectricWater['gia_dien'] * 1000 . '</span>';
                        echo '<span>' . $priceElectricWater['gia_nuoc'] * 1000 . '</span>';
                    } else {
                        $priceElectricWater['ma_dgdn'] = -1;
                        echo '<span> Chưa cập nhật giá điện nước tháng này !!!</span><br>';
                    }
                    echo '</div>';



                    echo '<div class="col-md-2 col-sm-2 box-tb">';
                    echo '<span>Tổng tiền</span>';
                    $tien_dien = ($electricWater['chiso_dien'] - $electricWaterBefore['chiso_dien']) * $priceElectricWater['gia_dien'];
                    $tien_nuoc = ($electricWater['chiso_nuoc'] - $electricWaterBefore['chiso_nuoc']) * $priceElectricWater['gia_nuoc'];


                    $tien_dien *= 1000;
                    $tien_nuoc *= 1000;

                    echo '<span>' . $tien_dien . '</span>';
                    echo '<span>' . $tien_nuoc . '</span>';
                    echo '</div>';
                    echo '<div class="line"></div>';
                    echo '<div class="box-sum">';
                    echo '<span>Tổng tiền: <b>' . ($tien_phong + $tien_dien + $tien_nuoc) . ' VNĐ</b></span><br>';
                    if ($electricWater['trangthai_thanhtoan'] == null) {
                        echo '<span>Chưa thanh toán</span><br>';
                    } else {
                        echo '<span>Đã thanh toán</span><br>';
                    }

                    echo '<form method="post" action="PayElectricWater.php">
                        <input type="hidden" name="ma_phong" value="' . $room['ma_phong'] . '">
                        <input type="hidden" name="ma_dgdn" value="' . $room['ma_dgdn'] . '">
                        <input type="hidden" name="tong_tien" value="' . ($tien_phong + $tien_dien + $tien_nuoc) . '">
                        <button type="submit" name="redirect" class="pay">Thanh toán</button>
                      </form>';

                    echo '</div>';
            }
            echo '</div>';
            echo '</div>';
        }
    }
    ?>
</div>
<div class="body"></div>
<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>

<script src="../public/js/StudentPay.js"></script>

<script>
    function startCountdown() {
        document.querySelectorAll(".countdown").forEach((element, index) => {
            let time = element.getAttribute("data-time") + " 00:00:00"; // Lấy ngày hẹn
            let appointmentDate = new Date(time).getTime();
            let timer;

            function updateCountdown() {
                let now = new Date().getTime();
                let timeLeft = appointmentDate - now;

                if (timeLeft <= 0) {
                    element.innerHTML = "Đã đến ngày hẹn!";
                    clearInterval(timer);
                    return;
                }

                let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
                let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

                element.innerHTML = `${days} ngày ${hours} giờ ${minutes} phút ${seconds} giây`;
            }

            updateCountdown(); // Cập nhật ngay khi load trang
            timer = setInterval(updateCountdown, 1000);
        });
    }

    startCountdown();
</script>
</body>

</html>