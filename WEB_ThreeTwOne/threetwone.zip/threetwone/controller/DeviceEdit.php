<?php
    ob_start();
    include '../public/helper/checkCookieLandLord.php';
    include '../view/title_lib.php';
    include '../model/Device.php';
    include '../view/DeviceView.php';
    include '../controller/AddImgDevice.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Sửa thiết bị') ?>
    <link rel="stylesheet" href="../public/css/DeviceEdit.css">
    <!-- Nhúng thêm css nếu cần   -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
</head>

<body>
<?php include '../view/HeaderLandLord.php'; ?>

<?php
    $ma_tb = $_GET['ma_tb'];
    $device = getDevice($ma_tb);
?>

<?php
    echo getFormEditDevice('DeviceEdit.php', $device);
?>

<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $ma_tb = $_POST['ma_tb'];
        $tenthietbi = $_POST['tenthietbi'];
        $oldImg = $_POST['current_img'];
        if (file_exists($oldImg)) {
            if($oldImg != "../public/img/default_avartar.jpg"){
                unlink($oldImg);
            }
        }
        updateDevice($ma_tb, $tenthietbi, UploadImg());
        header("Location: Device.php");
        exit();
    }
?>

<?php include '../view/FooterLandLord.php'; ?>
<?php ob_end_flush(); ?>

<script>
    // Hàm upload ảnh
    function uploadAvatar() {
        document.getElementById("fileToUpload").click();
    }


    //Hàm hiển thị ảnh trước khi upload
    function previewAvatar(event) {
        const img = document.getElementById("imgInput");
        const file = event.target.files[0]; //lấy file ảnh
        const reader = new FileReader(); //đọc file
        reader.onload = function(e) {
            img.src = e.target.result; //gán đường dẫn ảnh
        }
        reader.readAsDataURL(file);

    }

</script>
</body>

</html>