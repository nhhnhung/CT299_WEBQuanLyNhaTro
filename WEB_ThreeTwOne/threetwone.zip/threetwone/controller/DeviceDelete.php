<?php
    include '../public/helper/checkCookieLandLord.php';
    include '../model/Device.php';

    $ma_tb = $_GET['ma_tb'];
    // Xóa file
    $img = $_GET['img'];
    if(file_exists($img)){
        if($img != "../public/img/default_avartar.jpg"){
            unlink($img);
        }
    }

    deleteDevice($ma_tb);
    header('Location: Device.php');
?>