<?php
session_start();
include '../public/helper/checkSessionAdmin.php';
include '../view/title_lib.php';
include '../model/Admin.php';
include '../public/helper/sendEmail.php';
?>



<?php
if(isset($_POST['remind'])){
    $email = $_POST['email'];
    send_email('Nhắc nhở thanh toán hoa hồng', 'Phòng trọ của bạn đã được thanh toán tiền cọc tháng đầu tiên, hãy thanh toán hoa hồng dựa trên thỏa thuận ban đầu của web và bạn', $email);
}

if(isset($_POST['percent'])){
    $percent = $_POST['percent'];
    $percent = (float)$percent;
    updateCommision($percent);
}
?>


<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib("Admin") ?>
    <link rel="stylesheet" href="../public/css/MangeCommit.css">
    <link rel="stylesheet" href="../public/css/style.css">
    <link rel="stylesheet" href="../public/css/headerAdmin.css">
</head>
<body>
<?php include '../view/HeaderAdmin.php'; ?>
<div class="container1 col-md-10">
    <h1 class="title1">Sửa tỷ lệ phần trăm hoa hồng</h1>
    <div class="infoheader"></div>
    <div class="form-container">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="w-50">
            <div class="input-group">
                <input type="number" class="form-control" min="0" max="100" name="percent" placeholder="Nhập tỷ lệ phần trăm" required>
                <button style="margin-left: 5px" type="submit" class="btn btn-primary btn2">Sửa</button>
            </div>
        </form>
    </div>

    <h1>Quản lý hoa hồng</h1>
    <table class="table table-bordered table-hover text-center">
        <thead class="table-dark">
        <tr>
            <th>Tên nhà trọ</th>
            <th>Địa chỉ</th>
            <th>Số phòng</th>
            <th>Giá</th>
            <th>Tỷ lệ phần trăm</th>
            <th>Số tiền</th>
            <th>Trạng thái thanh toán</th>
            <th>Chủ trọ</th>
            <th>Nhắc nhở</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $commitsions = getAllCommision();
        foreach ($commitsions as $commitsion) {
            $status = $commitsion['trangthai'];
            if($status == null)
                $status = 'Chưa thanh toán';
            else if($status == 'yes')
                $status = 'Đã thanh toán';
            echo "<tr>
                            <td>{$commitsion['ten_nt']}</td>
                            <td>{$commitsion['diachi']}</td>
                            <td>{$commitsion['sophong']}</td>
                            <td>" . number_format($commitsion['gia'] * 1000) . " VND</td>
                            <td>{$commitsion['tylephantram']}%</td>
                            <td>" . number_format($commitsion['sotien'] * 10) . " VND</td>
                            <td>{$status}</td>
                            <td>{$commitsion['email']}</td>";
            if ($status == 'Chưa thanh toán') {
                echo "<td>
                                <form method='post' action='" . htmlspecialchars($_SERVER['PHP_SELF']) . "'>
                                    <input type='hidden' name='email' value='{$commitsion['email']}'>
                                    <button type='submit' class='btn btn-warning' name='remind'>Nhắc nhở</button>
                                </form>
                            </td>";
            } else {
                echo "<td>-</td>";
            }
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>


<script src="../public/js/Login.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.querySelector("form[action='<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>']");
        const submitButton = form.querySelector("button[type='submit']");

        submitButton.addEventListener("click", function (event) {
            const confirmAction = confirm("Bạn có chắc chắn muốn sửa tỷ lệ phần trăm hoa hồng không?");
            if (!confirmAction) {
                event.preventDefault(); // Ngăn chặn form gửi đi nếu người dùng nhấn Hủy
            }
        });
    });

</script>
</body>
</html>

