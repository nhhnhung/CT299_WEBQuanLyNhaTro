<?php
    include '../model/BoardingHouse.php';

    if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['numberOfroom']) && isset($_GET['ma_nt']) && isset($_GET['ma_lp'])){
        $numberOfroom = $_GET['numberOfroom'];
        $ma_nt = $_GET['ma_nt'];
        $ma_lp = $_GET['ma_lp'];
        if(checkExitRoom($ma_nt, $numberOfroom)){
            header('Location: DetailBoardingHouse.php?ma_nt='.$ma_nt.'&exitRoomError=1&ma_lp='.$ma_lp);
        }else{
            addRoom($numberOfroom, $ma_nt, $ma_lp);
            header('Location: DetailBoardingHouse.php?ma_nt='.$ma_nt);
        }
    }
?>