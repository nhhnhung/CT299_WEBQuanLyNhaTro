<?php
    include '../public/helper/checkCookieLandlord.php';
    include '../view/title_lib.php';
    include '../model/LandLord.php';
    include '../view/InfoLandLordView.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Trang chủ Chủ trọ') ?>
    <!--  Nhúng file css thêm nếu cần  -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/Info.css">
</head>
<body>
    <?php include '../view/HeaderLandLord.php' ?>

    <?php
        $ma_ct = $_COOKIE['ma_ct'];
        $landlord = getDataLandLord($ma_ct);
        echo getInfoLandLord($landlord);
        echo getButtonEditInfoLandLord($landlord);
    ?>

    <?php include '../view/FooterLandLord.php' ?>
</body>
</html>
