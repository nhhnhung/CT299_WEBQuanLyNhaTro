<?php
    include '../model/Admin.php';

    if($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["ma_nd"])){
        $ma_nd = $_GET["ma_nd"];
        lockAccount($ma_nd);
    }
?>