<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
    include '../view/InfoStudentView.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Thông tin sinh viên') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/InfoStudent.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <!--  Nhúng file css thêm nếu cần  -->
</head>
<body>
    <?php include '../view/HeaderStudent.php';?>

    <?php
        $ma_sv = $_COOKIE['ma_sv'];
        $student = getDataStudent($ma_sv);
        // phần header
        echo getHeader($student['hoten'], $student['sdt'], $student);


        echo getInfoStudent($student);
        echo getButtonEditInfoStudent($student);
    ?>

    <?php include '../view/FooterStudent.php'?>

    <script src="../public/js/InfoStudent.js"></script>
</body>
</html>
