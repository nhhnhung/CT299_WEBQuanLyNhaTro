<?php
    include '../public/helper/checkCookieLandlord.php';
    include '../view/title_lib.php';
    include '../model/BoardingHouse.php';
    include '../view/BoardingHouseView.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Quản lý nhà trọ') ?>
    <link rel="stylesheet" href="../public/css/ManagerBoardingHouse.css">
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <!--  Nhúng file css thêm nếu cần  -->
</head>
<body>
    <?php include '../view/HeaderLandLord.php' ?>

    <?php
        $listBoardingHouse = getAllBoardingHouseOfLandLord($_COOKIE['ma_ct']);
        showListBoardingHouse($listBoardingHouse);
    ?>

    <div class="d-flex justify-content-center">
        <a href="RegistBoardingHouse.php" class="btn btn-primary">Đăng ký nhà trọ</a>
    </div>



    <?php include '../view/FooterLandLord.php' ?>
    <script src="../public/js/ManagerHouse.js"></script>
</body>
</html>
