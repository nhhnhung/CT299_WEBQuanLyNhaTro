<?php
    include '../model/Admin.php';

    if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ma_nt'])) {
        allowRegistBoardingHouse($_GET['ma_nt']);
        header('Location: ComfirmRegistBoardingHouse.php');
    }
?>