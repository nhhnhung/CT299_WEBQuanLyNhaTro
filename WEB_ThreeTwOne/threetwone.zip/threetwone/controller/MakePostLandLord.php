<?php
include '../model/Posts.php';
include '../view/title_lib.php';
?>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['block_comment'])){
        $ma_bd = $_POST['ma_bd'];
        blockCommentByUser($ma_bd);
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['unblock_comment'])){
        $ma_bd = $_POST['ma_bd'];
        unblockCommentByUser($ma_bd);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_post'])) {
        $ma_bd = $_POST['ma_bd'];
        deletePost($ma_bd);
    }
?>


<!-- Phần xử lý upload ảnh -->
<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['make_post'])) {
        $ma_nd = $_POST['ma_nd'];
        $noidungbd = $_POST['noidungbd'];
        $uploadDir = "../public/imgPost/";
        $imagePaths = [];

        foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
            $originalName = $_FILES["images"]["name"][$key];
            $extension = pathinfo($originalName, PATHINFO_EXTENSION);
            $newFileName = uniqid("img_", true) . "." . $extension;
            $file = $uploadDir . $newFileName;

            if (move_uploaded_file($tmp_name, $file)) {
                $imagePaths[] = $file;
            }
        }

        if (!empty($imagePaths)) {
            $imagePathsString = implode(",", $imagePaths); // Nối chuỗi ảnh bằng dấu phẩy
            addPost($ma_nd, $noidungbd,$imagePathsString);
        }else{
            //Trường hợp không có ảnh
            $imagePathsString = null;
            addPost($ma_nd, $noidungbd, $imagePathsString);
        }
    }
?>


<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Bài Đăng') ?>
    <!--  Nhúng file css thêm nếu cần  -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/Makepost.css">
</head>
<body>

<?php include '../view/HeaderLandLord.php' ?>

<?php
    echo '<h1 class="text-primary text-center mt-4">Tạo bài đăng</h1>';
    $ma_nd = $_COOKIE['ma_ct'];
    echo '<div class="container">
                <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post" enctype="multipart/form-data" class="card p-3 shadow-sm">
                    <p class="fw-bold">Upload hình ảnh bài đăng</p>
                    <input type="file" name="images[]" multiple class="form-control mb-2">
                    <textarea name="noidungbd" placeholder="Nội dung" class="form-control mb-2" rows="3"></textarea>
                    <input type="hidden" name="ma_nd" value="' . $ma_nd . '">
                    <button type="submit" name="submit" class="btn btn-primary w-100 ">Đăng bài</button>
                    <input type="hidden" name="make_post" value="make_post">
                </form>
            </div>';

    $listPost = getAllPostOfUser($ma_nd);
    echo '<h1 class="text-primary text-center mt-4">Danh sách bài đăng của tôi</h1>';
    echo '<div class="container">';

    while ($row = $listPost->fetch_assoc()) {
        echo '<div class="card p-3 shadow-sm mt-3">';

        if ($row['ngaydang'] == NULL) {
            echo '<p class="text-warning">Thời gian đăng: Bài đăng chưa được duyệt</p>';
        } else {
            echo '<p class="text-muted">Thời gian đăng: ' . $row['ngaydang'] . '</p>';
        }

        echo '<div class="post">
                <p class="fw-bold">Nội dung bài đăng:</p>
                <p class="card-text">' . $row['noidungbd'] . '</p>              
              </div>';

        if (!empty($row["url_images"])) {
            $imagePaths = explode(",", $row["url_images"]);
            echo '<div class="post-images d-flex flex-wrap">';
            foreach ($imagePaths as $image) {
                echo '<img src="' . trim($image) . '" alt="Hình ảnh bài đăng" class="img-thumbnail m-1" style="max-width: 200px;">';
            }
            echo '</div>';
        }

        echo '<div class="d-flex justify-content-between mt-3">
                <form action="EditPost.php" method="post" class="d-inline">
                    <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                    <input type="hidden" name="img" value="' . $row['url_images'] . '">
                    <input type="hidden" name="edit_post" value="edit_post">
                    <input type="hidden" name="role" value="ct">
                    <button type="submit" name="submit" class="btn btn-outline-primary">Sửa bài</button>
                </form>
        
                <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post" class="d-inline">
                    <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                    <input type="hidden" name="delete_post" value="delete_post">  
                    <button type="submit" name="submit" class="btn btn-outline-danger">Xóa bài</button>
                </form>
              </div>';

        if($row['khoa_bl'] == 'user_block'){
            echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                <input type="hidden" name="unblock_comment" value="unblock_comment">  
                <button type="submit" name="submit" class="btn btn-outline-primary mt-3">Mở khóa bình luận</button>
              </form>';
        }else if($row['khoa_bl'] == null){
            echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                <input type="hidden" name="block_comment" value="block_comment">  
                <button type="submit" name="submit" class="btn btn-outline-danger mt-3">Khóa bình luận</button>
              </form>';
        }

        if($row['khoa_bl'] == 'admin_block'){
            echo '<p class="text-danger mt-3">Bình luận đã bị khóa bởi quản trị viên</p>';
        }

        echo '</div>';
    }
    echo '</div>';

?>


<?php include '../view/FooterLandLord.php' ?>

</body>
</html>