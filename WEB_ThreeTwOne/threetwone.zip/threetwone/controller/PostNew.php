<?php
    include '../model/Posts.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <title>Bài đăng</title>
    <link rel="stylesheet" href="../public/css/postnew.css">
    <?php echo setTitleAndImportLib('Trang chủ Sinh Viên'); ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
</head>

<body>

<?php include '../view/HeaderStudent.php'; ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<?php
    $listPosts = getAllPost();
    foreach ($listPosts as $post_item) {
        echo '<div class="post-container">';
        echo '<div class="post-header">';
        echo '<img src="' . $post_item['avatar'] . '" alt="Avatar">';
        echo '<div><strong>' . $post_item['hoten'] . '</strong> - ' . $post_item['ngaydang'] . '</div>';
        echo '</div>';

        echo '<div class="post-content">' . nl2br($post_item['noidungbd']) . '</div>';

        if (!empty($post_item["url_images"])) {
            $imagePaths = explode(",", $post_item["url_images"]);
            $totalImages = count($imagePaths);

            // Xác định class bố cục dựa trên số lượng ảnh
            $layoutClass = "";
            if ($totalImages == 1) {
                $layoutClass = "one-image";
            } elseif ($totalImages == 2) {
                $layoutClass = "two-images";
            } elseif ($totalImages == 3) {
                $layoutClass = "three-images";
            } elseif ($totalImages >= 4) {
                $layoutClass = "four-images";
            }

            echo '<div class="post-images ' . $layoutClass . '" id="post-images-' . $post_item['ma_bd'] . '">';

            for ($i = 0; $i < min(4, $totalImages); $i++) {
                echo '<img src="' . trim($imagePaths[$i]) . '" alt="Hình ảnh bài đăng">';
            }

            // Nếu có hơn 4 ảnh, hiển thị nút "+X"
            if ($totalImages > 4) {
                echo '<div class="extra-images" onclick="showAllImages(' . $post_item['ma_bd'] . ')">+' . ($totalImages - 4) . '</div>';
            }

            // Ẩn các ảnh còn lại
            for ($i = 4; $i < $totalImages; $i++) {
                echo '<img src="' . trim($imagePaths[$i]) . '" alt="Hình ảnh bài đăng" class="hidden-img post-' . $post_item['ma_bd'] . '">';
            }

            echo '</div>';
        }


        echo '<div class="post-actions">';
        echo '<button data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showComment(' . $post_item['ma_bd'] . ')">Bình luận</button>';
        echo '</div>';

        echo '</div>'; // Đóng div post-container
    }
?>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Bình luận</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body"></div>
        </div>
    </div>
</div>

<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>



<script>
    function showComment(ma_bd) {
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById('modal-body').innerHTML = `
                <div class="comment-container custom-scroll" id="comment-container-${ma_bd}">
                    ` + this.responseText + `
                </div>
                <form method="post" class="comment-form"  id="commentForm"  onsubmit="return addComment(event, ` + ma_bd + `)">
                    <input type="hidden" name="ma_bd" value="` + ma_bd + `">
                    <input type="hidden" name="ma_nd" value="<?php echo $ma_sv ?>">
                    <input type="hidden" name="img" value="<?php echo $student['avatar'] ?>">
                    <input type="hidden" name="hoten" value="<?php echo $student['hoten'] ?>">

                    <div class="comment-input-container">
                        <img src="<?php echo $student['avatar'] ?>" class="comment-avatar">
                        <textarea name="noidungbl" class="comment-input" placeholder="Nhập bình luận..." required></textarea>
                        <button type="button" class="comment-submit" onclick="addComment(event, ` + ma_bd + `)">Gửi</button>
                    </div>
                </form>
            `;
                // Kiểm tra nếu có thông báo khóa thì ẩn form bình luận
                const block = document.getElementById('block-comment');
                if (block !== null) {
                    let box = document.getElementById('commentForm'); // Chọn đúng form mới tạo
                    if (box) {
                        box.classList.add('noneFormComment');
                    }
                }
            }
        };
        xhttp.open("GET", "fetch_comments.php?ma_bd=" + ma_bd);
        xhttp.send();
    }


    function addComment(event, ma_bd) {
        event.preventDefault(); // Ngăn modal tự động tắt

        var formData = new FormData(document.getElementById('commentForm'));

        var xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Xóa nội dung textarea sau khi gửi
                document.querySelector("textarea[name='noidungbl']").value = "";

                // Cập nhật danh sách bình luận mới nhất
                showComment(ma_bd);
            }
        };
        xhttp.open("POST", "add_comment.php", true);
        xhttp.send(formData);
    }


    // ẩn ảnh
    function showAllImages(postId) {
        // Hiển thị tất cả ảnh bị ẩn
        let hiddenImages = document.querySelectorAll('.post-' + postId);
        hiddenImages.forEach(img => img.style.display = 'block');

        // Ẩn nút "+X"
        let extraButton = document.querySelector('#post-images-' + postId + ' .extra-images');
        if (extraButton) {
            extraButton.style.display = 'none';
        }

        // Thêm nút "Thu gọn"
        let collapseButton = document.createElement('div');
        collapseButton.className = 'collapse-images';
        collapseButton.innerText = 'Thu gọn';
        collapseButton.onclick = function() {
            hideExtraImages(postId);
        };

        // Thêm vào cuối danh sách ảnh
        document.querySelector('#post-images-' + postId).appendChild(collapseButton);
    }

    function hideExtraImages(postId) {
        // Ẩn tất cả ảnh dư
        let hiddenImages = document.querySelectorAll('.post-' + postId);
        hiddenImages.forEach(img => img.style.display = 'none');

        // Hiển thị nút "+X" lại
        let extraButton = document.querySelector('#post-images-' + postId + ' .extra-images');
        if (extraButton) {
            extraButton.style.display = 'flex';
        }

        // Xóa nút "Thu gọn"
        let collapseButton = document.querySelector('#post-images-' + postId + ' .collapse-images');
        if (collapseButton) {
            collapseButton.remove();
        }
    }
</script>
</body>

</html>