<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../view/InfoStudentView.php';
    include '../model/Student.php';

?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Chỉnh sửa thông tin sinh viên') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/InfoStudent.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <!--  Nhúng file css thêm nếu cần  -->
</head>

<body>
<?php include '../view/HeaderStudent.php' ?>

    <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hoten']) && isset($_POST['ngaysinh']) && isset($_POST['diachi']) && isset($_POST['sdt']) && isset($_POST['avatar'])) {
            $hoten = $_POST['hoten'];
            $ngaysinh = $_POST['ngaysinh'];
            $diachi = $_POST['diachi'];
            $sdt = $_POST['sdt'];
            $ma_sv = $_COOKIE['ma_sv'];
            $avatar = $_POST['avatar'];
            $student = getDataStudent($ma_sv);
            echo getHeader($student['hoten'], $student['sdt'], $student);;

            $info = array('hoten' => $hoten, 'ngaysinh' => $ngaysinh, 'diachi' => $diachi, 'sdt' => $sdt, 'avatar' => $avatar);
            echo getFormEditInfoStudent($info);
        }
    ?>

    <?php include '../view/FooterStudent.php' ?>
    <script src="../public/js/InfoStudent.js"></script>
</body>

</html>