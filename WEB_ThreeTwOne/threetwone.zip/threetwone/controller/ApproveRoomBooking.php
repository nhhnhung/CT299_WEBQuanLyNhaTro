<?php
    include '../public/helper/checkCookieLandlord.php';
    include '../view/title_lib.php';
    include '../model/BoardingHouse.php';
?>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['state']) && $_POST['state'] == 'allow'){
        $ma_pdk = $_POST['ma_pdk'];
        $ma_phong = $_POST['ma_phong'];
        $ma_sv = $_POST['ma_sv'];
        $ngayhen = $_POST['ngayhen'];
        allowRoomBooking($ma_pdk, $ma_phong, $ma_sv, $ngayhen);
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['state']) && $_POST['state'] == 'reject'){
        $ma_pdk = $_POST['ma_pdk'];
        rejectRoomBooking($ma_pdk);
    }

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Duyệt Đăng Ký Phòng') ?>
    <link rel="stylesheet" href="../public/css/Approve.css">
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
</head>
<body>
<?php include '../view/HeaderLandLord.php' ?>
<div class="container mt-4">
    <h1 class="text-center text-primary">Danh Sách Đăng Ký Phòng</h1>
        <?php
            $listRegistedRoom = getAllRegistedRoom();
            while ($registedRoom = $listRegistedRoom->fetch_assoc()) {
                $dataRoom = getDataRoom($registedRoom['ma_phong']);
            ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Thông tin phòng trọ</h5>
            </div>
            <div class="card-body">
                <p><b>Tên nhà trọ:</b> <?php echo $dataRoom['ten_nt']; ?></p>
                <p><b>Số phòng:</b> <?php echo $dataRoom['sophong']; ?></p>
                <p><b>Địa chỉ:</b> <?php echo $dataRoom['diachi']; ?></p>
                <p><b>Giá phòng:</b> <?php echo number_format($dataRoom['gia'], 0, ',', '.') . ' VND'; ?></p>
                <p><b>Sức chứa:</b> <?php echo $dataRoom['succhua']; ?> người</p>
                <p><b>Diện tích:</b> <?php echo $dataRoom['dientich']; ?> m<sup>2</sup></p>
            </div>
        </div>

        <h3 class="text-secondary">Danh sách đăng ký thuê</h3>
            <?php
                $listPerson = getListPersonRegistedRoom($registedRoom['ma_phong']);
                while ($person = $listPerson->fetch_assoc()) {
            ?>
            <div class="card mb-3">
                <div class="card-body">
                    <p><b>Họ tên:</b> <?php echo $person['hoten']; ?></p>
                    <p><b>Ngày sinh:</b> <?php echo $person['ngaysinh']; ?></p>
                    <p><b>Email:</b> <?php echo $person['email']; ?></p>
                    <p><b>Địa chỉ:</b> <?php echo $person['diachi']; ?></p>
                    <p><b>Số điện thoại:</b> <?php echo $person['sdt']; ?></p>
                    <p><b>Ngày đăng ký:</b> <?php echo $person['ngaydangky']; ?></p>

                    <form method="post" action="ApproveRoomBooking.php" class="d-inline">
                        <input type="hidden" name="ma_pdk" value="<?php echo $person['ma_pdk']; ?>">
                        <input type="hidden" name="ma_phong" value="<?php echo $registedRoom['ma_phong']; ?>">
                        <input type="hidden" name="ma_sv" value="<?php echo $person['ma_sv']; ?>">
                        <input type="hidden" name="state" value="allow">
                        <div class="input-group mb-3">
                            <input type="date" name="ngayhen" class="form-control" required>
                            <button type="submit" class="btn btn-success">Duyệt</button>
                        </div>
                    </form>

                    <form method="post" action="ApproveRoomBooking.php" class="d-inline">
                        <input type="hidden" name="ma_pdk" value="<?php echo $person['ma_pdk']; ?>">
                        <input type="hidden" name="state" value="reject">
                        <button type="submit" class="btn btn-danger">Từ chối</button>
                    </form>
                </div>
            </div>
        <?php } } ?>
</div>
<?php include '../view/FooterLandLord.php' ?>
<script src="../public/js/Login.js"></script>
</body>
</html>
