<?php
    include '../public/helper/checkCookieLandlord.php';
    include '../view/title_lib.php';
    include '../view/InfoLandLordView.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib('Chỉnh sửa thông tin Chủ trọ') ?>
    <!--  Nhúng file css thêm nếu cần  -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/Info.css">
</head>
<body>
<?php include '../view/HeaderLandLord.php' ?>

    <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hoten']) && isset($_POST['ngaysinh']) && isset($_POST['diachi']) && isset($_POST['sdt']) && isset($_POST['avatar']) ) {
            $hoten = $_POST['hoten'];
            $ngaysinh = $_POST['ngaysinh'];
            $diachi = $_POST['diachi'];
            $sdt = $_POST['sdt'];
            $avatar = $_POST['avatar'];
            $ma_ct = $_COOKIE['ma_ct'];
            $info = array('hoten' => $hoten, 'ngaysinh' => $ngaysinh, 'diachi' => $diachi, 'sdt' => $sdt, 'avatar' => $avatar);
            echo getFormEditInfoLandLord($info);
        }
    ?>

    <?php include '../view/FooterLandLord.php' ?>

</body>
</html>


