<?php
include '../model/Posts.php';
include '../view/title_lib.php';
include '../model/Student.php';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <title>Bài đăng</title>
    <link rel="stylesheet" href="../public/css/Makepost.css">
    <?php echo setTitleAndImportLib('Trang chủ Sinh Viên'); ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
</head>
<body>

<?php include '../view/HeaderStudent.php'; ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['make_post'])){
        $ma_nd = $_POST['ma_nd'];
        $noidungbd = $_POST['noidungbd'];
        $uploadDir = "../public/imgPost/";
        $imagePaths = [];

        foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
            $originalName = $_FILES["images"]["name"][$key];
            $extension = pathinfo($originalName, PATHINFO_EXTENSION);
            $newFileName = uniqid("img_", true) . "." . $extension;
            $file = $uploadDir . $newFileName;

            if (move_uploaded_file($tmp_name, $file)) {
                $imagePaths[] = $file;
            }
        }

        if (!empty($imagePaths)) {
            $imagePathsString = implode(",", $imagePaths); // Nối chuỗi ảnh bằng dấu phẩy
            addPost($ma_nd, $noidungbd, $imagePathsString);
        } else {
            //Trường hợp không có ảnh
            $imagePathsString = null;
            addPost($ma_nd, $noidungbd, $imagePathsString);
        }
    }
?>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_post'])){
        $ma_bd = $_POST['ma_bd'];
        deletePost($ma_bd);
    }
?>

<?php

    echo '<h1 class="text-primary text-center mt-4">Tạo bài đăng</h1>';
    $ma_nd = $_COOKIE['ma_sv'];
    echo '<div class="container">
                <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post" enctype="multipart/form-data" class="card p-3 shadow-sm">
                    <p class="fw-bold">Upload hình ảnh bài đăng</p>
                    <input type="file" name="images[]" multiple class="form-control mb-2">
                    <textarea name="noidungbd" placeholder="Nội dung" class="form-control mb-2" rows="3"></textarea>
                    <input type="hidden" name="ma_nd" value="' . $ma_nd . '">
                    <button type="submit" name="submit" class="btn btn-primary w-100 w-09890">Đăng bài</button>
                    <input type="hidden" name="make_post" value="make_post">
                </form>
            </div>';

    $listPost = getAllPostOfUser($ma_nd);
    echo '<h1 class="text-primary text-center mt-4">Danh sách bài đăng của tôi</h1>';
    echo '<div class="container">';

    while ($row = $listPost->fetch_assoc()) {
        echo '<div class="card p-3 shadow-sm mt-3">';

        if ($row['ngaydang'] == NULL) {
            echo '<p class="text-warning">Thời gian đăng: Bài đăng chưa được duyệt</p>';
        } else {
            echo '<p class="text-muted">Thời gian đăng: ' . $row['ngaydang'] . '</p>';
        }

        echo '<div class="post">
                    <p class="fw-bold">Nội dung bài đăng:</p>
                    <p class="card-text">' . $row['noidungbd'] . '</p>              
                  </div>';

        if (!empty($row["url_images"])) {
            $imagePaths = explode(",", $row["url_images"]);
            echo '<div class="post-images d-flex flex-wrap">';
            foreach ($imagePaths as $image) {
                echo '<img src="' . trim($image) . '" alt="Hình ảnh bài đăng" class="img-thumbnail m-1" style="max-width: 200px;">';
            }
            echo '</div>';
        }

        echo '<div class="d-flex justify-content-between mt-3">
                    <form action="EditPost.php" method="post" class="d-inline">
                        <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                        <input type="hidden" name="img" value="' . $row['url_images'] . '">
                        <input type="hidden" name="edit_post" value="edit_post">
                        <input type="hidden" name="role" value="sv">
                        <button type="submit" name="submit" class="btn btn-outline-primary">Sửa bài</button>
                    </form>
            
                    <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post" class="d-inline">
                        <input type="hidden" name="ma_bd" value="' . $row['ma_bd'] . '">
                        <input type="hidden" name="delete_post" value="delete_post">  
                        <button type="submit" name="submit" class="btn btn-outline-danger">Xóa bài</button>
                    </form>
                  </div>';

        echo '</div>';
    }
    echo '</div>';
?>

<?php include '../view/FooterStudent.php'?>
<script src="../public/js/InfoStudent.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll("form").forEach(form => {
            form.addEventListener("submit", function (event) {
                if (form.querySelector("input[name='delete_post']")) {
                    if (!confirm("Bạn có chắc chắn muốn xóa bài đăng này không?")) {
                        event.preventDefault(); // Ngăn form gửi nếu nhấn "Không"
                    }
                }
            });
        });
    });
</script>


</body>
</html>



