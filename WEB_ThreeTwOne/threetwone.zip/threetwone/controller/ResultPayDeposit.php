<?php
    include '../model/BoardingHouse.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <!-- Import CSS -->
    <?php echo setTitleAndImportLib('Kết quả thanh toán đặt cọc') ?>
    <link rel="stylesheet" href="../public/css/paypaypay.css">
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Student.css">
</head>
<body>

<!-- Header -->
<?php include '../view/HeaderStudent.php' ?>
<?php
    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    // phần header
    echo getHeader($student['hoten'], $student['sdt'], $student);
?>

<!-- Nội dung chính -->
<main>
    <div class="container1">
        <?php
        echo '<div class="alert">Thuê phòng thành công!</div>';
        if(isset($_GET['ma_hd']) && isset($_GET['vnp_Amount'])) {
            $ma_hd = $_GET['ma_hd'];
            $vnp_Amount = $_GET['tongtien']/1000;
            $ma_sv = $_GET['ma_sv'];
            $ma_phong = $_GET['ma_phong'];

            contractPayment($ma_hd);
            addCommision($ma_hd, $vnp_Amount);
            addRentingRoom($ma_phong, $ma_hd, $ma_sv);
        }
        ?>
    </div>
</main>

<!-- Footer -->
<div class="body"></div>
<?php include '../view/FooterStudent.php' ?>
<script src="../public/js/InfoStudent.js"></script>

</body>
</html>