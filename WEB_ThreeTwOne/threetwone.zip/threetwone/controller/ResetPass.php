<?php 
    include '../model/Account.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['password']) && isset($_POST['email'])){
        $passwordUser = $_POST['password'];
        $email = $_POST['email'];

        resetPass($passwordUser, $email);
        header('Location: Login.php');
    }
?>

