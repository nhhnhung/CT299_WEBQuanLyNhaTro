<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Service.php';
    include '../view/ServiceView.php';
    include '../model/Student.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Dịch vụ') ?>
    <link rel="stylesheet" href="../public/css/header_footer.css">
    <link rel="stylesheet" href="../public/css/InfoStudent.css">
    <link rel="stylesheet" href="../public/css/together.css">
    <link rel="stylesheet" href="../public/css/Service.css">
    <!-- Mỗi trang cần file khác nhau nên import thủ công -->

</head>

<body>
    <?php include '../view/HeaderStudent.php'; ?>

    <?php
        $student = getDataStudent($_COOKIE['ma_sv']);
        echo getHeader($student['hoten'], $student['sdt'], $student);

        // Hiển thị danh sách dịch vụ
        $listService = getAllService();
        $listRoom = getAllRoomStudentStay($_COOKIE['ma_sv']);
        showAllService($listService, $listRoom);
    ?>

    <?php include '../view/FooterStudent.php'; ?>
    <script src="../public/js/InfoStudent.js"></script>
</body>

</html>