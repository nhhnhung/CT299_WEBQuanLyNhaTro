<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Service.php';
    include '../view/ServiceView.php';

?>

<!doctype html>
<html lang="vi">
<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Kết quả thanh toán') ?>
    <!-- Mỗi trang cần file khác nhau nên import thủ công -->
    <link rel="stylesheet" href="../public/css/stylelac.css">
    <link rel="stylesheet" href="../public/css/header_footer.css">
</head>
<body>
    <?php include '../view/HeaderStudent.php'; ?>

    <?php
        $ma_sv = $_COOKIE['ma_sv'];
        $student = getDataStudent($ma_sv);
        echo getHeader($student['hoten'], $student['sdt'], $student);
    ?>

    <?php
        if($_GET['vnp_ResponseCode'] == '00' && $_GET['vnp_ResponseCode'] == '00'){
            echo getMessageSuccessPayment();
        }
    ?>

    <?php
        $listService = [];
        $day = date('Y-m-d');
        $ma_phong = $_GET['ma_phong'];
        foreach ($_GET as $key => $value) {
            if($key == 'ma_phong'){
                break;
            }

            $service = getServiceById($key);
            $service['soluong'] = $value;
            array_push($listService, $service);
            saveUseService($day, $value, $ma_phong, $key);
        }

        showAllServiceBooked($listService);
        echo '<div class="container text-center mt-4">';
        echo '    <div class="room-info p-3 rounded">Phòng sử dụng: <span>' . $ma_phong . '</span></div>';
        echo '    <div class="total-amount p-3 rounded mt-2">Tổng tiền: <span>' . number_format($_GET["vnp_Amount"]/100, 0, ",", ".") . ' VND</span></div>';
        echo '</div>';
    ?>


    <?php include '../view/FooterStudent.php'; ?>
    <script src="../public/js/Login.js"></script>
    <script src="../public/js/InfoStudent.js"></script>
</body>
</html>
