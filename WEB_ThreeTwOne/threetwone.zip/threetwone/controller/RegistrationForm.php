<?php
    include '../public/helper/checkCookieStudent.php';
    include '../view/title_lib.php';
    include '../model/Student.php';
    include '../model/BoardingHouse.php';
    include '../view/HeaderStudent.php';

    echo '<head>';
    echo setTitleAndImportLib('Đăng Ký Thuê phòng');
    echo '<link rel="stylesheet" href="../public//css/RegisForm.css">';
    echo '<link rel="stylesheet" href="../public/css/header_footer.css">
            <link rel="stylesheet" href="../public/css/together.css">';
    echo '</heade>';

    echo '<body>';
    echo '<div class="main">';


    $ma_sv = $_COOKIE['ma_sv'];
    $student = getDataStudent($ma_sv);
    // phần header
    echo getHeader($student['hoten'], $student['sdt'], $student);


    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['name_landlor']) && isset($_GET['phone_landlor']) && isset($_GET['name_boarding_house']) && isset($_GET['address_boarding_house']) && isset($_GET['price']) && isset($_GET['capacity']) && isset($_GET['area_room']) && isset($_GET['so_phong']) && isset($_GET['ma_phong']) && isset($_GET['ma_sv']) && isset($_GET['ma_ct'])) {
        $name_landlor = $_GET['name_landlor'];
        $phone_landlor = $_GET['phone_landlor'];
        $name_boarding_house = $_GET['name_boarding_house'];
        $address_boarding_house = $_GET['address_boarding_house'];
        $price = $_GET['price'];
        $capacity = $_GET['capacity'];
        $area_room = $_GET['area_room'];
        $room = $_GET['so_phong'];

        $ma_phong = $_GET['ma_phong'];
        $ma_sv = $_GET['ma_sv'];
        $ma_ct = $_GET['ma_ct'];



        echo '<div class="container contn">';
        echo '<div class="row row1">';
        echo '<div class="col-md-12 infoRoom">';
        echo '<h2>Thông tin đăng ký thuê phòng</h2>';
        echo '<p><i class="fas fa-user"></i>  Chủ nhà trọ: ' . $name_landlor . '</p>';
        echo '<p><i class="fas fa-phone"></i> Số điện thoại: ' . $phone_landlor . '</p>';
        echo '<p><i class="fas fa-home"></i> Nhà trọ: ' . $name_boarding_house . '</p>';
        echo '<p><i class="fas fa-map-marker-alt"></i> Địa chỉ: ' . $address_boarding_house . '</p>';
        echo '<p><i class="fas fa-money-bill-wave"></i> Giá phòng: ' . $price . 'VNĐ</p>';
        echo '<p><i class="fas fa-users"></i> Sức chứa: ' . $capacity . ' người</p>';
        echo '<p><i class="fas fa-expand"></i> Diện tích: ' . $area_room . ' m<sup>2</sup></p>';
        echo '<p><i class="fas fa-door-open"></i> Số phòng: ' . $room . '</p>';
        echo '</div>';
        echo '<div class="col-md-12 infoUser">';
        echo '<h2>Thông tin người thuê</h2>';
        $student = getDataStudent($_COOKIE['ma_sv']);
        echo '<form method="post" action="RegistrationForm.php">';
        echo '<div class="form-group
                                <label for="name"><i class="fas fa-user"></i> Họ tên: ' . $student['hoten'] . '</label>';
        echo '</div>';
        echo '<div class="form-group
                                <label for="phone"><i class="fas fa-phone"></i> Số điện thoại: ' . $student['sdt'] . '</label>';
        echo '</div>';
        echo '<div class="form-group
                                <label for="email"><i class="fas fa-envelope"></i> Email: ' . $student['email'] . '</label>';
        echo '</div>';
        echo '<div class="form-group
                                <label for="address"><i class="fas fa-map-marker-alt"></i> Địa chỉ: ' . $student['diachi'] . '</label>';
        echo '</div>';
        echo '<input type="hidden" name="ma_phong" value="' . $ma_phong . '">';
        echo '<input type="hidden" name="ma_sv" value="' . $ma_sv . '">';
        echo '<input type="hidden" name="ma_ct" value="' . $ma_ct . '">';
        echo '<div class="box">';
        echo '<button type="submit" class="btn">Đăng ký</button>';
        echo '</div>';
        echo '</form>';
        echo '</div>';
        echo '</div>';

    }


    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ma_phong']) && isset($_POST['ma_sv']) && isset($_POST['ma_ct'])) {
        $ma_phong = $_POST['ma_phong'];
        $ma_sv = $_POST['ma_sv'];
        $ma_ct = $_POST['ma_ct'];
        addRegistration($ma_sv, $ma_phong);
        echo '<div class="container contn">';
        echo '<div class="row row1">';
        echo '<div class="col-md-12">';
        echo '<h2>Đăng ký thành công vui lòng chờ chủ trọ phản hồi</h2>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';

    include '../view/FooterStudent.php';
    echo '</body>';
?>

<script src="../public/js/InfoStudent.js"></script>
