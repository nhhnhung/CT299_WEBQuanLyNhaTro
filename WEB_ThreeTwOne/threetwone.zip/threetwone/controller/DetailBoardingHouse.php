<?php
include '../public/helper/checkCookieLandlord.php';
include '../view/title_lib.php';
include '../model/BoardingHouse.php';
include '../model/Student.php';
include '../model/Device.php';
include '../view/BoardingHouseView.php';
?>

<!doctype html>
<html lang="vi">

<head>
    <?php echo setTitleAndImportLib('Chi tiết nhà trọ') ?>
    <link rel="stylesheet" href="../public/css/DetailBH.css">
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <!--  Nhúng file css thêm nếu cần  -->
</head>

<body>
<?php include '../view/HeaderLandLord.php' ?>

<div class="container-xl main">
    <div class="row">
        <div class="mainContent col-md-3">
            <?php
            $ma_nt = $_GET['ma_nt'];
            $boardingHouse = getDataBoardingHouse($ma_nt);
            echo '<h1 class="title">' . $boardingHouse['ten_nt'] . '</h1>';
            echo '<p><b>Địa chỉ: </b>' . $boardingHouse['diachi'] . '</p>';
            echo '<p><b>Số lượng phòng: </b>' . $boardingHouse['soluongphong'] . '</p>';
            echo '<p><b>Trạng thái:</b> Đã đăng ký kinh doanh</p>';
            ?>
            <button type="button" class="btn btn-outline-primary" onclick="goToList()">Danh sách loại phòng</button>
        </div>
        <div class="formAddTypeRoom col-md-9">
            <h2 class="title">Thêm loại phòng</h2>
            <form action="AddRoomType.php" method="post" name="form-add-room-type" enctype="multipart/form-data">
                <div class="infoHouse">
                    <input type="number" min="0" name="price" placeholder="Nhập giá phòng" required>VND
                    <input type="number" min="1" name="capacity" placeholder="Nhập sức chứa" required>Người
                    <input type="number" min="1" name="area-room" placeholder="Nhập diện tích" required> m<sup>2</sup>
                    <input id="imgs" type="file" name="images[]" multiple required>
                    <input type="hidden" name="ma_nt" value="<?php echo $ma_nt ?>">
                </div>
                <div class="box-inputIMG">
                    <label for="add-img"> Thêm tối đa 4 ảnh:</label>
                    <input type="button" id="add-img" class="btn-add" onclick="clickAddImgs()" value="Thêm ảnh">
                    <span id="number-img"></span>
                </div>
                <h5>Nhập số lượng thiết bị</h5>
                <?php
                $listDevice = getAllDevice();
                if ($listDevice->num_rows > 0) {
                    echo '<div class="listDevice">';
                    while ($row = $listDevice->fetch_assoc()) {
                        echo '<div class="device">';
                        echo '<label class="displayNone"><input type="hidden" name="devices[]" value="' . $row['ma_tb'] . '"></label>';
                        echo '<span>' . $row['tenthietbi'] . ':</span><input class="inputDevice" type="number" value="0" min="0" name="quantity-' . $row['ma_tb'] . '" placeholder="Nhập số lượng thiết bị">';
                        echo '</div>';
                    }
                    echo '</div>';
                } else {
                    echo '<p>Chưa có thiết bị</p>';
                    echo '<a href="AddDevice.php">Thêm thiết bị</a>';
                }
                ?>
                <input type="hidden" name="quantity-device" value="<?php echo $listDevice->num_rows ?>">
                <button type="submit" class="btn-add add1">Thêm loại phòng</button>
            </form>
        </div>
        <div class="listTypeRoom col-md-12">
            <div class="box">
                <h2 id="listTypeRoom">Danh sách loại phòng</h2>
                <?php
                $listRoomType = getListRoomType($ma_nt);
                $stt = 0;
                foreach ($listRoomType as $roomType) {
                    echo '<div class="box1 row">';
                    echo '<div class="col-md-4">';
                    echo '<h3>Thông tin loại phòng</h3>';
                    $listDeviceOfRoomType = getListDeviceOfRoomType($roomType['ma_lp']);
                    echo '<p>STT: ' . ++$stt . ' | Giá: <span class="gia" data-price="' . $roomType['gia']*1000 . '"></span> | Sức chứa: ' . $roomType['succhua'] . ' người | Diện tích: ' . $roomType['dientich'] . ' m<sup>2</sup></p>';
                    /*Phần hiển thị ảnh*/
                    if ($roomType['imgs'] != null) {
                        $imgs = explode(",", $roomType['imgs']);
                        echo '<div class="row imgs_box justify-content-center">';
                        foreach ($imgs as $img) {
                            echo '<img class="imgTypeRoom col-md-5 col-sm-2" src="' . $img . '" alt="ảnh loại phòng">';
                        }
                        echo '</div>';
                    }

                    echo '<p><b>Thiết bị: </b><br>';
                    foreach ($listDeviceOfRoomType as $device) {
                        echo $device['tenthietbi'] . ' (số lượng : ' . $device['soluong'] . ') <br>';
                    }
                    echo '</p>';

                    echo '<form class="addRoomForm" action="AddRoom.php" method="get">
                                    <input type="number" name="numberOfroom" min="1" placeholder="Số của phòng" required>
                                    <input type="hidden" name="ma_nt" value="' . $ma_nt . '">
                                    <input type="hidden" name="ma_lp" value="' . $roomType["ma_lp"] . '">
                                    <button type="submit" class="btn-add add2">Thêm phòng</button>
                                </form>
                                ';
                    if (isset($_GET['exitRoomError']) && $_GET['exitRoomError'] == 1 && isset($_GET['ma_lp']) && $_GET['ma_lp'] == $roomType['ma_lp']) {
                        echo '<div id="response" class="alert alert-danger">Số của phòng vừa thêm đã tồn tại</div>';
                    }
                    echo '</div>';
                    echo '<div class="col-md-8 row">';
                    echo '<h3>Danh sách phòng:</h3>';
                    echo '<div class="room-box col-md-12">';
                    $listRoom = getListRommOfRoomType($roomType['ma_lp']);
                    if ($listRoom->num_rows > 0) {
                        while ($row = $listRoom->fetch_assoc()) {
                            echo '<div class="room col-md-12">';
                            $ma_phong = $row['ma_phong'];
                            $sophong = $row['sophong'];
                            echo '<p class="numberRoom">Số phòng : ' . $sophong . '</p>';
                            $listPerson = getListPersonOfRoom($ma_phong);
                            if ($listPerson->num_rows > 0) {
                                echo '<h5>Danh sách người ở phòng này:</h5>';
                                echo '<table border="1" cellpadding="5" cellspacing="0" class="tablePerson col-md-12">
                                        <tr>
                                            <th>Họ tên</th>
                                            <th>Ngày sinh</th>
                                            <th>Số điện thoại</th>
                                        </tr>';
                                foreach ($listPerson as $person) {
                                    $student = getDataStudent($person['ma_sv']);
                                    echo '
                                        <tr>
                                            <td>' . $student['hoten'] . '</td>
                                            <td>' . date('d-m-Y', strtotime($student['ngaysinh'])) . '</td>
                                            <td>' . $student['sdt'] . '</td>
                                        </tr>';
                                }
                                echo '</table>';
                            } else {
                                echo '<p class="emptyR">Chưa có người ở phòng này</p>';
                            }
                            echo '</div>';
                        }
                    } else {
                        echo '<h3>Chưa có phòng</h3>';
                    }
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '<br><br>';
                }

                ?>
            </div>
        </div>
    </div>
</div>

<?php include '../view/FooterLandLord.php' ?>
<script src="../public/js/ManagerHouse.js"></script>
</body>

</html>