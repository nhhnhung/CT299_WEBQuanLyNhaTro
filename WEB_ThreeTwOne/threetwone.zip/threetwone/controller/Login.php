<?php 
    include '../model/CheckLogin.php';
    include '../view/title_lib.php';
    include '../view/LoginView.php';

    $error_login = false;
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['role'])){
        $email = $_POST['email'];
        $passwordUser = $_POST['password'];
        $role = $_POST['role'];

        if(checkLogin($email, $passwordUser, $role)){
            $error_login = false;
            if($role == 'sinhvien'){
                header('Location: Student.php');
            } else if($role == 'chutro'){
                header('Location: Landlord.php');
            }
        } else {
            $error_login = true;
        }
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <!-- Nhúng thư viện và set tiêu đề -->
    <?php echo setTitleAndImportLib('Đăng nhập') ?>

    <!-- Mỗi trang cần file khác nhau nên import thủ công -->
    <link rel="stylesheet" href="../public/css/stylemn.css">

</head>
<body>
    <div class="container">
        <h2>Đăng nhập</h2>
        
        <?php
            // Lấy form từ view
            echo getViewLogin(htmlspecialchars($_SERVER["PHP_SELF"]));

            // Hiển thị thông báo lỗi đăng nhập nếu có
            if($error_login == true){
                echo getMessageErrorLogin();
            }

            // Lấy các lựa chọn khác
            echo getMoreOption();
        ?>

    </div>

<!--    Hiển thị video nền-->
    <?php echo getBackgroundVideo(); ?>

    <script src="../public/js/Login.js"></script>

</body>
</html>


<!-- Link check :  http://localhost/threetwone/controller/Login.php -->