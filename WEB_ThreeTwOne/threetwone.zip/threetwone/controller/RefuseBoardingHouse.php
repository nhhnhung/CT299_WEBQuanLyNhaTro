<?php
    include '../model/Admin.php';
    include '../model/BoardingHouse.php';
    include '../public/helper/sendEmail.php';

    if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ma_nt'])) {
        $subject = 'Từ chối đăng ký nhà trọ';
        $body = 'Nhà trọ của bạn đã bị từ chối đăng ký';
        $boardingHouse = getDataBoardingHouse($_GET['ma_nt']);
        $boardingHouse = $boardingHouse->fetch_assoc();
        $infoBoardingHouse = 'Tên nhà trọ : ' . $boardingHouse['ten_nt'] . ' <br> ' . 'Địa chỉ nhà trọ: ' . $boardingHouse['diachi'];
        $body .= ' <br> ' . $infoBoardingHouse;
        send_email($subject, $body, $_GET['email']);
        refuseRegistBoardingHouse($_GET['ma_nt']);
        header('Location: ComfirmRegistBoardingHouse.php');
    }
?>