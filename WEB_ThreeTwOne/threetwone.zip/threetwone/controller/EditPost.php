<?php
    include '../model/Posts.php';
    include '../view/title_lib.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <link rel="stylesheet" href="../public/css/EditPost.css">
</head>
<body>
<div class="container mt-4">
    <div class="card shadow-sm p-4">
        <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['set_baidang']) && isset($_POST['role'])){
            $ma_bd = $_POST['ma_bd'];
            $noidungbd = $_POST['noidungbd'];
            $role = $_POST['role'];
            $old_img = $_POST['old_img'];

            $uploadDir = "../public/imgPost/";
            $imagePaths = [];

            foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
                $originalName = $_FILES["images"]["name"][$key];
                $extension = pathinfo($originalName, PATHINFO_EXTENSION);
                $newFileName = uniqid("img_", true) . "." . $extension;
                $file = $uploadDir . $newFileName;

                if (move_uploaded_file($tmp_name, $file)) {
                    $imagePaths[] = $file;
                }
            }

            if (!empty($imagePaths)) {
                $imagePathsString = implode(",", $imagePaths);
                editPostHaveOld($ma_bd, $noidungbd, $imagePathsString, $old_img);
            } else {
                editPost($ma_bd, $noidungbd, $old_img);
            }

            if($role == 'sv'){
                header('Location: MakePost.php');
            } else if($role == 'ct'){
                header('Location: MakePostLandLord.php');
            }
        }

        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_post'])){
            $ma_bd = $_POST['ma_bd'];
            $role = $_POST['role'];
            $img = $_POST['img'];
            ?>
            <h2 class="text-center text-primary">Chỉnh sửa bài đăng</h2>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data" class="mt-3">
                <div class="mb-3">
                    <label class="form-label fw-bold">Chọn ảnh mới (nếu có):</label>
                    <input type="file" name="images[]" multiple class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Nội dung bài đăng:</label>
                    <textarea name="noidungbd" placeholder="Nội dung" class="form-control" rows="3"></textarea>
                </div>
                <input type="hidden" name="ma_bd" value="<?php echo $ma_bd; ?>">
                <input type="hidden" name="old_img" value="<?php echo $img; ?>">
                <input type="hidden" name="set_baidang" value="set_baidang">
                <input type="hidden" name="role" value="<?php echo $role; ?>">
                <button type="submit" name="submit" class="btn btn-primary w-100">Lưu thay đổi</button>
            </form>
        <?php } ?>
    </div>
</div>

<script>
    document.querySelector("form").addEventListener("submit", function(event) {
        if (!confirm("Bạn có chắc chắn muốn lưu các thay đổi không?")) {
            event.preventDefault(); // Ngăn form gửi đi nếu chọn "Không"
        }
    });
</script>

</body>
</html>
