<?php
    include '../public/helper/payMent.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ma_phong']) && isset($_POST['ma_dgdn']) && isset($_POST['tong_tien'])){
        $ma_phong = $_POST['ma_phong'];
        $ma_dgdn = $_POST['ma_dgdn'];
        $ton_tien = $_POST['tong_tien'];

        $vnp_TxnRef = time();
        $vnp_OrderInfo = 'Thanh toán tiền điện nước tháng ' . date('m') . '-' . date('Y');
        $vnp_OrderType = 'billpayment';
        $vnp_Amount = $ton_tien;
        $vnp_Returnurl = 'http://localhost/threetwone/controller/StudentPay.php?ma_phong=' . $ma_phong . '&ma_dgdn=' . $ma_dgdn . '&tong_tien=' . $ton_tien;

        pay($vnp_Returnurl, $vnp_TxnRef, $vnp_OrderInfo, $vnp_OrderType, $vnp_Amount);
    }else{
        header('Location: http://localhost/threetwone/controller/StudentPay.php');
    }
?>