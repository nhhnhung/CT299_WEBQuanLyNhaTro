<?php
    include '../model/Posts.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $ma_bd = $_POST["ma_bd"];
        $ma_nd = $_POST["ma_nd"];
        $noidungbl = $_POST["noidungbl"];

        addComment($ma_bd, $ma_nd, $noidungbl);
    }

?>