<?php
    include '../model/Review.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ma_nt'])) {
        $ma_nt = $_GET['ma_nt'];
        $reviews = getAllReviewOfBoardingHouse($ma_nt);

        echo '<div class="review-container">';
        foreach ($reviews as $review) {
            echo '<div class="review">';
            echo '      <img src="' . $review['avatar'] . '" alt="Avatar" class="review-avatar">';
            echo '      <span class="review-name">' . $review['hoten'] . '</span>';
            echo '<p><strong>Đánh giá:</strong> ' . $review['danh_gia'] . '</p>';
            echo '<p><strong>Số sao:</strong> ';
            for ($i = 0; $i < $review['so_sao']; $i++) {
                echo '<i class="fa-solid fa-star" style="color: #FFD700;"></i>';
            }
            echo '</p>';
            echo '<p><strong>Thời gian:</strong> ' . $review['thoi_gian'] . '</p>';
            echo '</div>'; // Mỗi review là 1 div riêng
        }
        echo '</div>'; // Đóng div chứa danh sách đánh giá

        if (count($reviews) == 0) {
            echo '<p>Chưa có đánh giá nào</p>';
        }
    }

?>