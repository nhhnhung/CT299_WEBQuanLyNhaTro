<?php
    include '../model/Admin.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $hoten = $_POST['hoten'];
        $ngaysinh = $_POST['ngaysinh'];
        $email = $_POST['email'];
        $diachi = $_POST['diachi'];
        $sdt = $_POST['sdt'];
        $ma_nd = $_POST['ma_nd'];
        updateUser($hoten, $ngaysinh, $email, $diachi, $sdt, $ma_nd);
    }
?>