<?php
    include '../public/helper/checkCookieLandLord.php';
    include '../view/title_lib.php';
    include '../model/BoardingHouse.php';
    include '../view/BoardingHouseView.php';
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib("Đăng ký nhà trọ") ?>
    <!-- Đính kèm thêm css nếu có   -->
    <link rel="stylesheet" href="../public/css/Lacheader_footer.css">
    <link rel="stylesheet" href="../public/css/RegistLac.css">
</head>
<body>
    <?php include '../view/HeaderLandLord.php'; ?>

    <?php echo  getFormRegistBoardingHouse(htmlspecialchars($_SERVER['PHP_SELF']))?>

    <?php
        if(isset($_POST['tennt']) && isset($_POST['diachi'])) {
            $tennt = $_POST['tennt'];
            $diachi = $_POST['diachi'];
            $ma_ct = $_COOKIE['ma_ct'];

            registBoadingHouse($tennt, $diachi, $ma_ct);
            echo '<div class="alert alert-danger mess">Vui lòng chờ admin xác thực</div>';
        }
    ?>

    <?php include '../view/FooterLandLord.php'; ?>
    <script src="../public/js/Login.js"></script>
</body>
</html>

