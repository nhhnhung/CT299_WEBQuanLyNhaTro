<?php
    session_start();
    include '../public/helper/checkSessionAdmin.php';
    include '../view/title_lib.php';
    include '../model/Admin.php';
?>

<?php
echo setTitleAndImportLib('Quản lý tài khoản');
?>

<!doctype html>
<html lang="vi">
<head>
    <?php echo setTitleAndImportLib("Admin") ?>
    <link rel="stylesheet" href="../public/css/AccountManager.css">
    <link rel="stylesheet" href="../public/css/headerAdmin.css">
</head>


<body >
<?php include '../view/HeaderAdmin.php'; ?>

<div class="col-md-10">
<div class="text-center mt-3">
    <a href="MangeAccount.php?mange=sv" class="btn btn-primary m-2">Sinh Viên</a>
    <a href="MangeAccount.php?mange=ct" class="btn btn-primary m-2">Chủ Trọ</a>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sửa thông tin người dùng</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body"></div>
        </div>
    </div>
</div>

<?php
if(isset($_GET['mange']) && $_GET['mange'] == 'sv'){
    echo '<h1 class="text-center mt-4">Sinh viên</h1>';
    $listStudent = getAllStudent();
    echo '<table class="table table-bordered">';
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th>STT</th>';
    echo '<th>Tên sinh viên</th>';
    echo '<th>Ngày sinh</th>';
    echo '<th>Email</th>';
    echo '<th>Địa chỉ</th>';
    echo '<th>Số điện thoại</th>';
    echo '<th>Thao tác</th>';
    echo '<th>Trạng thái tài khoản</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    $i = 1;
    foreach ($listStudent as $student) {
        echo '<tr>';
        echo '<td>' . $i . '</td>';
        echo '<td>' . $student['hoten'] . '</td>';
        echo '<td>' . $student['ngaysinh'] . '</td>';
        echo '<td>' . $student['email'] . '</td>';
        echo '<td>' . $student['diachi'] . '</td>';
        echo '<td>' . $student['sdt'] . '</td>';
        echo '<td>' . ($student['trangthaitk'] == 'Đang mở' ? '<span class="badge bg-success">Đang mở</span>' : '<span class="badge bg-danger">Đã khóa</span>') . '</td>';
        echo '<td>';
        echo '<button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showFormEditUser(`' . $student['hoten'] . '`, `' . $student['ngaysinh'] . '`, `' . $student['email'] . '`, `' . $student['diachi'] . '`, `' . $student['sdt'] . '`, `' . $student['avatar'] . '`, `' . $student['ma_nd'] . '`)">Sửa</button> ';
        echo '<br><br>';
        echo $student['trangthaitk'] == 'Đang mở' ? '<button class="btn btn-danger btn-sm" onclick="lockAccount('. $student['ma_nd'] .')">Khóa</button>' : '<button class="btn btn-success btn-sm" onclick="unlockAccount('. $student['ma_nd'] .')">Mở</button>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    echo '</tbody>';
    echo '</table>';
}

if(isset($_GET['mange']) && $_GET['mange'] == 'ct'){
    echo '<h1 class="text-center mt-4">Chủ trọ</h1>';
    $listLandLord = getAllLandLord();
    echo '<table class="table table-bordered">';
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th>STT</th>';
    echo '<th>Tên chủ trọ</th>';
    echo '<th>Ngày sinh</th>';
    echo '<th>Email</th>';
    echo '<th>Địa chỉ</th>';
    echo '<th>Số điện thoại</th>';
    echo '<th>Mã số thuế</th>';
    echo '<th>Thao tác</th>';
    echo '<th>Trạng thái tài khoản</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    $i = 1;
    foreach ($listLandLord as $landLord) {
        echo '<tr>';
        echo '<td>' . $i . '</td>';
        echo '<td>' . $landLord['hoten'] . '</td>';
        echo '<td>' . $landLord['ngaysinh'] . '</td>';
        echo '<td>' . $landLord['email'] . '</td>';
        echo '<td>' . $landLord['diachi'] . '</td>';
        echo '<td>' . $landLord['sdt'] . '</td>';
        echo '<td>' . $landLord['masothue'] . '</td>';
        echo '<td>' . ($landLord['trangthaitk'] == 'Đang mở' ? '<span class="badge bg-success">Đang mở</span>' : '<span class="badge bg-danger">Đã khóa</span>') . '</td>';
        echo '<td>';
        echo '<button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="showFormEditUser(`' . $landLord['hoten'] . '`, `' . $landLord['ngaysinh'] . '`, `' . $landLord['email'] . '`, `' . $landLord['diachi'] . '`, `' . $landLord['sdt'] . '`, `' . $landLord['avatar'] . '`, `' . $landLord['ma_nd'] . '`)">Sửa</button> ';
        echo '<br><br>';
        echo $landLord['trangthaitk'] == 'Đang mở' ? '<button class="btn btn-danger btn-sm" onclick="lockAccount('. $landLord['ma_nd'] .')">Khóa</button>' : '<button class="btn btn-success btn-sm" onclick="unlockAccount('. $landLord['ma_nd'] .')">Mở</button>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    echo '</tbody>';
    echo '</table>';
}
?>
</div>


<script>
    function lockAccount(ma_nd){
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function () {
            if (this.readyState == 4 && this.status == 200) {
                location.reload();
            }
        };
        xhttp.open("GET", "LockAccount.php?ma_nd=" + ma_nd);
        xhttp.send();
    }

    function unlockAccount(ma_nd){
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function () {
            if (this.readyState == 4 && this.status == 200) {
                location.reload();
            }
        };
        xhttp.open("GET", "UnLockAccount.php?ma_nd=" + ma_nd);
        xhttp.send();
    }

    function showFormEditUser(hoten, ngaysinh, email, diachi, sdt, avatar, ma_nd){
        document.getElementById('modal-body').innerHTML = `
        <form id="editUserForm" onsubmit="return validateDateOfBirth()">
            <label for="hoten">Họ tên</label>
            <input type="text" name="hoten" value="` + hoten + `" required>

            <label for="ngaysinh">Ngày sinh</label>
            <input type="date" id="ngaysinh" name="ngaysinh" value="` + ngaysinh + `" required>

            <label for="email">Email</label>
            <input type="email" name="email" value="` + email + `" required>

            <label for="diachi">Địa chỉ</label>
            <input type="text" name="diachi" value="` + diachi + `" required>

            <label for="sdt">Số điện thoại</label>
            <input type="text" name="sdt" value="` + sdt + `" required>

            <input type="hidden" name="ma_nd" value="` + ma_nd + `">

            <button type="submit">Sửa</button>
        </form>
    `;
    }

    // Hàm kiểm tra ngày sinh
    function validateDateOfBirth() {
        let dob = document.getElementById('ngaysinh').value;
        let today = new Date();
        let dobDate = new Date(dob);

        // Kiểm tra nếu ngày sinh lớn hơn ngày hiện tại
        if (dobDate > today) {
            alert("Ngày sinh không hợp lệ! Vui lòng chọn ngày khác.");
            return false;
        }

        // Kiểm tra nếu người dùng chưa đủ 18 tuổi
        let minAgeDate = new Date();
        minAgeDate.setFullYear(today.getFullYear() - 18); // Tính ngày hợp lệ cho người từ 18 tuổi trở lên

        if (dobDate > minAgeDate) {
            alert("Bạn phải đủ 18 tuổi trở lên!");
            return false;
        }

        return true;
    }


    function updateUser(){
        event.preventDefault();
        var formData = new FormData(document.getElementById('editUserForm'));
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function () {
            if (this.readyState == 4 && this.status == 200) {
                location.reload();
            }
        };
        xhttp.open("POST", "UpdateUser.php");
        xhttp.send(formData);
    }


</script>

</body>
</html>


