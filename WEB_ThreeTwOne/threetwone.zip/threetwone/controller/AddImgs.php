<?php
function uploadImgs(){
    $uploadDir = "../public/imgTypeRoom/";
    $imagePaths = [];

    foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
        $originalName = $_FILES["images"]["name"][$key];
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $newFileName = uniqid("img_", true) . "." . $extension; //lưu với tên mới để tránh bị trùng
        $file = $uploadDir . $newFileName;

        if (move_uploaded_file($tmp_name, $file)) {
            $imagePaths[] = $file;
        }
    }

    if (!empty($imagePaths)) {
        $imagePathsString = implode(",", $imagePaths); // Nối chuỗi ảnh bằng dấu phẩy
    } else {
        //Trường hợp không có ảnh
        $imagePathsString = null;
    }
    return $imagePathsString;
}
