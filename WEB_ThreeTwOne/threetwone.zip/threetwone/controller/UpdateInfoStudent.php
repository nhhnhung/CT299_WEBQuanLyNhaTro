<?php
include '../model/Student.php';


// Phần upload ảnh
$folder = "../public/img_avatar/";
$last_str = pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION);
$file = $folder . "img" . uniqid() . "." . $last_str; //đánh tên theo chuỗi dài tự nhiên

$isUpload = 1;
$imageFileType = strtolower(pathinfo($file, PATHINFO_EXTENSION));

if (!empty($_FILES["fileToUpload"]["name"])) {
    // kiểm tra có phải file ảnh không
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if ($check !== false) {
            echo "File là 1 hình ảnh - " . $check["mime"] . ".";
            $isUpload = 1;
        } else {
            echo "File không phải là hình ảnh.";
            $isUpload = 0;
        }
    }

    // Kiểm tra file đã tồn tại chưa
    if (file_exists($file)) {
        echo "file này đã tồn tại.";
        $isUpload = 0;
    }


    // cho phép các định dạng file ảnh
    if (
        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif"
    ) {
        echo "Chỉ cho phép các định dạng sau: JPG, PNG, JPEG, GIF.";
        $isUpload = 0;
    }

    // kiểm tra file đã được upload chưa
    if ($isUpload == 0) {
        echo "file của bạn chưa được upload.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) {
            echo "File " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " đã được upload thành công.";
        } else {
            echo "có 1 lỗi trong quá trình upload.";
        }
    }
    $avatar = $file; // Nếu upload thành công, lấy ảnh mới

} else {
    $avatar = $_POST['current_avatar'];
}




if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hoten']) && isset($_POST['ngaysinh']) && isset($_POST['diachi']) && isset($_POST['sdt'])) {
    $hoten = $_POST['hoten'];
    $ngaysinh = $_POST['ngaysinh'];
    $diachi = $_POST['diachi'];
    $sdt = $_POST['sdt'];
    $ma_sv = $_COOKIE['ma_sv'];
    $img = $_POST['current_avatar'];

    updateInfoStudent($hoten, $ngaysinh, $diachi, $sdt, $ma_sv, $avatar);
    if ($img != $avatar) {
        if ($img != "../public/img_avatar/default_avartar.jpg") {
            unlink($img);
        }
    }
    header('Location: InfoStudent.php');
}
