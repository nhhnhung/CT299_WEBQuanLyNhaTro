<?php
    $connection->close();
?>