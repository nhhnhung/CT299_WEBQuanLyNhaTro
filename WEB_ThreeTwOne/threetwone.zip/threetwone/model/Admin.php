<?php
    function allowRegistBoardingHouse($ma_nt){
        include '../db/open.php';
        $sql = "UPDATE nha_tro SET soluongphong = 0 WHERE ma_nt = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function refuseRegistBoardingHouse($ma_nt){
        include '../db/open.php';
        $sql = "DELETE FROM nha_tro WHERE ma_nt = ? and soluongphong = -1";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function getAllStudent(){
        include '../db/open.php';
        $sql = "SELECT * FROM sinh_vien s join nguoi_dung n on s.ma_sv = n.ma_nd";
        $result = $connection->query($sql);
        $list = array();
        while($row = $result->fetch_assoc()){
            $list[] = $row;
        }
        include '../db/close.php';
        return $list;
    }

    function getAllLandLord(){
        include '../db/open.php';
        $sql = "SELECT * FROM chu_tro c join nguoi_dung n on c.ma_ct = n.ma_nd";
        $result = $connection->query($sql);
        $list = array();
        while($row = $result->fetch_assoc()){
            $list[] = $row;
        }
        include '../db/close.php';
        return $list;
    }

    function lockAccount($ma_nd){
        include '../db/open.php';
        $sql = "UPDATE nguoi_dung SET trangthaitk = 'Đã khóa' WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nd);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function unlockAccount($ma_nd){
        include '../db/open.php';
        $sql = "UPDATE nguoi_dung SET trangthaitk = 'Đang mở' WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nd);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function updateUser($hoten, $ngaysinh, $email, $diachi, $sdt, $ma_nd){
        include '../db/open.php';
        $sql = "UPDATE nguoi_dung SET hoten = ?, ngaysinh = ?, email = ?, diachi = ?, sdt = ? WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssssi", $hoten, $ngaysinh, $email, $diachi, $sdt, $ma_nd);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function getAllCommision(){
        include '../db/open.php';
        $sql = "SELECT ten_nt, n.diachi as diachi, sophong, gia, tylephantram, sotien, trangthai, email FROM hoa_hong h join hop_dong hd on h.ma_hd = hd.ma_hd join phieu_dang_ky pdk on hd.ma_pdk = pdk.ma_pdk join phong_tro p on pdk.ma_phong = p.ma_phong join loai_phong lp on lp.ma_lp = p.ma_lp join nha_tro n on p.ma_nt = n.ma_nt join nguoi_dung nd on nd.ma_nd = n.ma_ct order by trangthai";

        $result = $connection->query($sql);
        $list = array();
        while($row = $result->fetch_assoc()){
            $list[] = $row;
        }
        include '../db/close.php';
        return $list;
    }

    function updateCommision($percent){
        include '../db/open.php';
        $sql = "select tylephantram from hoa_hong where trangthai is null limit 1";
        $result = $connection->query($sql);
        $oldPercent = 3.0;
        if($result->num_rows == 1){
            $row = $result->fetch_assoc();
            $oldPercent = $row['tylephantram'];
            $oldPercent = (float)$oldPercent;
        }else{
            return;
        }

        $newPercent = $percent/$oldPercent * 1.0;
        $sql = "UPDATE hoa_hong SET tylephantram = ". $percent ." , sotien = (sotien * ". $newPercent .") where trangthai is null";
        $connection->query($sql);
        include '../db/close.php';
    }

?>