<?php
    function getAllDevice(){
        include '../db/open.php';
        $sql = "SELECT * FROM thiet_bi";
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function getDevice($ma_tb){
        include '../db/open.php';
        $sql = "SELECT * FROM thiet_bi WHERE ma_tb = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_tb);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function addDevice($tenthietbi, $img){
        include '../db/open.php';
        $sql = "INSERT INTO thiet_bi(tenthietbi,img) VALUES (?,?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ss", $tenthietbi, $img);
        $stmt->execute();
        include '../db/close.php';
    }

    function updateDevice($ma_tb, $tenthietbi,$img){
        include '../db/open.php';
        $sql = "UPDATE thiet_bi SET tenthietbi = ?, img = ? WHERE ma_tb = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $tenthietbi,$img ,$ma_tb);
        $stmt->execute();
        include '../db/close.php';
    }

    function deleteDevice($ma_tb){
        include '../db/open.php';
        $sql = "DELETE FROM thiet_bi WHERE ma_tb = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_tb);
        $stmt->execute();
        include '../db/close.php';
    }

    function addDeviceOfRoomType($ma_lp, $ma_tb, $ngay_lap, $soluong, $tinhtrang){
        include '../db/open.php';
        $sql = "INSERT INTO phong_thiet_bi(ma_lp, ma_tb, ngay_lap, soluong, tinhtrang) VALUES (?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iisii", $ma_lp, $ma_tb, $ngay_lap, $soluong, $tinhtrang);
        $stmt->execute();
        include '../db/close.php';
    }

    function getListDeviceOfRoomType($ma_lp){
        include '../db/open.php';
        $sql = "SELECT * FROM phong_thiet_bi p join thiet_bi t on p.ma_tb = t.ma_tb WHERE ma_lp = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_lp);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }

    function isExitDevice($tenthietbi){
        include '../db/open.php';
        $sql = "SELECT * FROM thiet_bi WHERE tenthietbi = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $tenthietbi);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

?>