<?php
    function getAllService(){
        include '../db/open.php';
        $sql = "SELECT * FROM dich_vu";
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function getServiceById($id){
        include '../db/open.php';
        $sql = "SELECT * FROM dich_vu WHERE ma_dv = $id";
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function saveUseService($dateUse, $quantity, $ma_phong, $ma_dv){
        include '../db/open.php';
        $sql = 'INSERT INTO su_dung_dv(ngaysudung, soluong, ma_phong, ma_dv)
                VALUES(?, ?, ?, ?)';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('ssss', $dateUse, $quantity, $ma_phong, $ma_dv);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

?>