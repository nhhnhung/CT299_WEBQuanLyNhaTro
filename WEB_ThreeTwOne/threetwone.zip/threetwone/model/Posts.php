<?php
    function addPost($ma_nd, $noidungbd, $imagePathsString){
        include '../db/open.php';
        $sql = 'insert into bai_dang(noidungbd, ma_nd, url_images) values(?, ?, ?)';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sis", $noidungbd, $ma_nd,$imagePathsString);
        $stmt->execute();
        include '../db/close.php';
    }


    function getAllPostOfUser($ma_nd){
        include '../db/open.php';
        $sql = 'select * from bai_dang where ma_nd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nd);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }

    function getAllPost(){
        include '../db/open.php';
        $sql = 'select * from bai_dang b join nguoi_dung n on b.ma_nd = n.ma_nd where (ngaydang is not null) order by ngaydang desc';
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function getAllPostNotModeration(){
        include '../db/open.php';
        $sql = 'select * from bai_dang b join nguoi_dung n on b.ma_nd = n.ma_nd where (ngaydang is null) order by ngaydang desc';
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function allowPost($ma_bd){
        include '../db/open.php';
        date_default_timezone_set("Asia/Ho_Chi_Minh");
        $ngaydang = date("Y-m-d H:i:s");
        $sql = 'update bai_dang set ngaydang = ? where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("si", $ngaydang, $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function rejectPost($ma_bd){
        include '../db/open.php';
        $sql = 'delete from bai_dang where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function editPost($ma_bd, $noidungbd,$imagePathsString){
        include '../db/open.php';
        $sql = 'update bai_dang set noidungbd = ?, url_images = ? where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $noidungbd,$imagePathsString, $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }
    function editPostHaveOld($ma_bd, $noidungbd, $imagePathsString, $old_img){
        include '../db/open.php';
        if (!empty($old_img)) {
            $imagePaths = explode(",", $old_img);

            // Xóa từng ảnh trong thư mục
            foreach ($imagePaths as $image) {
                $filePath = trim($image);
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
            }
        }
        $sql = 'update bai_dang set noidungbd = ?, url_images = ? where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $noidungbd, $imagePathsString, $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function deletePost($ma_bd){
        include '../db/open.php';
        $sql = 'delete from binh_luan where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_bd);
        $stmt->execute();


        $sql = 'SELECT url_images FROM bai_dang WHERE ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_bd);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (!empty($row["url_images"])) {
                $imagePaths = explode(",", $row["url_images"]); // Tách danh sách ảnh

                // Xóa từng ảnh trong thư mục
                foreach ($imagePaths as $image) {
                    $filePath = trim($image); // Loại bỏ khoảng trắng nếu có
                    if (file_exists($filePath)) {
                        unlink($filePath);
                    }
                }
            }
        }

        $sql = 'delete from bai_dang where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function getAllCommentOfPost($ma_bd){
        include '../db/open.php';
        $sql = 'select * from binh_luan b join tai_khoan t on b.ma_tk = t.ma_tk join nguoi_dung n on t.ma_nd = n.ma_nd where ma_bd = ? order by thoigianbl desc';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }


    function addComment($ma_bd, $ma_nd, $noidungbl){
        include '../db/open.php';
        $sql = 'select * from nguoi_dung n join tai_khoan t on n.ma_nd = t.ma_nd where t.ma_nd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('s', $ma_nd);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $ma_tk = $row['ma_tk'];

        $sql = 'insert into binh_luan(noidungbl, ma_bd, ma_tk, thoigianbl) values(?, ?, ?, ?)';
        date_default_timezone_set("Asia/Ho_Chi_Minh");
        $thoigianbl = date('Y-m-d H:i:s');
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('siis', $noidungbl, $ma_bd, $ma_tk, $thoigianbl);
        $stmt->execute();
        include '../db/close.php';
    }

    function blockCommentByAdmin($ma_bd){
        include '../db/open.php';
        $sql = 'update bai_dang set khoa_bl = "admin_block" where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function unblockCommentByAdmin($ma_bd){
        include '../db/open.php';
        $sql = 'update bai_dang set khoa_bl = null where ma_bd = ? and khoa_bl = "admin_block"';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function blockCommentByUser($ma_bd){
        include '../db/open.php';
        $sql = 'update bai_dang set khoa_bl = "user_block" where ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function unblockCommentByUser($ma_bd){
        include '../db/open.php';
        $sql = 'update bai_dang set khoa_bl = null where ma_bd = ? and khoa_bl = "user_block"';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        include '../db/close.php';
    }

    function isAuthor($ma_nd, $ma_bd){
        include '../db/open.php';
        $sql = 'select * from bai_dang where ma_nd = ? and ma_bd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('ii', $ma_nd, $ma_bd);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

    function isBlockComment($ma_bd){
        include '../db/open.php';
        $sql = 'select * from bai_dang where ma_bd = ? and khoa_bl is not null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('i', $ma_bd);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows == 1;
    }

?>















