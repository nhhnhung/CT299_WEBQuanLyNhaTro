<?php
    function setOrUpdatePriceElectricWater($ma_nt, $gia_dien, $gia_nuoc){
        include '../db/open.php';
        $thang = date('m');
        $nam = date('Y');
        if(getPriceElectricWater($ma_nt, $thang, $nam) != null) {
            $sql = "UPDATE don_gia_dien_nuoc SET gia_dien = ?, gia_nuoc = ? WHERE ma_nt = ? and thang = ? and nam = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("iiiii", $gia_dien, $gia_nuoc, $ma_nt, $thang, $nam);
            $stmt->execute();
        }else{
            $sql = "INSERT INTO don_gia_dien_nuoc (ma_nt, thang, nam, gia_dien, gia_nuoc) VALUES (?, ?, ?, ?, ?)";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("iiiii", $ma_nt, $thang, $nam, $gia_dien, $gia_nuoc);
            $stmt->execute();
        }
        include '../db/close.php';
    }

    function getPriceElectricWater($ma_nt, $thang, $nam){
        include '../db/open.php';
        $sql = "SELECT * FROM don_gia_dien_nuoc WHERE ma_nt = ? and thang = ? and nam = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_nt, $thang, $nam);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows > 0){
            return $result->fetch_assoc();
        }
        include '../db/close.php';
        return null;
    }


    function setOrUpdateElectricWater($ma_phong, $ma_dgdn, $chiso_dien, $chiso_nuoc){
        include '../db/open.php';
        if(getElectricWater($ma_phong, date('m'), date('Y')) != null) {
            $sql = "UPDATE dien_nuoc SET chiso_dien = ?, chiso_nuoc = ? WHERE ma_phong = ? and ma_dgdn = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("iiii", $chiso_dien, $chiso_nuoc, $ma_phong, $ma_dgdn);
            $stmt->execute();
        }else{
            $sql = "INSERT INTO dien_nuoc (ma_phong, ma_dgdn, chiso_dien, chiso_nuoc) VALUES (?, ?, ?, ?)";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("iiii", $ma_phong, $ma_dgdn, $chiso_dien, $chiso_nuoc);
            $stmt->execute();
        }
        include '../db/close.php';
    }

    function getElectricWater($ma_phong, $thang, $nam){
        include '../db/open.php';
        $sql = "SELECT * FROM dien_nuoc d1 join don_gia_dien_nuoc d2 on d1.ma_dgdn = d2.ma_dgdn WHERE ma_phong = ? and d2.thang = ? and d2.nam = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_phong, $thang, $nam);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows > 0){
            return $result->fetch_assoc();
        }
        include '../db/close.php';
        return null;
    }

    function BeforeMonth($month){
        if($month == 1){
            return 12;
        }
        return $month - 1;
    }

    function getListRoom_NotPay_ElectricWater($ma_sv){
        include '../db/open.php';
        $sql = "select * from thue_phong t join phong_tro p on t.ma_phong = p.ma_phong
                join nha_tro n on p.ma_nt = n.ma_nt join dien_nuoc d on p.ma_phong = d.ma_phong
                where t.ma_sv = ? and d.trangthai_thanhtoan is null";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }


    function updateElectricWater_AfterPay($ma_phong, $ma_dgdn){
        include '../db/open.php';
        $sql = "UPDATE dien_nuoc SET trangthai_thanhtoan = 'yes' WHERE ma_phong = ? and ma_dgdn = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_phong, $ma_dgdn);
        $stmt->execute();
        include '../db/close.php';
    }


    function isRoomNotPayElectricWater($ma_sv, $ma_phong){
        include '../db/open.php';
        $sql = "select * from thue_phong t join phong_tro p on t.ma_phong = p.ma_phong
                join nha_tro n on p.ma_nt = n.ma_nt join dien_nuoc d on p.ma_phong = d.ma_phong
                where t.ma_sv = ? and d.trangthai_thanhtoan is null and t.ma_phong = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_sv, $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

?>













