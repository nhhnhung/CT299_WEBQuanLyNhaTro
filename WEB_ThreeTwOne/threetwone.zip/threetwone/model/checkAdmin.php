<?php
    function check($key){
        $keys = array('MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyOEC6+Z5XGn2gNlt7nGspShGNB6UeWwG+Uzgg+auG5ZyFh9P5lFdWroNFl5pT2KPsyxnl6vnslcZ2arwHMTfg4yY9IXhJ4zj8t0t1ae5zZJkLgq4f7dMbVtYNVRDQDt9E+uNBK9nkZD5XM8b4YK0D3ybQJUPtYV/1M1+f++MFm8t+6eRQ1ggYZFNN9u8Vp6f2uaHsdPqs3aVmy7xSFQMIIEpAIBAAKCAQEAyOEC6+Z5XGn2gNlt7nGspShGNB6UeWwG+Uzgg+auG5ZyFh9P5lFdWroNFl5pT2KPsyxnl6vnslcZ2arwHMTfg4yY9IXhJ4zj8t0t1ae5zZJkLgq4f7dMbVtYNVRDQDt9+uNBK9nkZD5XM8b4YK0D3ybQJUPtYV/1M1+f++MFm8t+6eRQ1ggYZFNN9u8Vp6f2uaHsdPqs3aVmy7x');

        if(in_array($key, $keys)){
            return true;
        } else {
            return false;
        }
    }
?>