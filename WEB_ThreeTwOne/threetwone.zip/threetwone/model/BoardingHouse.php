<?php
    function registBoadingHouse($tennt, $diachi, $ma_ct){
        include '../db/open.php';
        $sql = "INSERT INTO nha_tro(ten_nt, diachi, soluongphong, ma_ct) VALUES (?, ?, -1, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $tennt, $diachi, $ma_ct);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function getListBoardingHouseUnComfirm(){
        include '../db/open.php';
        $sql = 'select * from nha_tro n1 join nguoi_dung n2 on n1.ma_ct = n2.ma_nd  where soluongphong = -1';
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function getDataBoardingHouse($ma_nt) {
        include '../db/open.php';
        $sql = 'select * from nha_tro where ma_nt = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function getAllBoardingHouseOfLandLord($ma_ct) {
        include '../db/open.php';
        $sql = 'select * from nha_tro where ma_ct = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_ct);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }


    function addRoomType($price, $capacity, $area_room, $ma_nt, $imgs){
        include '../db/open.php';
        $sql = "INSERT INTO loai_phong(gia, succhua, dientich, ma_nt, imgs) VALUES (?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssss", $price, $capacity, $area_room, $ma_nt, $imgs);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function getListRoomType($ma_nt) {
        include '../db/open.php';
        $sql = 'select * from loai_phong where ma_nt = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }

    function getListRommOfRoomType($ma_lp){
        include '../db/open.php';
        $sql = 'select ma_phong, sophong from loai_phong l join phong_tro p on l.ma_lp = p.ma_lp where l.ma_lp = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_lp);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }

    function getAllRoomOfBoardingHouse($ma_nt){
        include '../db/open.php';
        $sql = 'select * from phong_tro where ma_nt = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }

    function getListPersonOfRoom($ma_phong){
        include '../db/open.php';
        $sql = 'select t.ma_sv as ma_sv from phong_tro p join thue_phong t on p.ma_phong = t.ma_phong join hop_dong h on t.ma_hd = h.ma_hd where p.ma_phong = ? and (h.ngayketthuc is null or h.ngayketthuc > now()) and (t.sothango != 0 or t.sothango is null)';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }


    function addRoom($numberOfroom, $ma_nt, $ma_lp){
        include '../db/open.php';
        $sql = "INSERT INTO phong_tro(sophong, ma_nt, ma_lp) VALUES (?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $numberOfroom, $ma_nt, $ma_lp);
        $stmt->execute();

        $sql = "select soluongphong from nha_tro where ma_nt = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $soluongphong = $row['soluongphong'];
        $soluongphong++;

        $sql = "update nha_tro set soluongphong = ? where ma_nt = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $soluongphong, $ma_nt);
        $stmt->execute();
        $stmt->close();

        include '../db/close.php';
    }

    function getRoomType($price, $capacity, $area_room, $ma_nt){
        include '../db/open.php';
        $sql = 'select * from loai_phong where gia = ? and succhua = ? and dientich = ? and ma_nt = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssi", $price, $capacity, $area_room, $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function getPriceRoom($ma_phong){
        include '../db/open.php';
        $sql = 'select * from loai_phong l join phong_tro p on l.ma_lp = p.ma_lp where ma_phong = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->fetch_assoc();
    }


    function checkExitRoom($ma_nt, $numberOfroom){
        include '../db/open.php';
        $sql = 'select * from phong_tro where ma_nt = ? and sophong = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_nt, $numberOfroom);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }


    function checkOccupiedRoom($ma_phong){
        include '../db/open.php';
        $sql = 'select * from phieu_dang_ky p join hop_dong h on p.ma_pdk = h.ma_pdk join thue_phong t on t.ma_hd = h.ma_hd where p.ma_phong = ? and (ngayketthuc is null or ngayketthuc > now())';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }


    function addRegistration($ma_sv, $ma_phong){
        include '../db/open.php';
        $sql = "INSERT INTO phieu_dang_ky(ngaydangky, ma_sv, ma_phong) VALUES (?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $date = date('Y-m-d');
        $stmt->bind_param("sii", $date, $ma_sv, $ma_phong);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function getAllRegistedRoom() {
        include '../db/open.php';
        $sql = 'select distinct ma_phong from phieu_dang_ky where ngayhen is null';
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }

    function getDataRoom($ma_phong) {
        include '../db/open.php';
        $sql = 'select * from phong_tro p join nha_tro n on p.ma_nt = n.ma_nt join loai_phong l on l.ma_lp = p.ma_lp where ma_phong = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function getListPersonRegistedRoom($ma_phong){
        include '../db/open.php';
        $sql = 'select * from phieu_dang_ky p join nguoi_dung n on p.ma_sv = n.ma_nd where ma_phong = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }

    function checkRegisted($ma_sv, $ma_phong){
        include '../db/open.php';
        $sql = 'select * from phieu_dang_ky where ma_sv = ? and ma_phong = ? and ngayhen is null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_sv, $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

    function checkWaitingPaymentForRoom($ma_sv, $ma_phong){
        include '../db/open.php';
        $sql = 'select * from phieu_dang_ky p join hop_dong h on p.ma_pdk = h.ma_pdk where p.ma_sv = ? and p.ma_phong = ? and h.ngayky is null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_sv, $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

    function allowRoomBooking($ma_pdk, $ma_phong, $ma_sv, $ngayhen){
        include '../db/open.php';
        include '../public/helper/sendEmail.php';
        $sql = "update phieu_dang_ky set ngayhen = ? where ma_pdk = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("si", $ngayhen, $ma_pdk);
        $stmt->execute();

        $sql = 'select * from phieu_dang_ky p join nguoi_dung n on p.ma_sv = n.ma_nd where p.ma_phong = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_phong);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($person = $result->fetch_assoc()) {
            if($person['ma_sv'] != $ma_sv){
                send_email('Thông báo nhà trọ', 'Phòng bạn đã đăng ký đã bị từ chối', $person['email']);
            }else{
                send_email('Thông báo nhà trọ', 'Phòng bạn đã đăng ký đã được chấp nhận, vui lòng thanh tóán tiền cọc', $person['email']);
            }
        }

        $sql = 'delete from phieu_dang_ky where ma_phong = ? and ngayhen is null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_phong);
        $stmt->execute();

        $sql = 'insert into hop_dong(ma_sv, ma_pdk) values (?, ?)';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_sv, $ma_pdk);
        $stmt->execute();


        $stmt->close();
        include '../db/close.php';
    }


    function rejectRoomBooking($ma_pdk){
        include '../db/open.php';
        include '../public/helper/sendEmail.php';
        $sql = 'select * from phieu_dang_ky p join nguoi_dung n on p.ma_sv = n.ma_nd where p.ma_pdk = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_pdk);
        $stmt->execute();
        $result = $stmt->get_result();
        $person = $result->fetch_assoc();
        send_email('Thông báo', 'Phòng bạn đã đăng ký đã bị từ chối', $person['email']);

        $sql = 'delete from phieu_dang_ky where ma_pdk = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_pdk);
        $stmt->execute();

        $stmt->close();
        include '../db/close.php';
    }


    function getListRoomNotDeposit($ma_sv){
        include '../db/open.php';
        $sql = 'select * from phieu_dang_ky p join hop_dong h on p.ma_pdk = h.ma_pdk join phong_tro pt on p.ma_phong = pt.ma_phong join nha_tro n on pt.ma_nt = n.ma_nt join loai_phong lp on lp.ma_lp = pt.ma_lp where p.ma_sv = ? and h.ngayky is null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }


    function contractPayment($ma_hd){
        include '../db/open.php';
        $sql = 'update hop_dong set ngayky = now(), noidung = "Nội dung hợp đồng" where ma_hd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_hd);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }

    function addCommision($ma_hd, $amount) {
        include '../db/open.php';
        $sql = 'select * from hoa_hong where ma_hd = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_hd);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows == 0){
            $sql = 'insert into hoa_hong(tylephantram, sotien, ma_hd) values (3, ?, ?)';
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("ii", $amount, $ma_hd);
            $stmt->execute();
        }
        include '../db/close.php';
    }


    function addRentingRoom($ma_phong, $ma_dh, $ma_sv){
        include '../db/open.php';
        $sql = 'insert into thue_phong(ma_phong, ma_hd, ma_sv) values (?, ?, ?)';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_phong, $ma_dh, $ma_sv);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }


    function getListCommision($ma_ct){
        include '../db/open.php';
        $sql = 'select * from hoa_hong h join hop_dong hd on h.ma_hd = hd.ma_hd join phieu_dang_ky p on hd.ma_pdk = p.ma_pdk join nguoi_dung n on p.ma_sv = n.ma_nd join phong_tro pt on p.ma_phong = pt.ma_phong join nha_tro nt on pt.ma_nt = nt.ma_nt where nt.ma_ct = ? and trangthai is null';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_ct);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result;
    }


    function updateStatusCommision($ma_hoahong){
        include '../db/open.php';
        $sql = 'update hoa_hong set trangthai = ? where ma_hoahong = ?';
        $stmt = $connection->prepare($sql);
        $yes = 'yes';
        $stmt->bind_param("si", $yes, $ma_hoahong);
        $stmt->execute();
        $stmt->close();
        include '../db/close.php';
    }


    function getDataSearchHouse($input) {
        include '../db/open.php';
        $query = "SELECT n.hoten, n.sdt, nt.*, lp.* 
                    FROM nha_tro nt
                    JOIN loai_phong lp ON nt.ma_nt = lp.ma_nt
                    JOIN nguoi_dung n ON n.ma_nd = nt.ma_ct WHERE 1=1";
        if (is_numeric($input)) {
            $input = (int)$input;
            $query .= " AND (dientich = ? OR gia = ?)";
            $stmt = $connection->prepare($query);
            $stmt->bind_param("ii", $input, $input);
        } elseif (preg_match('/^(\d+)-(\d+)$/', $input, $matches)) { //tách số từ chuỗi
            $query .= " AND gia BETWEEN ? AND ?";
            $stmt = $connection->prepare($query);
            $stmt->bind_param("ii", $matches[1], $matches[2]);
        } else {
            $query .= " AND (nt.diachi LIKE ? OR nt.ten_nt LIKE ?)";
            $search = "%$input%";
            $stmt = $connection->prepare($query);
            $stmt->bind_param("ss", $search, $search);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }

    function getListRoomSeard($ma_lp) {
        include '../db/open.php';
        $sql = 'select * from loai_phong where ma_lp = ?';
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_lp);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }


?>












