<?php 

    function checkLogin($email, $passwordUser, $role){
        require '../db/open.php';

        if($role == 'sinhvien'){
            $sql = "SELECT * FROM sinh_vien JOIN nguoi_dung ON sinh_vien.ma_sv = nguoi_dung.ma_nd JOIN tai_khoan ON nguoi_dung.ma_nd = tai_khoan.ma_nd WHERE email = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if($result->num_rows == 1){
                $row = $result->fetch_assoc();
                if(password_verify($passwordUser, $row['matkhau']) && $row['trangthaitk'] != 'Đã khóa'){
                    $_COOKIE['ma_sv'] = setcookie('ma_sv', $row['ma_sv'], time() + 7200, '/');
                    $_COOKIE['hoten'] = setcookie('hoten', $row['hoten'], time() + 7200, '/');
                    $_COOKIE['sdt'] = setcookie('sdt', $row['sdt'], time() + 7200, '/');
                    return true;
                }
                return false;
            }
        }else if($role == 'chutro'){
            $sql = "SELECT * FROM chu_tro JOIN nguoi_dung ON chu_tro.ma_ct = nguoi_dung.ma_nd JOIN tai_khoan ON nguoi_dung.ma_nd = tai_khoan.ma_nd WHERE email = ?";
            $stmt = $connection->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if($result->num_rows == 1){
                $row = $result->fetch_assoc();
                if(password_verify($passwordUser, $row['matkhau']) && $row['trangthaitk'] != 'Đã khóa'){
                    $_COOKIE['ma_ct'] = setcookie('ma_ct', $row['ma_ct'], time() + 7200, '/');
                    $_COOKIE['hoten'] = setcookie('hoten', $row['hoten'], time() + 7200, '/');
                    $_COOKIE['sdt'] = setcookie('sdt', $row['sdt'], time() + 7200, '/');
                    return true;
                }
                return false;
            }
        }else{
            return false;
        }

        include '../db/close.php';
    }

    

?>