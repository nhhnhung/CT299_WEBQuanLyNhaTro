<?php 

    function checkEmail($email) {
        include '../db/open.php';
        $sql = "SELECT * FROM nguoi_dung WHERE email = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        include '../db/close.php';
        if($result->num_rows > 0){
            return true;
        }
        return false;    
    }


    function saveSinhVien($name, $birthday, $email, $address, $phone, $passwordUser){
        include '../db/open.php';

        $sql = "INSERT INTO nguoi_dung (hoten, ngaysinh, email, diachi, sdt) VALUES (?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssss", $name, $birthday, $email, $address, $phone);
        $stmt->execute();

        $sql = "SELECT ma_nd FROM nguoi_dung WHERE email = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $sql = "INSERT INTO sinh_vien (ma_sv) VALUES (?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $row['ma_nd']);
        $stmt->execute();

        $password_hash = password_hash($passwordUser, PASSWORD_DEFAULT);
        $sql = "INSERT INTO tai_khoan (ten_tk, matkhau, ma_nd) VALUES (?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $name, $password_hash, $row['ma_nd']);
        $stmt->execute();
        include '../db/close.php';
    }


    function saveChuTro($name, $birthday, $email, $address, $phone, $passwordUser, $tax_id){
        include '../db/open.php';

        $sql = "INSERT INTO nguoi_dung (hoten, ngaysinh, email, diachi, sdt) VALUES (?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssss", $name, $birthday, $email, $address, $phone);
        $stmt->execute();

        $sql = "SELECT ma_nd FROM nguoi_dung WHERE email = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $sql = "INSERT INTO chu_tro (ma_ct, masothue) VALUES (?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("is", $row['ma_nd'], $tax_id);
        $stmt->execute();

        $password_hash = password_hash($passwordUser, PASSWORD_DEFAULT);
        $sql = "INSERT INTO tai_khoan (ten_tk, matkhau, ma_nd) VALUES (?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ssi", $name, $password_hash, $row['ma_nd']);
        $stmt->execute();

        include '../db/close.php';
    }

    function resetPass($passwordUser, $email){
        include '../db/open.php';

        $password_hash = password_hash($passwordUser, PASSWORD_DEFAULT);
        $sql = "UPDATE tai_khoan SET matkhau = ? WHERE ma_nd = (SELECT ma_nd FROM nguoi_dung WHERE email = ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ss", $password_hash, $email);
        $stmt->execute();

        include '../db/close.php';
    }

    
?>