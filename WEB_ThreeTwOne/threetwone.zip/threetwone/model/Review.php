<?php
    function addReview($ma_nt, $ma_nd, $so_sao, $danh_gia){
        include '../db/open.php';
        $sql = "insert into danhgianhatro(ma_nt, ma_nd, so_sao, danh_gia) values(?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iiis", $ma_nt, $ma_nd, $so_sao, $danh_gia);
        $stmt->execute();
        include '../db/close.php';
    }

    function getAllReviewOfBoardingHouse($ma_nt){
        include '../db/open.php';
        $sql = "select * from danhgianhatro d join nguoi_dung n on d.ma_nd = n.ma_nd where ma_nt = ? order by thoi_gian desc";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $ma_nt);
        $stmt->execute();
        $result = $stmt->get_result();
        $reviews = [];
        while($row = $result->fetch_assoc()){
            $reviews[] = $row;
        }
        include '../db/close.php';
        return $reviews;
    }
?>