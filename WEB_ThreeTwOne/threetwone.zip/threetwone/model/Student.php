<?php 
    function getDataStudent($ma_sv){
        include '../db/open.php';
        $sql = "SELECT * FROM nguoi_dung WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        $student = $result->fetch_assoc();
        $stmt->close();

        include '../db/close.php';
        return $student;
    }

    function updateInfoStudent($hoten, $ngaysinh, $diachi, $sdt, $ma_sv, $avatar){
        include '../db/open.php';
        $sql = "UPDATE nguoi_dung SET hoten = ?, ngaysinh = ?, diachi = ?, sdt = ?, avatar = ? WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssssi", $hoten, $ngaysinh, $diachi, $sdt,$avatar, $ma_sv);
        $stmt->execute();

        include '../db/close.php';
    }


    function getAllRoomStudentStay($ma_sv) {
        include '../db/open.php';
        $sql = "select * from thue_phong t join phong_tro p on t.ma_phong = p.ma_phong
                join nha_tro n on p.ma_nt = n.ma_nt
                join hop_dong h on h.ma_hd = t.ma_hd
                join loai_phong lp on lp.ma_lp = p.ma_lp
                where t.ma_sv = ? and ((h.ngayketthuc is null) or (h.ngayketthuc < now())) and (t.sothango is null or t.sothango > 0)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }

    function isPersonHiring($ma_sv, $ma_hd){
        include '../db/open.php';
        $sql = "select * from hop_dong h join phieu_dang_ky p on h.ma_pdk = p.ma_pdk where h.ma_hd = ? and p.ma_sv = ? and (h.ngayketthuc is null or h.ngayketthuc > now())";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_hd, $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

    function getDataStudentByEmail($email){
        include '../db/open.php';
        $sql = "SELECT * FROM nguoi_dung n join sinh_vien s on n.ma_nd = s.ma_sv WHERE n.email = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->fetch_assoc();
    }

    function isMemberOfRoom($ma_sv, $ma_hd){
        include '../db/open.php';
        $sql = "select * from thue_phong where ma_sv = ? and ma_hd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("ii", $ma_sv, $ma_hd);
        $stmt->execute();
        $result = $stmt->get_result();
        include '../db/close.php';
        return $result->num_rows > 0;
    }

    function addPersonToRoom($ma_phong, $ma_hd, $ma_sv){
        include '../db/open.php';
        $sql = "insert into thue_phong(ma_phong, ma_hd, sothango, ma_sv) values(?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $sothango = 0;
        $stmt->bind_param("iiis", $ma_phong, $ma_hd, $sothango, $ma_sv);
        $stmt->execute();
        $result = $stmt->affected_rows;
        include '../db/close.php';
        return $result > 0;
    }

    function getListInvitation($ma_sv){
        include '../db/open.php';
        $sql = "select p.sophong, n.ten_nt, n.diachi, lp.gia, lp.succhua, t.ma_sv, pk.ma_sv as ma_inviter, p.ma_phong, h.ma_hd
                from thue_phong t 
                join phong_tro p on t.ma_phong = p.ma_phong
                join nha_tro n on p.ma_nt = n.ma_nt
                join hop_dong h on h.ma_hd = t.ma_hd
                join phieu_dang_ky pk on h.ma_pdk = pk.ma_pdk
                join loai_phong lp on lp.ma_lp = p.ma_lp
                where t.ma_sv = ? and (h.ngayketthuc is null or h.ngayketthuc < now()) and t.sothango = 0";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_sv);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        include '../db/close.php';
        return $result;
    }

    function acceptJoinRoom($ma_phong, $ma_hd, $ma_sv){
        include '../db/open.php';
        $sql = "update thue_phong set sothango = null where ma_phong = ? and ma_hd = ? and ma_sv = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_phong, $ma_hd, $ma_sv);
        $stmt->execute();
        include '../db/close.php';
    }

    function rejectJoinRoom($ma_phong, $ma_hd, $ma_sv){
        include '../db/open.php';
        $sql = "delete from thue_phong where ma_phong = ? and ma_hd = ? and ma_sv = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_phong, $ma_hd, $ma_sv);
        $stmt->execute();
        include '../db/close.php';
    }

    function exitRoom($ma_phong, $ma_hd, $ma_sv){
        include '../db/open.php';
        $sql = "delete from thue_phong where ma_phong = ? and ma_hd = ? and ma_sv = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iii", $ma_phong, $ma_hd, $ma_sv);
        $stmt->execute();
        include '../db/close.php';
    }

?>










