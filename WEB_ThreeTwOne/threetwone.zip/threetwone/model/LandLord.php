<?php 
    function getDataLandLord($ma_ct){
        include '../db/open.php';
        $sql = "SELECT * FROM nguoi_dung n join chu_tro ct on n.ma_nd = ct.ma_ct WHERE n.ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("s", $ma_ct);
        $stmt->execute();
        $result = $stmt->get_result();
        $landlord = $result->fetch_assoc();
        $stmt->close();

        include '../db/close.php';
        return $landlord;
    }

    function updateInfoLandLord($hoten, $ngaysinh, $diachi, $sdt,  $avatar, $ma_ct){
        include '../db/open.php';
        $sql = "UPDATE nguoi_dung SET hoten = ?, ngaysinh = ?, diachi = ?, sdt = ?, avatar = ? WHERE ma_nd = ?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("sssssi", $hoten, $ngaysinh, $diachi, $sdt, $avatar, $ma_ct);
        $stmt->execute();
        include '../db/close.php';
    }

    function getAllLandLord(){
        include '../db/open.php';
        $sql = "SELECT * FROM nguoi_dung n join chu_tro ct on n.ma_nd = ct.ma_ct";
        $result = $connection->query($sql);
        include '../db/close.php';
        return $result;
    }
?>




