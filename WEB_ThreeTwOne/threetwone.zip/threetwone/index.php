<?php 
    header('Location: controller/Login.php');
?>